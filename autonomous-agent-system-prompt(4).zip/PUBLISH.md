# WIRE — how to publish this on GitHub (2 minutes)

You do not need a terminal. Everything below happens in the browser.

---

## Way 1 — let the app do it for you (easiest)

1. Open the app → sidebar → **Tools → Source code**.
2. Click **"Make your key →"** — GitHub opens with the permissions already ticked.
   Scroll down and press **Generate token**, then copy it.
3. Paste the key into the field on that page, name the repository, press
   **Publish to GitHub**.

The desk writes every file to the repository itself and gives you a
**Deploy** button.

---

## Way 2 — upload the files by hand

1. Unzip `wire-source.zip`. You get a `wire/` folder.
2. Go to **github.com** → **New repository** → name it `wire-desk` → **Create**.
3. Click **Add file → Upload files** and drag the **contents** of the `wire/`
   folder (not the folder itself) into the page.
4. Press **Commit changes**. That's the whole upload.

---

## Make it live (either way)

1. **render.com** → **New → Web Service** → connect `wire-desk`.
   It reads `render.yaml` automatically. (Railway and Vercel work the same way.)
2. In the same dashboard: **New → PostgreSQL**, copy its connection URL.
3. Under your service → **Environment**, add:
   - `DATABASE_URL` = the Postgres URL
   - `OPENROUTER_API_KEY` = your model key
4. **Deploy.** Render prints your permanent URL and restarts the app if it
   ever stops.

Optional: `NEXT_PUBLIC_SITE_URL` = your URL (or your own domain) so search
engines and shared links point at the right place.

---

## Run it locally

```bash
npm install
npx drizzle-kit push
npm run build && npm run start
```

Needs Node 20+, PostgreSQL, and a `.env` with `DATABASE_URL` and
`OPENROUTER_API_KEY`.

## What is in here

- `src/lib` — the engine: agent, memory and ethics, the multi-AI mesh,
  self-rewriting codex, resident engineer, 216-app gateway, search, commands,
  site builder, treasury, source export.
- `src/app` — every route, plus the public `/about` page, sitemap and robots.
- `src/components` — the chat interface and its panels.
- `src/db` — the 15-table schema (Drizzle ORM).
- `Dockerfile`, `render.yaml` — deploy anywhere.
