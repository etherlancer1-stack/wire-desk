import Link from "next/link";

export default function NotFound() {
  return (
    <main className="grid min-h-dvh place-items-center bg-paper px-6 text-ink">
      <div className="max-w-[560px]">
        <p className="text-[12px] font-semibold tracking-[0.14em] text-wire uppercase">
          Wire · off the record
        </p>
        <h1 className="mt-4 font-display text-[clamp(40px,7vw,76px)] leading-[0.92] font-black tracking-[-0.03em]">
          Nothing filed
          <br />
          <span className="font-normal italic">under this address.</span>
        </h1>
        <p className="mt-6 font-serif text-[17px] leading-[1.62] text-ink-soft">
          The link you followed does not exist on this desk — or it was one of
          the private builds, which open only through their own unguessable
          link. Every answer is one click away.
        </p>
        <Link
          href="/"
          className="mt-8 inline-block rounded-full bg-wire px-7 py-3.5 text-[15px] font-semibold text-paper hover:opacity-90"
        >
          Open the desk →
        </Link>
      </div>
    </main>
  );
}
