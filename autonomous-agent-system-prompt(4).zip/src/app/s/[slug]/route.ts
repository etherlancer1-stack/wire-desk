import { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { sites } from "@/db/schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Private builds. The slug is the key: unguessable, unlisted, yours. */
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ slug: string }> },
) {
  const { slug } = await params;
  const [site] = await db.select().from(sites).where(eq(sites.slug, slug)).limit(1);
  if (!site) {
    return new Response(
      "<!DOCTYPE html><meta charset='utf-8'><title>Not found</title><body style='font-family:Georgia,serif;background:#f2ede3;color:#16120e;display:grid;place-items:center;height:100vh;margin:0'><div style='text-align:center'><div style='font:11px ui-monospace,monospace;letter-spacing:.14em;text-transform:uppercase;color:#c6320f'>Private build</div><h1 style='font-size:44px;margin:.3em 0'>Not on this desk</h1><p>This link does not exist, or was taken down.</p></div></body>",
      { status: 404, headers: { "Content-Type": "text/html; charset=utf-8" } },
    );
  }
  await db
    .update(sites)
    .set({ visits: site.visits + 1 })
    .where(eq(sites.slug, slug));
  return new Response(site.html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "X-Robots-Tag": "noindex, nofollow",
      "Cache-Control": "private, max-age=60",
    },
  });
}
