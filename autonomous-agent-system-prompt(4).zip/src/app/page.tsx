import { WireDesk } from "@/components/WireDesk";

export default function Home() {
  return <WireDesk />;
}
