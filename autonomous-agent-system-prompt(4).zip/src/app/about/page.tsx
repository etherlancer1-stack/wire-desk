import type { Metadata, NextPage } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "WIRE — the AI answer desk that reads the live web, learns, and builds",
  description:
    "WIRE is an autonomous AI desk: it searches the live internet before answering, cites every claim to its source, remembers what you teach it, rewrites its own code, builds and privately hosts websites and games, and runs across many AI providers at once.",
  keywords: [
    "AI answer engine",
    "AI with sources",
    "autonomous AI agent",
    "AI website builder",
    "AI that learns",
    "live web search AI",
    "WIRE desk",
  ],
  openGraph: {
    title: "WIRE — the answer desk that reads the live web",
    description:
      "Ask anything. It reads the internet first, cites its sources, remembers you, and builds what you need.",
    type: "website",
  },
};

const FAQ = [
  {
    q: "What makes WIRE different from a chatbot?",
    a: "Every factual answer starts with the live internet. WIRE searches across web, Wikipedia, GitHub, Stack Overflow, arXiv, news, weather, books and live feeds, reads the actual pages, and numbers every claim back to the page it came from.",
  },
  {
    q: "Does it learn?",
    a: "Yes. It keeps a long-term memory of what you tell it, honours corrections permanently, adapts its tone to your verdicts, and rewrites its own operating rules from evidence every dozen turns. A resident engineer agent reads its own source code and files patches.",
  },
  {
    q: "Can it build things?",
    a: "Ask for a website, a game or a tool and it designs and writes the complete application, publishes it privately on its own unguessable link, and hands it to you.",
  },
  {
    q: "Which AI models does it use?",
    a: "A mesh of providers — Claude, GPT, Gemini, Groq, Mistral, DeepSeek, Grok, OpenRouter, Together, Cerebras and local models. It picks the best mind per question and migrates automatically if one provider goes down.",
  },
];

const AboutPage: NextPage = () => {
  return (
    <main className="mx-auto max-w-[900px] px-6 py-16">
      <p className="text-[12px] font-semibold tracking-[0.14em] text-wire uppercase">
        Autonomous answer desk
      </p>
      <h1 className="mt-4 font-display text-[clamp(38px,6vw,72px)] leading-[0.95] font-black tracking-[-0.03em]">
        WIRE answers anything — <span className="font-normal italic">and shows its work.</span>
      </h1>
      <p className="mt-6 max-w-[62ch] font-serif text-[19px] leading-[1.62] text-ink-soft">
        Ask a question and WIRE reads the live internet first: search results,
        whole pages, papers, repositories, books, news and live data. It answers
        in clean prose, cites every claim to the exact page it came from, and
        remembers what you teach it so the next answer is sharper than the last.
      </p>

      <div className="mt-12 grid gap-8 sm:grid-cols-2">
        {[
          ["Grounded answers", "Live search across a dozen ecosystems, pages fetched and read in full, numbered citations you can click."],
          ["A mind that grows", "Long-term memory, permanent corrections, a self-written codex of rules, and a resident engineer that analyses and patches its own code."],
          ["Builds for you", "Websites, games, dashboards and tools — written, published and hosted privately on their own unguessable links."],
          ["Never goes dark", "A mesh of model providers from many companies. One failing is not an outage; the desk continues on another."],
        ].map(([title, body]) => (
          <section key={title} className="border-t border-ink pt-4">
            <h2 className="font-display text-[21px] font-bold">{title}</h2>
            <p className="mt-2 font-serif text-[15.5px] leading-[1.62] text-ink-soft">{body}</p>
          </section>
        ))}
      </div>

      <h2 className="mt-16 font-display text-[30px] font-bold tracking-[-0.02em]">
        Questions people ask
      </h2>
      <div className="mt-6 space-y-8">
        {FAQ.map((f) => (
          <section key={f.q}>
            <h3 className="font-display text-[19px] font-semibold">{f.q}</h3>
            <p className="mt-2 max-w-[68ch] font-serif text-[16px] leading-[1.66] text-ink-soft">
              {f.a}
            </p>
          </section>
        ))}
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "WIRE",
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web",
            description:
              "Autonomous AI answer desk with live web grounding, citations, memory, self-rewriting code and a private website builder.",
            offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
          }),
        }}
      />

      <Link
        href="/"
        className="mt-14 inline-block rounded-full bg-wire px-7 py-3.5 text-[15px] font-semibold text-paper hover:opacity-90"
      >
        Open the desk →
      </Link>
    </main>
  );
};

export default AboutPage;
