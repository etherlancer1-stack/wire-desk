"use client";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en">
      <body
        style={{
          margin: 0,
          minHeight: "100vh",
          display: "grid",
          placeItems: "center",
          background: "#f2ede3",
          color: "#16120e",
          fontFamily: "Georgia, serif",
        }}
      >
        <div style={{ maxWidth: 560, padding: 24 }}>
          <p
            style={{
              color: "#c6320f",
              fontSize: 12,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              fontWeight: 600,
            }}
          >
            The desk recovered itself
          </p>
          <h1 style={{ fontSize: 52, lineHeight: 1, margin: "16px 0" }}>
            A fault was caught
            <br />
            <span style={{ fontWeight: 400, fontStyle: "italic" }}>
              before it took anything down.
            </span>
          </h1>
          <p style={{ fontSize: 17, lineHeight: 1.62, color: "#4a4038" }}>
            Something in the interface failed, and the survival layer isolated
            it. Your chats, memory, sites and the running agent are untouched.
            Reload and carry on.
          </p>
          <button
            onClick={reset}
            style={{
              marginTop: 28,
              background: "#c6320f",
              color: "#f2ede3",
              border: 0,
              borderRadius: 999,
              padding: "14px 28px",
              fontSize: 15,
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            Recover
          </button>
          <span style={{ marginLeft: 12, fontSize: 12, color: "#8c8072", fontFamily: "monospace" }}>
            {error?.digest ?? ""}
          </span>
        </div>
      </body>
    </html>
  );
}
