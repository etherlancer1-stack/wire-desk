import { NextRequest } from "next/server";
import {
  CATEGORIES,
  KALI_TOOLS,
  addTarget,
  assess,
  listTargets,
  reportSummary,
  toolStatus,
  verifyOwnership,
} from "@/lib/security";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** What each category of tool needs to actually run. */
const PERMISSIONS: Record<string, string> = {
  "Network discovery": "raw sockets · LAN visibility",
  "DNS security": "outbound DNS",
  OSINT: "public internet only",
  "Web application testing": "target in authorized scope",
  "Vulnerability assessment": "target in authorized scope",
  Exploitation: "isolated lab · written authorization",
  "Network traffic": "promiscuous capture on owned network",
  "Wireless security": "monitor-mode interface · owned hardware",
  "Password security": "own hashes · own services",
  Cryptography: "none — analysis only",
  "Reverse engineering": "local binaries you own",
  "Malware analysis": "isolated VM · no network",
  "Digital forensics": "read-only evidence copies",
  "Fuzz testing": "sandboxed runtime",
  "Container security": "registry or cluster credentials",
  "Cloud security": "own cloud account credentials",
  "Active Directory": "own domain · lab account",
  "Mobile security": "own builds · test device",
  "Hardware & radio": "own devices · local spectrum",
  "Web3 security": "own contracts · testnet",
  "Detection & response": "log sources you control",
  "Security reporting": "none",
};

export async function GET() {
  const [targets, status] = await Promise.all([listTargets(), toolStatus()]);
  return Response.json({
    tools: KALI_TOOLS.map((t) => ({
      ...t,
      install: t.docs.includes("kali.org") ? `sudo apt install ${t.name.split("-")[0]}` : "see docs",
      permissions: PERMISSIONS[t.category] ?? "own systems only",
    })),
    categories: CATEGORIES,
    installed: status,
    targets,
    notice:
      "Authorized targets only. Checks are non-destructive. Tool status reflects what is actually present on this host — nothing is advertised as installed unless verified.",
  });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const action = String(body?.action ?? "assess");

  if (action === "add") {
    try {
      const target = await addTarget({
        name: String(body?.name ?? ""),
        host: String(body?.host ?? ""),
        scope: String(body?.scope ?? "owned"),
        notes: String(body?.notes ?? ""),
      });
      return Response.json({ ok: true, target });
    } catch (err) {
      return Response.json(
        { ok: false, error: err instanceof Error ? err.message : "invalid target" },
        { status: 400 },
      );
    }
  }

  if (action === "verify") {
    const host = String(body?.host ?? "").trim();
    const proof = await verifyOwnership(host);
    return Response.json({ ok: proof.verified, ...proof });
  }

  const host = String(body?.host ?? "").trim();
  const targets = await listTargets();
  const declared = targets.find((t) => t.host === host.replace(/^https?:\/\//, "").replace(/\/.*$/, ""));
  if (!declared) {
    return Response.json(
      {
        ok: false,
        error:
          "Refusing: this host is not in your authorized scope. Add it as a target you own or are permitted to test first.",
      },
      { status: 403 },
    );
  }

  const result = await assess(declared.host);
  return Response.json({ ok: true, ...result, summary: reportSummary(result.findings) });
}
