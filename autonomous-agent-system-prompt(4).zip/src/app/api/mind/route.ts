import { NextRequest } from "next/server";
import { consolidate, cycleStart, mindState, traverse } from "@/lib/graph";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** The linked mind: graph, episodes, cycles, traversal. */
export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q") ?? "";
  const [state, links] = await Promise.all([
    mindState(),
    q ? traverse(q, 3, 16) : Promise.resolve([]),
  ]);
  return Response.json({ ...state, links });
}

export async function POST(req: Request) {
  const body = await req.json();
  const action = String(body?.action ?? "cycle");

  if (action === "cycle") {
    const report = await cycleStart();
    return Response.json({ ok: true, report });
  }
  if (action === "consolidate") {
    const report = await consolidate();
    return Response.json({ ok: true, report });
  }
  return Response.json({ error: "Unknown action" }, { status: 400 });
}
