import { NextRequest } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { deployments } from "@/db/schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Deployment dashboard. A record here reflects a real deployment on the
 * provider — the provider link and its URL are stored, and status changes are
 * written when the provider reports them. Nothing is marked live optimistically.
 */
export async function GET() {
  const rows = await db.select().from(deployments).orderBy(desc(deployments.createdAt)).limit(50);
  return Response.json({
    deployments: rows,
    providers: [
      {
        id: "render",
        label: "Render",
        docs: "https://render.com/docs",
        needs: "account + PostgreSQL add-on",
        price: "free tier available; instance hours billed above it",
        launch: "https://dashboard.render.com/new",
      },
      {
        id: "railway",
        label: "Railway",
        docs: "https://docs.railway.com",
        needs: "account + Postgres plugin",
        price: "usage-based; $5 free credit monthly",
        launch: "https://railway.app/new",
      },
      {
        id: "vercel",
        label: "Vercel",
        docs: "https://vercel.com/docs",
        needs: "account + external database",
        price: "free hobby tier; functions and bandwidth metered",
        launch: "https://vercel.com/new",
      },
      {
        id: "fly",
        label: "Fly.io",
        docs: "https://fly.io/docs",
        needs: "account + Fly Postgres",
        price: "usage-based",
        launch: "https://fly.io/apps/new",
      },
      {
        id: "coolify",
        label: "Coolify (self-hosted)",
        docs: "https://coolify.io/docs",
        needs: "your own server",
        price: "free software; you pay for the server",
        launch: "https://coolify.io",
      },
    ],
  });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const action = String(body?.action ?? "record");

  if (action === "record") {
    const [row] = await db
      .insert(deployments)
      .values({
        project: String(body?.project ?? "WIRE").slice(0, 80),
        provider: String(body?.provider ?? "render").slice(0, 40),
        url: String(body?.url ?? "").slice(0, 200),
        status: ["pending", "building", "live", "failed", "rolled back"].includes(body?.status)
          ? body.status
          : "pending",
        log: String(body?.log ?? "").slice(0, 2000),
        commit: String(body?.commit ?? "").slice(0, 60),
      })
      .returning();
    return Response.json({ deployment: row });
  }

  if (action === "status" && body?.id) {
    await db
      .update(deployments)
      .set({
        status: String(body.status).slice(0, 20),
        log: body.log ? String(body.log).slice(0, 2000) : undefined,
        url: body.url ? String(body.url).slice(0, 200) : undefined,
      })
      .where(eq(deployments.id, String(body.id)));
    return Response.json({ ok: true });
  }

  return Response.json({ error: "Unknown action" }, { status: 400 });
}
