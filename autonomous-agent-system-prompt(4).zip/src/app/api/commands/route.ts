import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { commandLog, feedback } from "@/db/schema";
import { COMMANDS, runCommand } from "@/lib/commands";
import { vote } from "@/lib/brain";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const log = await db.select().from(commandLog).orderBy(desc(commandLog.createdAt)).limit(30);
  return Response.json({ commands: COMMANDS, log });
}

export async function POST(req: Request) {
  const body = await req.json();

  if (body?.type === "feedback") {
    await vote(
      body.messageId ? String(body.messageId) : null,
      Number(body.vote) < 0 ? -1 : 1,
      String(body.note ?? "").slice(0, 400),
    );
    return Response.json({ ok: true, learned: Boolean(String(body.note ?? "").trim()) });
  }

  const input = String(body?.input ?? "").trim();
  if (!input) return Response.json({ error: "Empty command" }, { status: 400 });
  const result = await runCommand(input);
  await db.insert(commandLog).values({
    command: result.command,
    input: input.slice(0, 500),
    output: result.output.slice(0, 4000),
    ok: result.ok ? 1 : 0,
  });
  return Response.json({ result });
}
