import { NextRequest } from "next/server";
import {
  createProject,
  deletePath,
  listProjects,
  makeDir,
  projectSummary,
  readFileSafe,
  removeProject,
  searchProject,
  tree,
  writeFileSafe,
} from "@/lib/workspace";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Persistent project workspaces — the same real files the agent works on. */
export async function GET(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  const rel = req.nextUrl.searchParams.get("path") ?? "";
  const query = req.nextUrl.searchParams.get("q") ?? "";
  const file = req.nextUrl.searchParams.get("file");

  if (!id) return Response.json({ projects: await listProjects() });

  try {
    if (file) {
      return Response.json({ content: await readFileSafe(id, file), path: file });
    }
    if (query) {
      return Response.json({ hits: await searchProject(id, query) });
    }
    const [entries, summary] = await Promise.all([tree(id, rel), projectSummary(id)]);
    return Response.json({ entries, summary });
  } catch (err) {
    return Response.json(
      { error: err instanceof Error ? err.message : "workspace error" },
      { status: 400 },
    );
  }
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const action = String(body?.action ?? "create");
  try {
    if (action === "create") {
      const project = await createProject({
        name: String(body?.name ?? ""),
        framework: String(body?.framework ?? "static"),
        description: String(body?.description ?? ""),
      });
      return Response.json({ project });
    }
    const id = String(body?.id ?? "");
    if (!id) return Response.json({ error: "Project id required" }, { status: 400 });

    if (action === "write") {
      const result = await writeFileSafe(id, String(body?.path ?? "untitled.txt"), String(body?.content ?? ""));
      return Response.json({ ok: true, ...result });
    }
    if (action === "mkdir") {
      await makeDir(id, String(body?.path ?? ""));
      return Response.json({ ok: true });
    }
    if (action === "delete") {
      await deletePath(id, String(body?.path ?? ""));
      return Response.json({ ok: true });
    }
    if (action === "delete-project") {
      await removeProject(id);
      return Response.json({ ok: true });
    }
    return Response.json({ error: "Unknown action" }, { status: 400 });
  } catch (err) {
    return Response.json(
      { error: err instanceof Error ? err.message : "workspace error" },
      { status: 400 },
    );
  }
}
