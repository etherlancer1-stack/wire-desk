import { desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { conversations, messages, sources } from "@/db/schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const convs = await db
    .select()
    .from(conversations)
    .orderBy(desc(conversations.updatedAt))
    .limit(60);

  let counts: Record<string, number> = {};
  if (convs.length) {
    const rows = await db
      .select({ id: messages.conversationId })
      .from(messages)
      .where(inArray(messages.conversationId, convs.map((c) => c.id)));
    for (const r of rows) counts[r.id] = (counts[r.id] ?? 0) + 1;
  }

  return Response.json({
    conversations: convs.map((c) => ({ ...c, turns: counts[c.id] ?? 0 })),
  });
}

export async function DELETE() {
  await db.delete(sources);
  await db.delete(messages);
  await db.delete(conversations);
  return Response.json({ ok: true });
}
