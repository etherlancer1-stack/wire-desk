import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { conversations, messages, sources } from "@/db/schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function GET(_req: Request, { params }: Params) {
  const { id } = await params;
  const [conversation] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, id))
    .limit(1);
  if (!conversation) return Response.json({ error: "Not found" }, { status: 404 });

  const msgs = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(asc(messages.createdAt));

  const srcs = await db
    .select()
    .from(sources)
    .where(eq(sources.conversationId, id))
    .orderBy(asc(sources.idx));

  return Response.json({ conversation, messages: msgs, sources: srcs });
}

export async function PATCH(req: Request, { params }: Params) {
  const { id } = await params;
  const body = await req.json();
  if (typeof body?.title === "string" && body.title.trim()) {
    await db
      .update(conversations)
      .set({ title: body.title.trim().slice(0, 96) })
      .where(eq(conversations.id, id));
  }
  return Response.json({ ok: true });
}

export async function DELETE(_req: Request, { params }: Params) {
  const { id } = await params;
  await db.delete(conversations).where(eq(conversations.id, id));
  return Response.json({ ok: true });
}
