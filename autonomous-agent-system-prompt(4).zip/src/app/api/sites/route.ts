import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sites } from "@/db/schema";
import { sanitizeSiteHtml, siteSlug, wrapSite } from "@/lib/sites";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db
    .select({
      id: sites.id,
      slug: sites.slug,
      title: sites.title,
      prompt: sites.prompt,
      bytes: sites.bytes,
      visits: sites.visits,
      createdAt: sites.createdAt,
      updatedAt: sites.updatedAt,
    })
    .from(sites)
    .orderBy(desc(sites.updatedAt))
    .limit(60);
  return Response.json({ sites: rows });
}

export async function POST(req: Request) {
  const body = await req.json();
  const title = String(body?.title ?? "Untitled build").slice(0, 120);
  const prompt = String(body?.prompt ?? "").slice(0, 400);
  const raw = String(body?.html ?? "");
  if (raw.length < 80) return Response.json({ error: "Nothing to publish" }, { status: 400 });

  const html = wrapSite(sanitizeSiteHtml(raw), title);
  const slug = siteSlug();
  const [row] = await db
    .insert(sites)
    .values({ slug, title, prompt, html, bytes: html.length })
    .returning();
  return Response.json({ site: { slug: row.slug, title: row.title, url: `/s/${row.slug}` } });
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const slug = url.searchParams.get("slug");
  if (slug) await db.delete(sites).where(eq(sites.slug, slug));
  else await db.delete(sites);
  return Response.json({ ok: true });
}
