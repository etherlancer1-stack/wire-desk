import { NextRequest } from "next/server";
import { listSource, textListing, zipSource } from "@/lib/bundle";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * The whole codebase, on demand.
 *   /api/code            → wire-source.zip  (every file, zipped in-process)
 *   /api/code?format=txt → one readable listing of all source
 *   /api/code?format=json→ the file manifest
 */
export async function GET(req: NextRequest) {
  const format = req.nextUrl.searchParams.get("format") ?? "zip";

  // Private source: owner-only. Without a configured owner key the export is
  // closed entirely; with one, the request must present it.
  const expected = process.env.WIRE_OWNER_KEY;
  const provided =
    req.nextUrl.searchParams.get("key") ?? req.headers.get("x-wire-owner") ?? "";
  if (!expected) {
    return Response.json(
      {
        error:
          "Source export is disabled. Set WIRE_OWNER_KEY in the server environment to enable owner-only access.",
      },
      { status: 403 },
    );
  }
  if (provided !== expected) {
    return Response.json({ error: "Owner key required." }, { status: 403 });
  }

  if (format === "json") {
    const files = await listSource();
    return Response.json({
      files,
      totals: {
        files: files.length,
        lines: files.reduce((a, f) => a + f.lines, 0),
        bytes: files.reduce((a, f) => a + f.bytes, 0),
      },
    });
  }

  if (format === "txt") {
    const text = await textListing();
    return new Response(text, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Disposition": 'attachment; filename="wire-source.txt"',
      },
    });
  }

  const zip = await zipSource();
  return new Response(new Uint8Array(zip), {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": 'attachment; filename="wire-source.zip"',
      "Content-Length": String(zip.length),
    },
  });
}
