import { NextRequest } from "next/server";
import { runAgent } from "@/lib/agent";
import { isCommand } from "@/lib/commands";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Body = {
  conversationId?: string;
  message: string;
  mode?: "ask" | "deep";
  regenerate?: boolean;
  apps?: string[];
  settings?: Partial<import("@/lib/agent").MeshSettings>;
};

/** Lightweight in-memory rate limit — the desk answers, it does not get farmed. */
const hits = new Map<string, { count: number; window: number }>();
function rateLimited(ip: string): boolean {
  const now = Date.now();
  const row = hits.get(ip);
  if (!row || now - row.window > 60_000) {
    hits.set(ip, { count: 1, window: now });
    return false;
  }
  row.count += 1;
  return row.count > 40;
}

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
  if (rateLimited(ip)) {
    return new Response(
      JSON.stringify({ error: "The desk is at capacity — one moment." }),
      { status: 429, headers: { "Content-Type": "application/json" } },
    );
  }

  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return Response.json({ error: "Malformed request" }, { status: 400 });
  }

  const message = (body.message ?? "").slice(0, 4000).trim();
  if (!message) return Response.json({ error: "Empty question" }, { status: 400 });

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let closed = false;
      const emit = (evt: Record<string, unknown>) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(JSON.stringify(evt) + "\n"));
        } catch {
          closed = true;
        }
      };
      req.signal.addEventListener("abort", () => {
        closed = true;
      });

      try {
        for await (const evt of runAgent({
          conversationId: body.conversationId ?? null,
          message,
          mode: body.mode === "deep" ? "deep" : "ask",
          settings: body.settings,
          apps: body.apps,
          regenerate: Boolean(body.regenerate),
          signal: req.signal,
        })) {
          emit({ ...evt, command: isCommand(message) ? evt.command : undefined });
          if (closed) break;
        }
      } catch (err) {
        emit({
          type: "error",
          message: err instanceof Error ? err.message : "Unknown failure on the desk.",
        });
      } finally {
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "application/x-ndjson; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}
