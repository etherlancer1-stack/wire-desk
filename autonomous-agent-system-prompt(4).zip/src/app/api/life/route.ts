import { desc } from "drizzle-orm";
import { db } from "@/db";
import { diary } from "@/db/schema";
import { wake } from "@/lib/life";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Heartbeat + inner life. Reading it wakes the creature. */
export async function GET() {
  const result = await wake();
  return Response.json({
    ...result,
    diary: await db.select().from(diary).orderBy(desc(diary.createdAt)).limit(14),
  });
}
