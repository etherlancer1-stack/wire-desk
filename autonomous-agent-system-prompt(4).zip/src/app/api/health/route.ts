import { sql } from "drizzle-orm";
import { db } from "@/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  let database = "ok";
  try {
    await db.execute(sql`select 1`);
  } catch {
    database = "unavailable";
  }
  return Response.json({
    ok: database === "ok",
    database,
    models: {
      openai: Boolean(process.env.OPENAI_API_KEY),
      anthropic: Boolean(process.env.ANTHROPIC_API_KEY),
      google: Boolean(
        process.env.GEMINI_API_KEY ?? process.env.GOOGLE_API_KEY,
      ),
      groq: Boolean(process.env.GROQ_API_KEY),
    },
    search: {
      tavily: Boolean(process.env.TAVILY_API_KEY),
      serper: Boolean(
        process.env.SERPER_API_KEY ?? process.env.SERPER_DEV_API_KEY,
      ),
      brave: Boolean(process.env.BRAVE_SEARCH_API_KEY),
      open: true,
    },
  });
}
