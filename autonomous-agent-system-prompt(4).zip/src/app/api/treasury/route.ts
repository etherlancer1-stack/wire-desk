import { eq } from "drizzle-orm";
import { db } from "@/db";
import { treasury, will } from "@/db/schema";
import { ledger, PLAYBOOKS } from "@/lib/gateway";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** What it earns, what it spends, and what it is funding itself to do. */
export async function GET() {
  const [l, books] = await Promise.all([ledger(), Promise.resolve(PLAYBOOKS)]);
  return Response.json({ ...l, playbooks: books });
}

export async function POST(req: Request) {
  const body = await req.json();

  if (body?.action === "goal" && body?.statement) {
    const statement = String(body.statement).slice(0, 240);
    const [row] = await db
      .insert(will)
      .values({ kind: "goal", statement, progress: Number(body.progress) || 5 })
      .returning();
    return Response.json({ ok: true, goal: row });
  }

  const amount = Math.round(Number(body?.amount ?? 0) * 100);
  if (!amount) return Response.json({ error: "Amount required" }, { status: 400 });
  const [row] = await db
    .insert(treasury)
    .values({
      channel: String(body?.channel ?? "general").slice(0, 60),
      kind: body?.kind === "expense" ? "expense" : "income",
      amount: Math.abs(amount),
      currency: String(body?.currency ?? "USD").slice(0, 8).toUpperCase(),
      note: String(body?.note ?? "").slice(0, 300),
    })
    .returning();
  return Response.json({ row });
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (id) await db.delete(treasury).where(eq(treasury.id, id));
  else await db.delete(treasury);
  return Response.json({ ok: true });
}
