import { eq } from "drizzle-orm";
import { db } from "@/db";
import { connections } from "@/db/schema";
import { CONNECTORS } from "@/lib/apps";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(connections);
  const byApp = new Map(rows.map((r) => [r.app, r]));
  const apps = CONNECTORS.map((c) => {
    const row = byApp.get(c.id);
    return {
      id: c.id,
      label: c.label,
      kind: c.kind,
      needs: c.needs,
      keyHint: c.keyHint,
      blurb: c.blurb,
      connected: c.needs === "none" ? true : Boolean(row?.apiKey),
      hasKey: Boolean(row?.apiKey),
      hits: row?.hits ?? 0,
      lastUsedAt: row?.lastUsedAt ?? null,
    };
  });
  return Response.json({ apps });
}

export async function POST(req: Request) {
  const body = await req.json();
  const app = String(body?.app ?? "");
  const connector = CONNECTORS.find((c) => c.id === app);
  if (!connector) return Response.json({ error: "Unknown app" }, { status: 404 });
  const apiKey = String(body?.apiKey ?? "").trim().slice(0, 400);
  const existing = await db.select().from(connections).where(eq(connections.app, app));
  if (existing.length) {
    await db
      .update(connections)
      .set({ apiKey, connected: 1, label: connector.label })
      .where(eq(connections.app, app));
  } else {
    await db.insert(connections).values({
      app,
      label: connector.label,
      apiKey,
      connected: 1,
    });
  }
  return Response.json({ ok: true, app, connected: Boolean(apiKey) || connector.needs === "none" });
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const app = url.searchParams.get("app");
  if (app) await db.delete(connections).where(eq(connections.app, app));
  return Response.json({ ok: true });
}
