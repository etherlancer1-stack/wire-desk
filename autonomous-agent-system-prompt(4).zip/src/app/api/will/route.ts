import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { will } from "@/db/schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(will).orderBy(desc(will.updatedAt)).limit(50);
  return Response.json({ will: rows });
}

export async function POST(req: Request) {
  const body = await req.json();
  const statement = String(body?.statement ?? "").trim().slice(0, 240);
  if (body?.id) {
    await db
      .update(will)
      .set({
        statement: statement || undefined,
        status: body.status === "done" || body.status === "active" ? body.status : undefined,
        progress: typeof body.progress === "number" ? Math.max(0, Math.min(100, body.progress)) : undefined,
        updatedAt: new Date(),
      })
      .where(eq(will.id, body.id));
    return Response.json({ ok: true });
  }
  if (!statement) return Response.json({ error: "Empty statement" }, { status: 400 });
  const [row] = await db
    .insert(will)
    .values({
      kind: ["goal", "value", "habit"].includes(body?.kind) ? body.kind : "goal",
      statement,
      progress: typeof body?.progress === "number" ? body.progress : 0,
    })
    .returning();
  return Response.json({ will: row });
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (id) await db.delete(will).where(eq(will.id, id));
  else await db.delete(will);
  return Response.json({ ok: true });
}
