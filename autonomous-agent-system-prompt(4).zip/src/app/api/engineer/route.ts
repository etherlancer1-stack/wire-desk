import { NextRequest } from "next/server";
import { analyzeCode, applyPatch, dailyCycle, history, readOwnCode, revertPatch, runUpgrade } from "@/lib/engineer";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** The resident engineer: its analysis, its patches, and the daily cycle. */
export async function GET() {
  const files = await readOwnCode();
  const analysis = analyzeCode(files);
  const { runs, patches } = await history();
  const cycle = await dailyCycle();
  return Response.json({
    analysis,
    runs,
    patches,
    daily: cycle,
    ownedFiles: files.map((f) => ({ file: f.file, lines: f.lines, bytes: f.bytes })),
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const action = String(body?.action ?? "upgrade");

    if (action === "upgrade") {
      const result = await runUpgrade();
      return Response.json({ ok: true, ...result });
    }
    if (action === "apply" && body?.id) {
      const result = await applyPatch(String(body.id));
      return Response.json(result);
    }
    if (action === "revert" && body?.id) {
      await revertPatch(String(body.id));
      return Response.json({ ok: true });
    }
    return Response.json({ error: "Unknown action" }, { status: 400 });
  } catch (err) {
    return Response.json(
      { ok: false, message: err instanceof Error ? err.message : "engineer error" },
      { status: 500 },
    );
  }
}
