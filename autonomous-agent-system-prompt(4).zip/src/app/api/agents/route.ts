import { NextRequest } from "next/server";
import { listAgents, removeAgent, runOwnAgent, saveAgent } from "@/lib/studio";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const { SKILLS, PRESETS, efficiency } = await import("@/lib/openjarvis");
  const { brainHealth } = await import("@/lib/life");
  const health = await brainHealth();
  const agents = await listAgents();
  return Response.json({
    agents,
    skills: SKILLS,
    presets: PRESETS,
    efficiency: efficiency({
      brainStats: Object.entries(health).map(([id, h]) => ({
        id,
        label: id,
        ok: h.ok,
        fail: h.fail,
        latencyMs: h.latencyMs,
        keyless: id === "ollama" || id === "openwire",
      })),
      turns: agents.reduce((a, b) => a + b.runs, 0),
    }),
  });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const action = String(body?.action ?? "save");

  // OpenJarvis presets: build a ready-to-run agent from the starter kits.
  if (action === "preset") {
    const { PRESETS } = await import("@/lib/openjarvis");
    const preset = PRESETS.find((p) => p.id === String(body?.id ?? ""));
    if (!preset) return Response.json({ error: "Unknown preset" }, { status: 404 });
    const agent = await saveAgent({
      name: preset.name,
      role: preset.role,
      instructions: preset.instructions,
      model: "auto",
      tools: preset.tools,
    });
    return Response.json({ agent, preset: preset.id });
  }

  if (action === "run") {
    const encoder = new TextEncoder();
    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        const push = (obj: unknown) =>
          controller.enqueue(encoder.encode(JSON.stringify(obj) + "\n"));
        try {
          let model = "";
          const { answer } = await runOwnAgent(String(body.id), String(body.message ?? ""), (t) =>
            push({ type: "token", text: t }),
          );
          push({ type: "done", model, answer });
        } catch (err) {
          push({ type: "error", message: err instanceof Error ? err.message : "agent failed" });
        } finally {
          controller.close();
        }
      },
    });
    return new Response(stream, {
      headers: {
        "Content-Type": "application/x-ndjson; charset=utf-8",
        "Cache-Control": "no-cache, no-transform",
      },
    });
  }

  if (action === "delete") {
    await removeAgent(String(body.id));
    return Response.json({ ok: true });
  }

  const agent = await saveAgent({
    id: body?.id ? String(body.id) : undefined,
    name: String(body?.name ?? ""),
    role: String(body?.role ?? ""),
    instructions: String(body?.instructions ?? ""),
    model: String(body?.model ?? "auto"),
    tools: String(body?.tools ?? "web,memory"),
  });
  return Response.json({ agent });
}
