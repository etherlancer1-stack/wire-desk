import { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { connections } from "@/db/schema";
import { connectApp, ECOSYSTEM, gatewayStatus, slugify } from "@/lib/gateway";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** The 300-app ecosystem: master keys, per-app credentials, live status. */
export async function GET(req: NextRequest) {
  const filter = req.nextUrl.searchParams.get("q") ?? "";
  const apps = await gatewayStatus(filter);
  return Response.json({
    ecosystem: ECOSYSTEM,
    apps,
    total: apps.length,
    connected: apps.filter((a) => a.connected).length,
  });
}

export async function POST(req: Request) {
  const body = await req.json();
  const name = String(body?.name ?? "");
  const slug = body?.slug ? String(body.slug) : slugify(name);
  if (!slug) return Response.json({ error: "Missing app" }, { status: 400 });
  await connectApp(slug, name || slug, String(body?.key ?? "").slice(0, 500));
  return Response.json({ ok: true, slug, connected: Boolean(String(body?.key ?? "")) });
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const slug = url.searchParams.get("slug");
  if (slug) await db.delete(connections).where(eq(connections.app, slug));
  return Response.json({ ok: true });
}
