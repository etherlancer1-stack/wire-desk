import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { memories } from "@/db/schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(memories).orderBy(desc(memories.updatedAt)).limit(300);
  return Response.json({ memories: rows });
}

export async function POST(req: Request) {
  const body = await req.json();
  const content = String(body?.content ?? "").trim().slice(0, 240);
  if (!content) return Response.json({ error: "Empty memory" }, { status: 400 });
  const [row] = await db
    .insert(memories)
    .values({
      kind: ["fact", "preference", "correction", "skill", "identity"].includes(body?.kind)
        ? body.kind
        : "fact",
      content,
      detail: String(body?.detail ?? "").slice(0, 200),
      pinned: body?.pinned ? 1 : 0,
      weight: 3,
      source: "manual",
    })
    .returning();
  return Response.json({ memory: row });
}

export async function PATCH(req: Request) {
  const body = await req.json();
  if (!body?.id) return Response.json({ error: "Missing id" }, { status: 400 });
  await db
    .update(memories)
    .set({
      pinned: body.pinned === undefined ? undefined : body.pinned ? 1 : 0,
      content: body.content ? String(body.content).slice(0, 240) : undefined,
      updatedAt: new Date(),
    })
    .where(eq(memories.id, body.id));
  return Response.json({ ok: true });
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (id) await db.delete(memories).where(eq(memories.id, id));
  else await db.delete(memories);
  return Response.json({ ok: true });
}
