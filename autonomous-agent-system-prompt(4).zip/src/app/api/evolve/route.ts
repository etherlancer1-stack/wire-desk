import { desc } from "drizzle-orm";
import { db } from "@/db";
import { codex } from "@/db/schema";
import { activeCodex, codexHistory, evolve, evidence, revertCodex, reviveCodex } from "@/lib/evolve";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** The desk's own code, its version history, and the button that rewrites it. */
export async function GET() {
  const [active, history, ev] = await Promise.all([
    activeCodex(),
    codexHistory(),
    evidence(),
  ]);
  return Response.json({ active, history, evidence: ev });
}

export async function POST(req: Request) {
  const body = await req.json();
  const action = String(body?.action ?? "evolve");

  if (action === "evolve") {
    const result = await evolve();
    return Response.json({ ok: true, ...result });
  }
  if (action === "revert" && body?.id) {
    await revertCodex(String(body.id));
    return Response.json({ ok: true });
  }
  if (action === "revive" && body?.id) {
    await reviveCodex(String(body.id));
    return Response.json({ ok: true });
  }
  if (action === "rewrite" && body?.content) {
    const active = await activeCodex();
    for (const e of active) await revertCodex(e.id);
    const { codex: table } = await import("@/db/schema");
    await db.insert(table).values({
      kind: "rule",
      content: String(body.content).slice(0, 500),
      note: "written by hand",
      version: active.length + 1,
    });
    return Response.json({ ok: true });
  }
  return Response.json({ error: "Unknown action" }, { status: 400 });
}
