import type { Metadata } from "next";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import "./globals.css";

const BASE = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(BASE),
  title: {
    default: "WIRE — the AI answer desk that reads the live web",
    template: "%s · WIRE",
  },
  description:
    "Ask anything. WIRE searches the live internet, reads the pages it finds, and answers in clean prose with every claim traced back to its source — and it remembers, learns and builds.",
  keywords: [
    "AI answer engine",
    "AI with citations",
    "autonomous AI agent",
    "AI website builder",
    "WIRE",
  ],
  openGraph: {
    title: "WIRE — the answer desk that reads the live web",
    description:
      "Live web grounding, real citations, memory that grows, and a builder that publishes private sites.",
    url: BASE,
    siteName: "WIRE",
    type: "website",
  },
  twitter: { card: "summary_large_image", title: "WIRE", description: "Ask anything. It reads the wire first." },
  robots: { index: true, follow: true },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className="font-serif">
        <div
          aria-hidden
          className="pointer-events-none fixed inset-0 z-50 opacity-[0.32] mix-blend-multiply"
          style={{
            backgroundImage: "url('images/paper.jpg')",
            backgroundSize: "620px",
          }}
        />
        <ErrorBoundary label="The desk">
          {children}
        </ErrorBoundary>
      </body>
    </html>
  );
}
