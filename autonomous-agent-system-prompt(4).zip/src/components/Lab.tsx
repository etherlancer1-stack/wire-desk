"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Icon } from "./icons";
import { PanelHead } from "./Panels";
import { BRAINS } from "@/lib/mesh";

/* ------------------------------ agent studio ---------------------------- */

type AgentRow = {
  id: string;
  name: string;
  role: string;
  instructions: string;
  model: string;
  tools: string;
  runs: number;
};

type Preset = {
  id: string;
  name: string;
  mode: string;
  about: string;
  role: string;
};
type Skill = { id: string; name: string; category: string; source: string; about: string; invoke: string };
type Efficiency = {
  avgLatencyMs: number;
  fastestBrain: string;
  localShare: number;
  estimatedCostPerTurn: number;
  intelligencePerWatt: number;
  note: string;
};

export function AgentsPanel() {
  const [agents, setAgents] = useState<AgentRow[]>([]);
  const [presets, setPresets] = useState<Preset[]>([]);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [eff, setEff] = useState<Efficiency | null>(null);
  const [form, setForm] = useState({
    id: "",
    name: "",
    role: "",
    instructions: "",
    model: "auto",
    tools: "web,memory",
  });
  const [selected, setSelected] = useState<string>("");
  const [message, setMessage] = useState("");
  const [answer, setAnswer] = useState("");
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");

  const load = useCallback(() => {
    fetch("/api/agents")
      .then((r) => r.json())
      .then((d) => {
        setAgents(d.agents ?? []);
        setPresets(d.presets ?? []);
        setSkills(d.skills ?? []);
        setEff(d.efficiency ?? null);
      })
      .catch(() => setAgents([]));
  }, []);

  const usePreset = async (id: string) => {
    const d = await fetch("/api/agents", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "preset", id }),
    }).then((r) => r.json());
    if (d.agent) {
      setNote(`Preset “${d.agent.name}” built and ready to run.`);
      setSelected(d.agent.id);
      load();
    }
  };

  useEffect(() => {
    load();
  }, [load]);

  const save = async () => {
    const d = await fetch("/api/agents", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "save", ...form }),
    }).then((r) => r.json());
    if (d.agent) {
      setNote(`Saved ${d.agent.name}.`);
      setSelected(d.agent.id);
      setForm({ id: "", name: "", role: "", instructions: "", model: "auto", tools: "web,memory" });
      load();
    }
  };

  const run = async () => {
    if (!selected || !message.trim() || busy) return;
    setBusy(true);
    setAnswer("");
    try {
      const res = await fetch("/api/agents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "run", id: selected, message }),
      });
      const reader = res.body?.getReader();
      const dec = new TextDecoder();
      let buf = "";
      while (reader) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const e = JSON.parse(line);
            if (e.type === "token") setAnswer((a) => a + e.text);
            if (e.type === "error") setNote(e.message);
          } catch {
            /* partial */
          }
        }
      }
    } catch {
      setNote("The agent did not respond.");
    }
    setBusy(false);
    setMessage("");
    load();
  };

  return (
    <div>
      <PanelHead
        slug={`Agent studio · ${agents.length} agents built`}
        title="Build your own AI agents"
        lede="This is a factory for agents. Give one a name, a role and standing instructions — it gets its own memory, its own model and its own tools, runs from this screen or from chat, and keeps its run count in the database. The desk itself is just the first agent built here."
      />

      {note && (
        <p className="slug mt-4 border-l-2 border-wire py-2 pl-4 leading-[1.9] text-wire">{note}</p>
      )}

      {/* ---------------------- OpenJarvis integration ------------------ */}
      <div className="mt-8 rounded-2xl border border-rule bg-paper-2/40 px-5 py-5">
        <div className="flex flex-wrap items-center gap-3">
          <h2 className="text-[16px] font-bold tracking-[-0.015em]">
            Built on the OpenJarvis architecture
          </h2>
          <a
            href="https://github.com/open-jarvis/OpenJarvis"
            target="_blank"
            rel="noreferrer noopener"
            className="wire-chip"
          >
            Stanford SAIL · Apache 2.0 ↗
          </a>
        </div>
        <p className="mt-2 max-w-[80ch] text-[13px] leading-[1.65] text-ink-soft">
          Skills as first-class tools (agentskills.io), agent presets with
          on-demand / scheduled / continuous execution, local-first model
          routing, and evaluation that treats latency and cost as first-class
          constraints — not just accuracy.
        </p>

        {eff && (
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-5">
            {[
              ["Intelligence/watt", String(eff.intelligencePerWatt)],
              ["Avg latency", `${eff.avgLatencyMs}ms`],
              ["Fastest brain", eff.fastestBrain],
              ["Local share", `${eff.localShare}%`],
              ["Est. cost/turn", `$${eff.estimatedCostPerTurn}`],
            ].map(([k, v]) => (
              <div key={k} className="wire-tile">
                <div className="text-[17px] leading-none font-black tabular-nums">{v}</div>
                <div className="mt-1.5 text-[9px] font-semibold tracking-[0.13em] text-mute uppercase">
                  {k}
                </div>
              </div>
            ))}
          </div>
        )}
        {eff && <p className="mt-2.5 text-[11.5px] text-mute">{eff.note}</p>}

        <div className="mt-5">
          <div className="slug text-mute">OpenJarvis presets — one click to build</div>
          <div className="mt-2.5 flex flex-wrap gap-2">
            {presets.map((p) => (
              <button
                key={p.id}
                onClick={() => void usePreset(p.id)}
                title={p.about}
                className="wire-chip"
              >
                {p.name}
                <span className="opacity-60">{p.mode}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-5">
          <div className="slug text-mute">Skill catalog · {skills.length} skills</div>
          <div className="scroll-pane mt-2.5 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {skills.map((s) => (
              <div key={s.id} className="wire-tile">
                <div className="flex items-baseline gap-2">
                  <span className="font-mono text-[11.5px] font-semibold">{s.name}</span>
                  <span className="ml-auto text-[9px] font-semibold tracking-[0.12em] text-wire uppercase">
                    {s.category}
                  </span>
                </div>
                <p className="mt-1.5 text-[11.5px] leading-[1.5] text-ink-soft">{s.about}</p>
                <div className="mt-1.5 text-[10px] text-mute">
                  {s.source} · {s.invoke}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)]">
        <div>
          <div className="slug border-b border-ink pb-2 text-ink">
            {form.id ? "Edit agent" : "New agent"}
          </div>
          <div className="mt-4 space-y-3">
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Name — e.g. Research Analyst"
              className="w-full border border-rule bg-paper-2/50 px-3 py-2.5 font-serif text-[15px] text-ink placeholder:text-mute/70"
            />
            <input
              value={form.role}
              onChange={(e) => setForm({ ...form, role: e.target.value })}
              placeholder="Role — e.g. deep research and synthesis"
              className="w-full border border-rule bg-paper-2/50 px-3 py-2.5 font-serif text-[15px] text-ink placeholder:text-mute/70"
            />
            <textarea
              value={form.instructions}
              onChange={(e) => setForm({ ...form, instructions: e.target.value })}
              rows={5}
              placeholder="Standing instructions — how it thinks, what it must always do, what it must never do."
              className="w-full resize-y border border-rule bg-paper-2/50 px-3 py-2.5 font-serif text-[14.5px] leading-[1.6] text-ink placeholder:text-mute/70"
            />
            <div className="flex flex-wrap gap-2">
              <select
                value={form.model}
                onChange={(e) => setForm({ ...form, model: e.target.value })}
                className="slug border border-rule bg-paper-2/50 px-3 py-2.5 text-ink"
              >
                <option value="auto">model: auto</option>
                {BRAINS.map((b) => (
                  <option key={b.id} value={b.defaultModel}>
                    {b.label} · {b.defaultModel}
                  </option>
                ))}
              </select>
              <input
                value={form.tools}
                onChange={(e) => setForm({ ...form, tools: e.target.value })}
                placeholder="tools: web,memory"
                className="flex-1 border border-rule bg-paper-2/50 px-3 py-2.5 font-mono text-[12px] text-ink placeholder:text-mute/70"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => void save()}
                className="slug bg-wire px-5 py-2.5 text-paper hover:opacity-90"
              >
                {form.id ? "Update agent" : "Build agent"}
              </button>
              {form.id && (
                <button
                  onClick={() =>
                    setForm({ id: "", name: "", role: "", instructions: "", model: "auto", tools: "web,memory" })
                  }
                  className="slug border border-rule px-4 py-2.5 text-mute hover:border-ink hover:text-ink"
                >
                  Cancel
                </button>
              )}
            </div>

            <div className="pt-3">
              <div className="slug text-mute">Start from a template</div>
              <div className="mt-2 flex flex-wrap gap-2">
                {[
                  ["Research Analyst", "deep research and synthesis", "Investigate across primary sources, compare conflicting claims, give confidence levels.", "web,memory"],
                  ["Code Architect", "software design and review", "Design before writing. Show interfaces, then implementation, then tests.", "web,memory"],
                  ["Market Scout", "commercial opportunities", "Find problems people pay to solve; estimate effort versus return.", "web,memory"],
                  ["Tutor", "teaching and explanation", "Explain from first principles with worked examples.", "memory"],
                ].map(([name, role, instructions, tools]) => (
                  <button
                    key={name}
                    onClick={() => setForm({ id: "", name, role, instructions, model: "auto", tools })}
                    className="slug border border-rule px-3 py-1.5 text-mute hover:border-wire hover:text-wire"
                  >
                    + {name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="slug mt-9 border-b border-ink pb-2 text-ink">Your agents</div>
          <div className="mt-2">
            {agents.map((a) => (
              <div
                key={a.id}
                className={`flex items-center gap-3 border-b border-rule py-2.5 ${
                  selected === a.id ? "bg-paper-2/60" : ""
                }`}
              >
                <button
                  onClick={() => {
                    setSelected(a.id);
                    setForm({ ...a, instructions: a.instructions ?? "" });
                  }}
                  className="min-w-0 flex-1 text-left"
                >
                  <div className="truncate font-serif text-[15px] font-semibold">{a.name}</div>
                  <div className="slug text-mute">
                    {a.role} · {a.runs} runs
                  </div>
                </button>
                <button
                  onClick={() =>
                    void fetch("/api/agents", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ action: "delete", id: a.id }),
                    }).then(load)
                  }
                  className="slug text-mute hover:text-wire"
                >
                  remove
                </button>
              </div>
            ))}
            {!agents.length && (
              <p className="slug py-3 leading-[1.9] text-mute">
                No agents yet. Build one above — it will be running in seconds.
              </p>
            )}
          </div>
        </div>

        <div>
          <div className="slug border-b border-ink pb-2 text-ink">Talk to your agent</div>
          <div className="mt-4 flex items-center gap-2">
            <select
              value={selected}
              onChange={(e) => setSelected(e.target.value)}
              className="slug flex-1 border border-rule bg-paper-2/50 px-3 py-2.5 text-ink"
            >
              <option value="">select an agent…</option>
              {agents.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </select>
            <button
              onClick={() => void run()}
              disabled={!selected || busy}
              className="slug bg-wire px-4 py-2.5 text-paper hover:opacity-90 disabled:opacity-40"
            >
              {busy ? "Running…" : "Run"}
            </button>
          </div>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={3}
            placeholder="Give it a task…"
            className="mt-3 w-full resize-y border border-rule bg-paper-2/50 px-3 py-2.5 font-serif text-[15px] leading-[1.6] text-ink placeholder:text-mute/70"
          />
          {answer && (
            <pre className="mt-4 max-h-[420px] overflow-auto whitespace-pre-wrap rounded-xl border border-rule bg-paper-2/50 px-4 py-3 font-serif text-[14px] leading-[1.62] text-ink">
              {answer}
            </pre>
          )}
          <p className="slug mt-4 leading-[1.9] text-mute">
            Each agent runs on its own instructions and its own model, with the
            web available if its tools include it. Everything it does is
            recorded in its run count.
          </p>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------- security lab --------------------------- */

type Tool = { name: string; category: string; about: string; docs: string };
type Target = { id: string; name: string; host: string; scope: string; authorized: number };
type Finding = { severity: string; check: string; detail: string; fix: string };

export function SecurityPanel() {
  const [tools, setTools] = useState<Tool[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [installed, setInstalled] = useState<Record<string, boolean>>({});
  const [targets, setTargets] = useState<Target[]>([]);
  const [cat, setCat] = useState("all");
  const [host, setHost] = useState("");
  const [scope, setScope] = useState("owned");
  const [findings, setFindings] = useState<Finding[]>([]);
  const [summary, setSummary] = useState<{ high: number; medium: number; low: number; pass: number; score: number } | null>(null);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(() => {
    fetch("/api/security")
      .then((r) => r.json())
      .then((d) => {
        setTools(d.tools ?? []);
        setCategories(d.categories ?? []);
        setInstalled(d.installed ?? {});
        setTargets(d.targets ?? []);
      })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const addTarget = async () => {
    const d = await fetch("/api/security", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "add", host, scope, name: host }),
    }).then((r) => r.json());
    setNote(d.ok ? `${host} added to your authorized scope.` : d.error ?? "Could not add target.");
    setHost("");
    load();
  };

  const assessTarget = async (h: string) => {
    setBusy(true);
    setNote(`Assessing ${h} — non-destructive checks only…`);
    setFindings([]);
    setSummary(null);
    try {
      const d = await fetch("/api/security", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "assess", host: h }),
      }).then((r) => r.json());
      if (d.ok) {
        setFindings(d.findings ?? []);
        setSummary(d.summary ?? null);
        setNote(`Assessment complete for ${h}.`);
      } else {
        setNote(d.error ?? "Assessment refused.");
      }
    } catch {
      setNote("The assessment failed.");
    }
    setBusy(false);
  };

  const filtered = cat === "all" ? tools : tools.filter((t) => t.category === cat);

  return (
    <div>
      <PanelHead
        slug={`Security lab · ${tools.length} tools catalogued · authorized scope only`}
        title="Ethical security lab"
        lede="A Kali-aligned testing environment that stays inside the lines: only hosts you declare and authorize can be assessed, checks are non-destructive by default, and every tool is listed with its official documentation. Installation status is verified against this host — nothing here claims to be installed when it is not."
      />

      {note && (
        <p className="slug mt-4 border-l-2 border-wire py-2 pl-4 leading-[1.9] text-wire">{note}</p>
      )}

      <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <div>
          <div className="slug border-b border-ink pb-2 text-ink">Authorized scope</div>
          <p className="mt-3 font-serif text-[14px] leading-[1.6] text-ink-soft">
            Only systems you own or are explicitly permitted to test. Anything
            outside this list is refused by the server, whatever is typed into
            the chat.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <input
              value={host}
              onChange={(e) => setHost(e.target.value)}
              placeholder="yourdomain.com"
              className="min-w-[180px] flex-1 border border-rule bg-paper-2/50 px-3 py-2.5 font-mono text-[12px] text-ink placeholder:text-mute/70"
            />
            <select
              value={scope}
              onChange={(e) => setScope(e.target.value)}
              className="slug border border-rule bg-paper-2/50 px-3 py-2.5 text-ink"
            >
              <option value="owned">owned</option>
              <option value="staging">staging</option>
              <option value="lab">lab</option>
            </select>
            <button
              onClick={() => void addTarget()}
              className="slug bg-wire px-4 py-2.5 text-paper hover:opacity-90"
            >
              Authorize
            </button>
          </div>

          <div className="mt-5">
            {targets.map((t) => (
              <div key={t.id} className="flex items-center gap-3 border-b border-rule py-2.5">
                <div className="min-w-0 flex-1">
                  <div className="truncate font-mono text-[13px]">{t.host}</div>
                  <div className="slug text-mute">{t.scope} · authorized</div>
                </div>
                <button
                  onClick={() => void assessTarget(t.host)}
                  disabled={busy}
                  className="slug border border-ink px-3.5 py-2 hover:bg-wire hover:border-wire hover:text-paper disabled:opacity-40"
                >
                  Assess
                </button>
              </div>
            ))}
            {!targets.length && (
              <p className="slug py-3 leading-[1.9] text-mute">
                No authorized targets yet.
              </p>
            )}
          </div>

          {summary && (
            <div className="mt-7">
              <div className="slug border-b border-ink pb-2 text-ink">Assessment report</div>
              <div className="mt-4 grid grid-cols-5 gap-x-4">
                {[
                  ["Score", String(summary.score)],
                  ["High", String(summary.high)],
                  ["Medium", String(summary.medium)],
                  ["Low", String(summary.low)],
                  ["Pass", String(summary.pass)],
                ].map(([k, v]) => (
                  <div key={k} className="border-t border-ink pt-2">
                    <div className="slug text-mute">{k}</div>
                    <div className="mt-1 font-display text-[22px] leading-none font-black">{v}</div>
                  </div>
                ))}
              </div>
              <div className="mt-5 space-y-3">
                {findings.map((f, i) => (
                  <div key={i} className="border-t border-rule pt-2.5">
                    <div className="slug flex items-center gap-2 text-mute">
                      <span
                        className={
                          f.severity === "high"
                            ? "text-wire"
                            : f.severity === "pass"
                              ? "text-mute"
                              : "text-ink"
                        }
                      >
                        {f.severity}
                      </span>
                      <span className="text-rule">/</span>
                      <span className="truncate">{f.check}</span>
                    </div>
                    <p className="mt-1.5 font-serif text-[14px] leading-[1.5]">{f.detail}</p>
                    {f.fix && (
                      <p className="mt-1 font-serif text-[12.5px] leading-[1.5] text-ink-soft italic">
                        Fix: {f.fix}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div>
          <div className="slug border-b border-ink pb-2 text-ink">
            Kali tool catalogue · {filtered.length}
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {["all", ...categories].map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`slug rounded-full border px-3 py-1.5 transition-colors ${
                  cat === c
                    ? "border-wire bg-wire text-paper"
                    : "border-rule text-mute hover:border-ink hover:text-ink"
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="mt-5 space-y-3">
            {filtered.map((t) => (
              <div key={t.name} className="border-t border-rule pt-2.5">
                <div className="flex items-baseline gap-2">
                  <span className="font-mono text-[13px] font-semibold">{t.name}</span>
                  <span className="slug text-mute">{t.category}</span>
                  <span
                    className={`slug ml-auto ${
                      installed[t.name] ? "text-wire" : "text-mute/70"
                    }`}
                  >
                    {installed[t.name] ? "verified on host" : "not installed here"}
                  </span>
                </div>
                <p className="mt-1.5 font-serif text-[13px] leading-[1.5] text-ink-soft">{t.about}</p>
                <a
                  href={t.docs}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="slug mt-1 inline-flex items-center gap-1 text-mute hover:text-wire"
                >
                  official docs <Icon name="send" className="h-2.5 w-2.5" />
                </a>
              </div>
            ))}
          </div>

          <p className="slug mt-8 leading-[1.9] text-mute">
            The heavy offensive tooling runs on an isolated Kali VM or security
            server — never on the production box that serves your desk. Invasive
            testing requires explicit authorization per target and is logged.
          </p>
        </div>
      </div>
    </div>
  );
}
