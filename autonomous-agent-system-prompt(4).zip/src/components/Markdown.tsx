"use client";

import React from "react";

/**
 * Small editorial markdown renderer.
 * Handles the subset WIRE emits: headings, lists, quotes, tables, code fences,
 * inline emphasis/links, and `[n]` citation markers rendered as hanging
 * superscripts that light up their wire card.
 */

type CiteFn = (n: number) => void;

const INLINE =
  /(\*\*[^*]+\*\*|`[^`]+`|!\[[^\]]*\]\([^)\s]+\)|\[[^\]]+\]\([^)\s]+\)|\[(\d{1,2})\]|\*[^*\n]+\*)/g;

function inline(text: string, keyBase: string, onCite?: CiteFn): React.ReactNode[] {
  const out: React.ReactNode[] = [];
  let last = 0;
  let m: RegExpExecArray | null;
  INLINE.lastIndex = 0;
  while ((m = INLINE.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index));
    const tok = m[0];
    const k = `${keyBase}-${m.index}`;
    if (tok.startsWith("**")) {
      out.push(<strong key={k}>{tok.slice(2, -2)}</strong>);
    } else if (tok.startsWith("`")) {
      out.push(<code key={k}>{tok.slice(1, -1)}</code>);
    } else if (tok.startsWith("![")) {
      const img = /!\[([^\]]*)\]\(([^)\s]+)\)/.exec(tok);
      if (img) {
        out.push(
          <img
            key={k}
            src={img[2]}
            alt={img[1] || "generated"}
            loading="lazy"
            className="mt-4 w-full rounded-xl border border-rule"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = "none";
            }}
          />,
        );
      }
    } else if (tok.startsWith("[")) {
      const cite = m[2];
      if (cite) {
        const n = Number(cite);
        out.push(
          <button
            key={k}
            type="button"
            onClick={() => onCite?.(n)}
            title={`Source ${n}`}
            className="mx-[0.12em] align-super font-mono text-[0.62em] font-semibold tracking-[0.06em] text-wire transition-colors hover:bg-wire hover:text-paper"
          >
            {n}
          </button>,
        );
      } else {
        const link = /\[([^\]]+)\]\(([^)\s]+)\)/.exec(tok);
        if (link) {
          out.push(
            <a key={k} href={link[2]} target="_blank" rel="noreferrer noopener">
              {link[1]}
            </a>,
          );
        }
      }
    } else if (tok.startsWith("*")) {
      out.push(<em key={k}>{tok.slice(1, -1)}</em>);
    }
    last = m.index + tok.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

function splitRow(line: string): string[] {
  return line
    .replace(/^\||\|$/g, "")
    .split("|")
    .map((c) => c.trim());
}

export function Markdown({
  text,
  onCite,
}: {
  text: string;
  onCite?: CiteFn;
}) {
  const blocks: React.ReactNode[] = [];
  // Models love LaTeX markup; on paper it reads as noise. Turn inline math into
  // code spans and display math into a typeset equation panel.
  const normalized = text
    .replace(/\\\(([\s\S]*?)\\\)/g, (_m, inner: string) => `\`${inner.trim()}\``)
    .replace(/\\\[([\s\S]*?)\\\]/g, (_m, inner: string) => `\n\`\`\`\n${inner.trim()}\n\`\`\`\n`)
    .replace(/\$\$([\s\S]*?)\$\$/g, (_m, inner: string) => `\n\`\`\`\n${inner.trim()}\n\`\`\`\n`)
    .replace(/\$([^$\n]{1,60})\$/g, (_m, inner: string) => `\`${inner}\``);
  const lines = normalized.replace(/\r/g, "").split("\n");
  let i = 0;
  let key = 0;

  while (i < lines.length) {
    const line = lines[i];

    // fenced code
    if (/^\s*```/.test(line)) {
      const lang = line.replace(/^\s*```/, "").trim();
      const buf: string[] = [];
      i++;
      while (i < lines.length && !/^\s*```/.test(lines[i])) buf.push(lines[i++]);
      i++;
      blocks.push(
        <pre key={key++}>
          {lang ? (
            <span className="slug absolute right-3 text-paper/40">{lang}</span>
          ) : null}
          <code>{buf.join("\n")}</code>
        </pre>,
      );
      continue;
    }

    // heading
    const h = /^(#{1,4})\s+(.*)$/.exec(line);
    if (h) {
      const level = h[1].length;
      const content = inline(h[2], `h${key}`, onCite);
      if (level <= 2) blocks.push(<h2 key={key++}>{content}</h2>);
      else blocks.push(<h3 key={key++}>{content}</h3>);
      i++;
      continue;
    }

    // horizontal rule
    if (/^\s*([-*_])\1{2,}\s*$/.test(line)) {
      blocks.push(<div key={key++} className="hairline my-7" />);
      i++;
      continue;
    }

    // table
    if (line.trim().startsWith("|") && /^\s*\|[\s:|-]+\|\s*$/.test(lines[i + 1] ?? "")) {
      const head = splitRow(line);
      i += 2;
      const rows: string[][] = [];
      while (i < lines.length && lines[i].trim().startsWith("|")) rows.push(splitRow(lines[i++]));
      blocks.push(
        <table key={key++}>
          <thead>
            <tr>
              {head.map((c, ci) => (
                <th key={ci}>{inline(c, `th${key}${ci}`, onCite)}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, ri) => (
              <tr key={ri}>
                {r.map((c, ci) => (
                  <td key={ci}>{inline(c, `td${key}${ri}${ci}`, onCite)}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>,
      );
      continue;
    }

    // blockquote
    if (/^\s*>\s?/.test(line)) {
      const buf: string[] = [];
      while (i < lines.length && /^\s*>\s?/.test(lines[i]))
        buf.push(lines[i++].replace(/^\s*>\s?/, ""));
      blocks.push(
        <blockquote key={key++}>{inline(buf.join(" "), `q${key}`, onCite)}</blockquote>,
      );
      continue;
    }

    // lists
    if (/^\s*([-*•]|\d+[.)])\s+/.test(line)) {
      const ordered = /^\s*\d+[.)]\s+/.test(line);
      const items: string[] = [];
      while (i < lines.length && /^\s*([-*•]|\d+[.)])\s+/.test(lines[i])) {
        items.push(lines[i++].replace(/^\s*([-*•]|\d+[.)])\s+/, ""));
      }
      const ListTag = ordered ? "ol" : "ul";
      blocks.push(
        <ListTag key={key++}>
          {items.map((it, ii) => (
            <li key={ii}>{inline(it, `l${key}${ii}`, onCite)}</li>
          ))}
        </ListTag>,
      );
      continue;
    }

    // paragraph
    if (line.trim()) {
      const buf: string[] = [];
      while (
        i < lines.length &&
        lines[i].trim() &&
        !/^\s*([-*•]|\d+[.)])\s+/.test(lines[i]) &&
        !/^\s*(#|>|```|\|)/.test(lines[i])
      ) {
        buf.push(lines[i++]);
      }
      blocks.push(<p key={key++}>{inline(buf.join(" "), `p${key}`, onCite)}</p>);
      continue;
    }

    i++;
  }

  return <>{blocks}</>;
}
