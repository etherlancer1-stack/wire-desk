"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Icon } from "./icons";

/* Shared section header — every panel reads as a section of the same paper. */
export function PanelHead({
  slug,
  title,
  lede,
  action,
}: {
  slug: string;
  title: string;
  lede: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="relative pb-7">
      <div className="flex items-center gap-2">
        <span className="h-[6px] w-[6px] rounded-full bg-wire" />
        <div className="slug font-semibold tracking-[0.12em] text-wire uppercase">{slug}</div>
      </div>
      <div className="mt-3 flex flex-wrap items-end justify-between gap-4">
        <h1 className="max-w-[22ch] text-[clamp(28px,3.6vw,42px)] leading-[1.03] font-black tracking-[-0.032em]">
          {title}
        </h1>
        {action}
      </div>
      <p className="mt-3.5 max-w-[68ch] text-[15px] leading-[1.68] text-ink-soft">{lede}</p>
      <div className="mt-6 h-px w-full bg-gradient-to-r from-ink via-rule to-transparent" />
    </div>
  );
}

/* --------------------------------- apps --------------------------------- */

type AppRow = {
  id: string;
  label: string;
  kind: string;
  needs: string;
  keyHint: string;
  blurb: string;
  connected: boolean;
  hasKey: boolean;
  hits: number;
  lastUsedAt: string | null;
};

export function AppsPanel() {
  const [apps, setApps] = useState<AppRow[]>([]);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState<string | null>(null);

  const load = useCallback(() => {
    fetch("/api/apps")
      .then((r) => r.json())
      .then((d) => setApps(d.apps ?? []))
      .catch(() => setApps([]));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const connect = async (id: string) => {
    setSaving(id);
    await fetch("/api/apps", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ app: id, apiKey: drafts[id] ?? "" }),
    }).catch(() => {});
    setSaving(null);
    load();
  };

  const disconnect = async (id: string) => {
    await fetch(`/api/apps?app=${encodeURIComponent(id)}`, { method: "DELETE" }).catch(() => {});
    load();
  };

  return (
    <div>
      <PanelHead
        slug="Connected apps · the desk works through them"
        title="App switchboard"
        lede="Every connector below is a live tool the desk can call while it answers — Google, the open web, Wikipedia, GitHub, Stack Overflow, arXiv, world news, live weather, places and currency. The ones with keys become full strength; the rest already work."
      />

      <div className="mt-8 overflow-x-auto">
        <table className="w-full min-w-[720px] border-collapse">
          <thead>
            <tr className="border-b border-ink">
              <th className="slug pb-2 pr-4 text-left text-mute">App</th>
              <th className="slug pb-2 pr-4 text-left text-mute">Kind</th>
              <th className="slug pb-2 pr-4 text-left text-mute">Status</th>
              <th className="slug pb-2 pr-4 text-left text-mute">Calls made</th>
              <th className="slug pb-2 text-left text-mute">Key</th>
            </tr>
          </thead>
          <tbody>
            {apps.map((a) => (
              <tr
                key={a.id}
                className="group border-b border-rule align-top transition-colors hover:bg-paper-2/50"
              >
                <td className="py-4 pr-4">
                  <div className="font-display text-[17px] leading-tight font-semibold">
                    {a.label}
                  </div>
                  <p className="mt-1.5 max-w-[38ch] font-serif text-[13px] leading-[1.5] text-mute">
                    {a.blurb}
                  </p>
                </td>
                <td className="slug py-4 pr-4 text-ink-soft">{a.kind}</td>
                <td className="py-4 pr-4">
                  <span
                    className={`slug inline-block border px-2 py-1 ${
                      a.connected
                        ? "border-wire text-wire"
                        : "border-rule text-mute"
                    }`}
                  >
                    {a.connected ? "connected" : "needs key"}
                  </span>
                </td>
                <td className="slug tnum py-4 pr-4 text-ink-soft">
                  {a.hits}
                  <div className="mt-1 text-mute/80">
                    {a.lastUsedAt ? new Date(a.lastUsedAt).toLocaleDateString() : "—"}
                  </div>
                </td>
                <td className="py-4">
                  {a.needs === "key" ? (
                    <div className="flex items-center gap-2">
                      <input
                        type="password"
                        value={drafts[a.id] ?? ""}
                        onChange={(e) => setDrafts({ ...drafts, [a.id]: e.target.value })}
                        placeholder={a.hasKey ? "••••••••" : a.keyHint}
                        className="w-[190px] border border-rule bg-paper-2/50 px-2.5 py-2 font-mono text-[11.5px] text-ink placeholder:text-mute/70"
                      />
                      <button
                        onClick={() => void connect(a.id)}
                        className="slug border border-ink px-2.5 py-2 transition-colors hover:bg-wire hover:border-wire hover:text-paper"
                      >
                        {saving === a.id ? "…" : a.hasKey ? "Update" : "Connect"}
                      </button>
                      {a.hasKey && (
                        <button
                          onClick={() => void disconnect(a.id)}
                          className="slug px-1.5 py-2 text-mute hover:text-wire"
                        >
                          Drop
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="slug text-mute">{a.keyHint}</div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="slug mt-6 leading-[1.9] text-mute">
        Keys are held on this server for your desk only, sent solely to the app
        they belong to, and never shown again after saving.
      </p>
    </div>
  );
}

/* -------------------------------- memory -------------------------------- */

type MemoryRow = {
  id: string;
  kind: string;
  content: string;
  detail: string;
  weight: number;
  uses: number;
  pinned: number;
  source: string;
  updatedAt: string;
};

export function MemoryPanel() {
  const [rows, setRows] = useState<MemoryRow[]>([]);
  const [kind, setKind] = useState("fact");
  const [content, setContent] = useState("");

  const load = useCallback(() => {
    fetch("/api/memory")
      .then((r) => r.json())
      .then((d) => setRows(d.memories ?? []))
      .catch(() => setRows([]));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const add = async () => {
    if (!content.trim()) return;
    await fetch("/api/memory", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, content }),
    }).catch(() => {});
    setContent("");
    load();
  };

  const patch = async (id: string, body: Record<string, unknown>) => {
    await fetch("/api/memory", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, ...body }),
    }).catch(() => {});
    load();
  };

  const counts = rows.reduce<Record<string, number>>((acc, r) => {
    acc[r.kind] = (acc[r.kind] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <div>
      <PanelHead
        slug={`Memory · ${rows.length} things learned`}
        title="What it knows about you"
        lede="This is the desk's long-term memory. It fills itself from every conversation — names, preferences, corrections, working habits — and every entry here is injected into future answers. Pin what matters, delete what shouldn't be remembered."
        action={
          <div className="slug flex flex-wrap gap-2 text-mute">
            {Object.entries(counts).map(([k, v]) => (
              <span key={k} className="border border-rule px-2 py-1">
                {k} · {v}
              </span>
            ))}
          </div>
        }
      />

      <div className="mt-7 flex flex-wrap items-center gap-3 border border-rule bg-paper-2/50 px-4 py-3">
        <select
          value={kind}
          onChange={(e) => setKind(e.target.value)}
          className="slug border border-rule bg-paper px-2.5 py-2 text-ink"
        >
          <option value="fact">fact</option>
          <option value="knowledge">knowledge</option>
          <option value="preference">preference</option>
          <option value="correction">correction</option>
          <option value="skill">skill</option>
          <option value="identity">identity</option>
        </select>
        <input
          value={content}
          onChange={(e) => setContent(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && void add()}
          placeholder="Teach it something — “I prefer answers under 200 words”"
          className="min-w-[240px] flex-1 border border-rule bg-paper px-3 py-2 font-serif text-[15px] text-ink placeholder:text-mute/70"
        />
        <button
          onClick={() => void add()}
          className="slug bg-wire px-4 py-2.5 text-paper hover:opacity-90"
        >
          Teach
        </button>
      </div>

      <div className="mt-8 columns-1 gap-8 lg:columns-2">
        {rows.map((r) => (
          <div
            key={r.id}
            className="mb-5 break-inside-avoid border-t border-rule pt-3"
          >
            <div className="slug flex items-center gap-2 text-mute">
              <span
                className={
                  r.kind === "correction"
                    ? "text-wire"
                    : r.kind === "identity"
                      ? "text-ink"
                      : "text-ink-soft"
                }
              >
                {r.kind}
              </span>
              <span className="text-rule">/</span>
              <span className="tnum">used {r.uses}×</span>
              <span className="text-rule">/</span>
              <span className="tnum">w{r.weight}</span>
              <span className="ml-auto flex items-center gap-2">
                <button
                  onClick={() => void patch(r.id, { pinned: !r.pinned })}
                  className={`slug ${r.pinned ? "text-wire" : "text-mute hover:text-ink"}`}
                >
                  {r.pinned ? "pinned" : "pin"}
                </button>
                <button
                  onClick={() =>
                    void fetch(`/api/memory?id=${r.id}`, { method: "DELETE" }).then(load)
                  }
                  className="slug text-mute hover:text-wire"
                >
                  forget
                </button>
              </span>
            </div>
            <p className="mt-2 font-serif text-[15.5px] leading-[1.55] text-ink">
              {r.content}
            </p>
            {r.detail && (
              <p className="mt-1.5 font-serif text-[12.5px] leading-[1.5] text-mute italic">
                {r.detail}
              </p>
            )}
          </div>
        ))}
        {rows.length === 0 && (
          <p className="slug leading-[1.9] text-mute">
            No memories yet. Ask it something, correct it once, and this page
            starts filling itself.
          </p>
        )}
      </div>
    </div>
  );
}

/* --------------------------------- will --------------------------------- */

type WillRow = {
  id: string;
  kind: string;
  statement: string;
  status: string;
  progress: number;
  updatedAt: string;
};

export function WillPanel() {
  const [rows, setRows] = useState<WillRow[]>([]);
  const [statement, setStatement] = useState("");
  const [kind, setKind] = useState("goal");

  const load = useCallback(() => {
    fetch("/api/will")
      .then((r) => r.json())
      .then((d) => setRows(d.will ?? []))
      .catch(() => setRows([]));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const add = async () => {
    if (!statement.trim()) return;
    await fetch("/api/will", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, statement }),
    }).catch(() => {});
    setStatement("");
    load();
  };

  const update = async (id: string, body: Record<string, unknown>) => {
    await fetch("/api/will", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, ...body }),
    }).catch(() => {});
    load();
  };

  return (
    <div>
      <PanelHead
        slug="Standing will · goals it acts on"
        title="Its own will"
        lede="These are the desk's standing orders to itself. They are injected into every answer, so it works toward them on its own — sharper sourcing, shorter answers, whatever you set. Give it a value and it will hold itself to it."
      />

      <div className="mt-7 flex flex-wrap items-center gap-3 border border-rule bg-paper-2/50 px-4 py-3">
        <select
          value={kind}
          onChange={(e) => setKind(e.target.value)}
          className="slug border border-rule bg-paper px-2.5 py-2 text-ink"
        >
          <option value="goal">goal</option>
          <option value="value">value</option>
          <option value="habit">habit</option>
        </select>
        <input
          value={statement}
          onChange={(e) => setStatement(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && void add()}
          placeholder="Set a standing order — “Never pad an answer past what the question needs”"
          className="min-w-[240px] flex-1 border border-rule bg-paper px-3 py-2 font-serif text-[15px] text-ink placeholder:text-mute/70"
        />
        <button
          onClick={() => void add()}
          className="slug bg-wire px-4 py-2.5 text-paper hover:opacity-90"
        >
          Commit
        </button>
      </div>

      <div className="mt-9 space-y-7">
        {rows.map((r) => (
          <div key={r.id} className="border-t border-ink pt-4">
            <div className="slug flex items-center gap-2 text-mute">
              <span className="text-wire">{r.kind}</span>
              <span className="text-rule">/</span>
              <span className={r.status === "done" ? "text-ink-soft" : "text-ink"}>
                {r.status}
              </span>
              <span className="ml-auto flex items-center gap-2">
                <button
                  onClick={() =>
                    void update(r.id, { progress: Math.min(100, r.progress + 10) })
                  }
                  className="slug text-mute hover:text-wire"
                >
                  +10%
                </button>
                <button
                  onClick={() =>
                    void update(r.id, {
                      status: r.status === "done" ? "active" : "done",
                      progress: r.status === "done" ? 0 : 100,
                    })
                  }
                  className="slug text-mute hover:text-wire"
                >
                  {r.status === "done" ? "reopen" : "complete"}
                </button>
                <button
                  onClick={() =>
                    void fetch(`/api/will?id=${r.id}`, { method: "DELETE" }).then(load)
                  }
                  className="slug text-mute hover:text-wire"
                >
                  drop
                </button>
              </span>
            </div>
            <p
              className={`mt-2.5 font-display text-[19px] leading-[1.32] font-semibold ${
                r.status === "done" ? "text-mute line-through" : "text-ink"
              }`}
            >
              {r.statement}
            </p>
            <div className="mt-3 flex items-center gap-3">
              <div className="h-[3px] flex-1 bg-rule">
                <div
                  className="h-full bg-wire transition-all duration-500"
                  style={{ width: `${r.progress}%` }}
                />
              </div>
              <span className="slug tnum text-mute">{r.progress}%</span>
            </div>
          </div>
        ))}
        {rows.length === 0 && (
          <p className="slug leading-[1.9] text-mute">
            No standing will yet. Set one above — or tell it in plain words,
            “from now on always cite the date of every source”, and it will keep
            that as a habit.
          </p>
        )}
      </div>
    </div>
  );
}

/* ------------------------------- commands ------------------------------- */

type Cmd = { name: string; args: string; about: string; example: string };

export function CommandConsole() {
  const [cmds, setCmds] = useState<Cmd[]>([]);
  const [input, setInput] = useState("");
  const [output, setOutput] = useState<string>("");
  const [title, setTitle] = useState("Ready.");
  const [busy, setBusy] = useState(false);
  const [ok, setOk] = useState(true);

  useEffect(() => {
    fetch("/api/commands")
      .then((r) => r.json())
      .then((d) => setCmds(d.commands ?? []))
      .catch(() => setCmds([]));
  }, []);

  const run = async (value?: string) => {
    const command = (value ?? input).trim();
    if (!command) return;
    setBusy(true);
    setOutput("");
    setTitle("Running…");
    try {
      const d = await fetch("/api/commands", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ input: command }),
      }).then((r) => r.json());
      setTitle(d.result?.title ?? "Result");
      setOutput(d.result?.output ?? "");
      setOk(Boolean(d.result?.ok));
    } catch {
      setTitle("Console error");
      setOutput("The command deck did not respond.");
      setOk(false);
    }
    setBusy(false);
    setInput("");
  };

  return (
    <div>
      <PanelHead
        slug="Command deck · deterministic tools"
        title="Commands & ciphers"
        lede="The desk is an operator, not only a writer. Hashing, encoding, cipher identification, JWT inspection, password entropy, regex, JSON, arithmetic and timestamps — all computed here, in-process, no shell and no data leaving the desk."
      />

      <div className="mt-8 grid gap-8 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div>
          <div className="flex items-center gap-3 border border-ink bg-panel px-4 py-3">
            <span className="slug text-wire">wire ▸</span>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && void run()}
              placeholder="/crack 57495245206465736b"
              className="flex-1 bg-transparent font-mono text-[13.5px] text-paper placeholder:text-paper/45 focus:outline-none"
            />
            <button
              onClick={() => void run()}
              disabled={busy}
              className="slug bg-wire px-3.5 py-2 text-paper disabled:opacity-40"
            >
              {busy ? "…" : "Run"}
            </button>
          </div>

          <div className="mt-5 border-t border-ink pt-4">
            <div className="slug flex items-center gap-2">
              <span className={ok ? "text-wire" : "text-mute"}>{ok ? "●" : "○"}</span>
              <span className="text-ink">{title}</span>
            </div>
            <pre className="mt-3 overflow-x-auto bg-panel px-5 py-4 font-mono text-[12.5px] leading-[1.7] whitespace-pre-wrap text-paper/90">
              {output || "Output lands here. Pick a command on the right, or type your own."}
            </pre>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            {["/help", "/crack 57495245206465736b", "/hash wire desk", "/password battery-staple", "/uuid"].map(
              (s) => (
                <button
                  key={s}
                  onClick={() => {
                    setInput(s);
                    void run(s);
                  }}
                  className="slug border border-rule px-2.5 py-1.5 text-mute transition-colors hover:border-wire hover:text-wire"
                >
                  {s}
                </button>
              ),
            )}
          </div>
        </div>

        <aside className="border-l border-rule pl-6">
          <div className="slug border-b border-ink pb-2 text-ink">The deck</div>
          <div className="mt-3 space-y-3">
            {cmds.map((c) => (
              <button
                key={c.name}
                onClick={() => {
                  setInput(c.example);
                  void run(c.example);
                }}
                className="group block w-full border-t border-rule pt-2.5 text-left"
              >
                <div className="slug text-wire">
                  /{c.name} <span className="text-mute">{c.args}</span>
                </div>
                <p className="mt-1 font-serif text-[13px] leading-[1.5] text-ink-soft group-hover:text-ink">
                  {c.about}
                </p>
              </button>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}
