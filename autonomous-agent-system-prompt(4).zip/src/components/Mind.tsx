"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Icon } from "./icons";
import { PanelHead } from "./Panels";

type NodeRow = {
  label: string;
  kind: string;
  detail: string;
  source: string;
  confidence: number;
  uses: number;
};
type EdgeRow = { relation: string; note: string; weight: number; fromId: string; toId: string };
type EpisodeRow = { id: string; kind: string; headline: string; body: string; source: string; confidence: number; createdAt: string };

export function MindPanel() {
  const [nodes, setNodes] = useState<NodeRow[]>([]);
  const [edges, setEdges] = useState<EdgeRow[]>([]);
  const [episodes, setEpisodes] = useState<EpisodeRow[]>([]);
  const [graph, setGraph] = useState({ nodes: 0, edges: 0, episodes: 0 });
  const [links, setLinks] = useState<{ path: string }[]>([]);
  const [query, setQuery] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback((q = "") => {
    fetch(`/api/mind?q=${encodeURIComponent(q)}`)
      .then((r) => r.json())
      .then((d) => {
        setNodes(d.nodes ?? []);
        setEdges(d.edges ?? []);
        setEpisodes(d.episodes ?? []);
        setGraph(d.graph ?? { nodes: 0, edges: 0, episodes: 0 });
        setLinks(d.links ?? []);
      })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    load("");
  }, [load]);

  const runCycle = async (action: string) => {
    setBusy(true);
    setNote(action === "cycle" ? "Scanning the world…" : "Consolidating the graph…");
    try {
      const d = await fetch("/api/mind", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      }).then((r) => r.json());
      setNote(`${d.report?.headline ?? "Done."} ${d.report?.findings?.[0] ?? ""}`);
    } catch {
      setNote("The cycle failed and changed nothing.");
    }
    setBusy(false);
    load(query);
  };

  return (
    <div>
      <PanelHead
        slug={`Linked mind · ${graph.nodes} nodes · ${graph.edges} edges · ${graph.episodes} episodes`}
        title="One-to-another"
        lede="Nothing here is an isolated fact. Every concept, event, equation and page becomes a node, and every relationship a typed edge — CAUSES, ENABLES, CONTRADICTS, DERIVED_FROM, ANALOGOUS_TO. Before it answers, it traverses two hops through this graph so today connects to everything it already knew."
        action={
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => void runCycle("cycle")}
              disabled={busy}
              className="slug flex items-center gap-2 border border-ink px-4 py-2.5 hover:bg-wire hover:border-wire hover:text-paper disabled:opacity-40"
            >
              <Icon name="search" className="h-3.5 w-3.5" />
              Morning scan
            </button>
            <button
              onClick={() => void runCycle("consolidate")}
              disabled={busy}
              className="slug flex items-center gap-2 border border-ink px-4 py-2.5 hover:bg-wire hover:border-wire hover:text-paper disabled:opacity-40"
            >
              <Icon name="refresh" className="h-3.5 w-3.5" />
              Night consolidation
            </button>
          </div>
        }
      />

      {note && (
        <p className="slug mt-5 border-l-2 border-wire py-2 pl-4 leading-[1.9] text-wire">{note}</p>
      )}

      <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)]">
        <div>
          <div className="slug border-b border-ink pb-2 text-ink">Traverse it</div>
          <div className="mt-3 flex gap-2">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && load(query)}
              placeholder="any topic — how does it connect?"
              className="flex-1 border border-rule bg-paper-2/50 px-3 py-2.5 font-serif text-[15px] text-ink placeholder:text-mute/70"
            />
            <button
              onClick={() => load(query)}
              className="slug bg-wire px-4 py-2.5 text-paper hover:opacity-90"
            >
              Traverse
            </button>
          </div>
          <div className="mt-4 space-y-2.5">
            {links.map((l, i) => (
              <div key={i} className="border-t border-rule pt-2">
                <p className="font-mono text-[12px] leading-[1.7] text-ink-soft">{l.path}</p>
              </div>
            ))}
            {!links.length && (
              <p className="slug leading-[1.9] text-mute">
                No paths yet for that. Every question you ask adds nodes and
                edges — try again after a few turns.
              </p>
            )}
          </div>

          <div className="slug mt-9 border-b border-ink pb-2 text-ink">Nodes — what it knows</div>
          <div className="mt-2">
            {nodes.map((n, i) => (
              <div key={i} className="flex items-baseline gap-3 border-b border-rule py-2">
                <div className="min-w-0 flex-1">
                  <div className="truncate font-serif text-[14px]">{n.label}</div>
                  <div className="slug text-mute">
                    {n.kind} · confidence {n.confidence} · {n.source || "conversation"}
                  </div>
                </div>
                <span className="slug tnum text-mute">{n.uses}×</span>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="slug border-b border-ink pb-2 text-ink">
            Daily cycles — scan, investigate, consolidate
          </div>
          <div className="mt-4 space-y-4">
            {[
              ["Morning", "Scans live world signals, logs them as episodes and links them into the graph."],
              ["Investigation", "Every answer absorbs its concepts as nodes with typed relations and provenance."],
              ["Night", "Merges duplicate nodes, strengthens well-evidenced links, flags contradictions for tomorrow."],
            ].map(([title, body]) => (
              <div key={title} className="border-t border-rule pt-2.5">
                <div className="font-display text-[16px] font-semibold">{title}</div>
                <p className="mt-1 font-serif text-[13.5px] leading-[1.55] text-ink-soft">{body}</p>
              </div>
            ))}
          </div>

          <div className="slug mt-9 border-b border-ink pb-2 text-ink">
            Episodic log — timestamped, with provenance
          </div>
          <div className="mt-3 space-y-3.5">
            {episodes.map((e) => (
              <article key={e.id} className="border-t border-rule pt-2.5">
                <div className="slug flex items-center gap-2 text-mute">
                  <span className="text-wire">{e.kind}</span>
                  <span className="text-rule">/</span>
                  <span className="tnum">confidence {e.confidence}</span>
                  <span className="ml-auto tnum">
                    {new Date(e.createdAt).toLocaleString(undefined, {
                      month: "short",
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                </div>
                <h3 className="mt-1.5 font-serif text-[14.5px] leading-[1.4] font-semibold">
                  {e.headline}
                </h3>
                <p className="mt-1 font-serif text-[12.5px] leading-[1.5] text-ink-soft">
                  {e.body.slice(0, 180)}
                </p>
                {e.source && (
                  <div className="slug mt-1 truncate text-mute">{e.source}</div>
                )}
              </article>
            ))}
            {!episodes.length && (
              <p className="slug leading-[1.9] text-mute">The log is empty — run a morning scan.</p>
            )}
          </div>

          <div className="slug mt-9 border-b border-ink pb-2 text-ink">Typed relations in use</div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {[...new Set(edges.map((e) => e.relation))].map((r) => (
              <span key={r} className="slug rounded-full border border-rule px-2.5 py-1 text-mute">
                {r}
              </span>
            ))}
            {!edges.length && <span className="slug text-mute">none yet</span>}
          </div>
        </div>
      </div>
    </div>
  );
}
