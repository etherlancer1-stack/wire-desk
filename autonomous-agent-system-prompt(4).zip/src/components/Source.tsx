"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Icon } from "./icons";
import { PanelHead } from "./Panels";

type FileRow = { path: string; bytes: number; lines: number };

/**
 * Source access is owner-only. The export endpoint refuses unless the request
 * carries the WIRE_OWNER_KEY set on the server — ordinary visitors can never
 * pull the private source.
 */
export function SourcePanel() {
  const [files, setFiles] = useState<FileRow[]>([]);
  const [totals, setTotals] = useState({ files: 0, lines: 0, bytes: 0 });
  const [ownerKey, setOwnerKey] = useState("");
  const [note, setNote] = useState("");

  const load = useCallback((key: string) => {
    fetch(`/api/code?format=json&key=${encodeURIComponent(key)}`)
      .then(async (r) => {
        if (!r.ok) {
          const d = await r.json().catch(() => ({}));
          setFiles([]);
          setNote(d.error ?? "Source access is restricted to the owner.");
          return;
        }
        const d = await r.json();
        setFiles(d.files ?? []);
        setTotals(d.totals ?? { files: 0, lines: 0, bytes: 0 });
        setNote("");
      })
      .catch(() => setFiles([]));
  }, []);

  useEffect(() => {
    const saved = window.localStorage.getItem("wire.owner") ?? "";
    setOwnerKey(saved);
    load(saved);
  }, [load]);

  const unlock = () => {
    window.localStorage.setItem("wire.owner", ownerKey);
    load(ownerKey);
  };

  const href = (format: string) =>
    `/api/code?format=${format}&key=${encodeURIComponent(ownerKey)}`;

  return (
    <div>
      <PanelHead
        slug={`Private source · owner access · ${totals.files} files · ${totals.lines.toLocaleString()} lines`}
        title="Source & deployment"
        lede="The codebase is private. Downloading it requires the owner key configured on the server (WIRE_OWNER_KEY) — nothing here is exposed to ordinary visitors, and there is no public source endpoint. Deployment is done through your hosting provider, never through a token handed to the app."
      />

      <div className="mt-8 rounded-2xl border border-rule bg-paper-2/40 px-5 py-4">
        <div className="text-[14px] font-semibold">Owner access</div>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <input
            type="password"
            value={ownerKey}
            onChange={(e) => setOwnerKey(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && unlock()}
            placeholder="WIRE_OWNER_KEY"
            className="min-w-[220px] flex-1 border border-rule bg-paper px-3 py-2.5 font-mono text-[12px] text-ink placeholder:text-mute/70"
          />
          <button
            onClick={unlock}
            className="slug bg-ink px-4 py-2.5 text-paper hover:opacity-90"
          >
            Unlock source
          </button>
          <a
            href={href("zip")}
            className="slug border border-ink px-4 py-2.5 hover:bg-wire hover:border-wire hover:text-paper"
          >
            Download .zip
          </a>
          <a
            href={href("txt")}
            className="slug border border-rule px-4 py-2.5 text-mute hover:border-ink hover:text-ink"
          >
            Listing .txt
          </a>
        </div>
        {note && (
          <p className="slug mt-3 border-l-2 border-wire py-1.5 pl-3 leading-[1.8] text-wire">
            {note}
          </p>
        )}
      </div>

      {files.length > 0 && (
        <>
          <div className="mt-8 grid grid-cols-3 gap-x-8">
            {[
              ["Files", String(totals.files)],
              ["Lines of code", totals.lines.toLocaleString()],
              ["Size", `${(totals.bytes / 1024).toFixed(0)} kb`],
            ].map(([k, v]) => (
              <div key={k} className="border-t border-ink pt-2">
                <div className="slug text-mute">{k}</div>
                <div className="mt-1 font-display text-[26px] leading-none font-black">{v}</div>
              </div>
            ))}
          </div>

          <div className="mt-9 space-y-7">
            {Object.entries(
              files.reduce<Record<string, FileRow[]>>((acc, f) => {
                const key = f.path.includes("/")
                  ? f.path.split("/").slice(0, 2).join("/")
                  : "root";
                (acc[key] ??= []).push(f);
                return acc;
              }, {}),
            ).map(([group, rows]) => (
              <section key={group}>
                <div className="slug border-b border-ink pb-2 text-wire">{group}</div>
                <div className="mt-2">
                  {rows.map((f) => (
                    <div
                      key={f.path}
                      className="flex items-baseline gap-3 border-b border-rule py-2"
                    >
                      <span className="font-mono text-[12px] text-ink-soft">{f.path}</span>
                      <span className="slug ml-auto tnum text-mute">
                        {f.lines ? `${f.lines.toLocaleString()} lines` : "binary"} ·{" "}
                        {(f.bytes / 1024).toFixed(1)} kb
                      </span>
                    </div>
                  ))}
                </div>
              </section>
            ))}
          </div>
        </>
      )}

      <div className="mt-10 border-t border-ink pt-5">
        <div className="slug text-wire">Deployment — through your hosting provider</div>
        <h2 className="mt-2 font-display text-[22px] leading-tight font-bold">
          Run it in the cloud; the phone is only a screen
        </h2>
        <p className="mt-2.5 max-w-[70ch] font-serif text-[14.5px] leading-[1.62] text-ink-soft">
          WIRE is cloud-native by design: inference, the agent, the database,
          builds and security checks all run on the server. Any modern Android
          phone can drive it through a browser — nothing is compiled or hosted
          on the device.
        </p>

        <div className="mt-5 grid gap-4 sm:grid-cols-3">
          {[
            ["1. Put the source on your Git host", "Private repository, created by you — the app never holds your Git credentials."],
            ["2. Connect a hosting provider", "Render, Railway, Fly.io, Vercel, or self-hosted Coolify/Dokploy. The included Dockerfile and render.yaml describe the build."],
            ["3. Set the environment", "DATABASE_URL, OPENROUTER_API_KEY, WIRE_OWNER_KEY, NEXT_PUBLIC_SITE_URL. Nothing else."],
          ].map(([title, body], i) => (
            <div key={title} className="border-t border-ink pt-3">
              <div className="slug text-wire">Step {i + 1}</div>
              <h3 className="mt-1.5 font-display text-[16px] leading-tight font-semibold">{title}</h3>
              <p className="mt-1.5 font-serif text-[13px] leading-[1.55] text-ink-soft">{body}</p>
            </div>
          ))}
        </div>

        <div className="mt-6 flex flex-wrap gap-2">
          {[
            ["Render", "https://dashboard.render.com/new"],
            ["Railway", "https://railway.app/new"],
            ["Fly.io", "https://fly.io/apps/new"],
            ["Vercel", "https://vercel.com/new"],
            ["Coolify (self-hosted)", "https://coolify.io"],
            ["Dokploy (self-hosted)", "https://dokploy.com"],
          ].map(([label, href]) => (
            <a
              key={label}
              href={href}
              target="_blank"
              rel="noreferrer noopener"
              className="rounded-full border border-ink px-4 py-2 text-[13px] font-semibold hover:bg-wire hover:border-wire hover:text-paper"
            >
              {label}
            </a>
          ))}
        </div>

        <p className="slug mt-6 leading-[1.9] text-mute">
          Deployment happens on the provider dashboard with your own account.
          The app never collects tokens for publishing and never creates public
          repositories on your behalf.
        </p>
      </div>
    </div>
  );
}
