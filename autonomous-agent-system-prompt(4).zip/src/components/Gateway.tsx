"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Icon } from "./icons";
import { PanelHead } from "./Panels";

/* -------------------------------- gateway ------------------------------- */

type AppRow = {
  name: string;
  slug: string;
  category: string;
  group: string;
  master: boolean;
  connected: boolean;
  hits: number;
  lastUsedAt: string | null;
};

export function GatewayPanel() {
  const [apps, setApps] = useState<AppRow[]>([]);
  const [ecosystem, setEcosystem] = useState<{ category: string; blurb: string; groups: { group: string; apps: string[] }[] }[]>([]);
  const [query, setQuery] = useState("");
  const [drafts, setDrafts] = useState<Record<string, string>>({});

  const load = useCallback((q = "") => {
    fetch(`/api/gateway?q=${encodeURIComponent(q)}`)
      .then((r) => r.json())
      .then((d) => {
        setApps(d.apps ?? []);
        if (d.ecosystem) setEcosystem(d.ecosystem);
      })
      .catch(() => setApps([]));
  }, []);

  useEffect(() => {
    load("");
  }, [load]);

  const connect = async (a: AppRow) => {
    await fetch("/api/gateway", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: a.name, slug: a.slug, key: drafts[a.slug] ?? "" }),
    }).catch(() => {});
    load(query);
  };

  const connected = apps.filter((a) => a.connected);

  return (
    <div>
      <PanelHead
        slug={`Integration gateway · ${apps.length} platforms · ${connected.length} connected`}
        title="The app ecosystem"
        lede="Autonomous desks do not log into three hundred apps one at a time. They hold master keys — Composio, Nango, Pipedream, Arcade, n8n, MCP — that open hundreds of apps at once over OAuth, and keep individual credentials for the rest. Connect one here and the desk works through it."
        action={
          <div className="flex items-center gap-2">
            <input
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                load(e.target.value);
              }}
              placeholder="filter: google, stripe, github…"
              className="w-[220px] border border-rule bg-paper-2/50 px-3 py-2 font-mono text-[12px] text-ink placeholder:text-mute/70"
            />
            <button
              onClick={() => load(query)}
              className="slug border border-ink px-3.5 py-2 hover:bg-wire hover:border-wire hover:text-paper"
            >
              Scan
            </button>
          </div>
        }
      />

      {connected.length > 0 && (
        <div className="mt-7 border-t border-ink pt-4">
          <div className="slug text-wire">Connected · the desk works through these</div>
          <div className="mt-3 flex flex-wrap gap-2">
            {connected.map((a) => (
              <span
                key={a.slug}
                className="flex items-center gap-2 rounded-full border border-rule px-3 py-1.5"
              >
                <span className="h-[6px] w-[6px] rounded-full bg-wire" />
                <span className="font-serif text-[13px]">{a.name}</span>
                <span className="slug tnum text-mute">{a.hits}</span>
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="mt-9 space-y-12">
        {ecosystem.map((cat) => {
          const inCat = apps.filter((a) => a.category === cat.category);
          if (!inCat.length) return null;
          return (
            <section key={cat.category}>
              <div className="border-b border-ink pb-2">
                <h2 className="font-display text-[22px] leading-tight font-bold tracking-[-0.015em]">
                  {cat.category}
                </h2>
                <p className="mt-1.5 max-w-[70ch] font-serif text-[13.5px] leading-[1.55] text-mute">
                  {cat.blurb}
                </p>
              </div>

              <div className="mt-5 space-y-7">
                {cat.groups.map((g) => {
                  const rows = inCat.filter((a) => a.group === g.group);
                  if (!rows.length) return null;
                  return (
                    <div key={g.group}>
                      <div className="slug text-wire">{g.group}</div>
                      <div className="mt-3 grid gap-x-8 gap-y-3 sm:grid-cols-2 xl:grid-cols-3">
                        {rows.map((a) => (
                          <div
                            key={a.slug}
                            className="group flex items-center gap-2.5 border-t border-rule pt-2.5"
                          >
                            <span
                              className={`h-[6px] w-[6px] shrink-0 rounded-full ${
                                a.connected ? "bg-wire" : "bg-rule"
                              }`}
                            />
                            <div className="min-w-0 flex-1">
                              <div className="truncate font-serif text-[14px] leading-tight">
                                {a.name}
                                {a.master && (
                                  <span className="slug ml-2 text-wire">master key</span>
                                )}
                              </div>
                              {a.connected ? (
                                <div className="slug tnum mt-0.5 text-mute">
                                  connected · {a.hits} calls
                                </div>
                              ) : (
                                <input
                                  type="password"
                                  value={drafts[a.slug] ?? ""}
                                  onChange={(e) =>
                                    setDrafts({ ...drafts, [a.slug]: e.target.value })
                                  }
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter") void connect(a);
                                  }}
                                  placeholder="api key / token — enter to connect"
                                  className="mt-1 w-full border-b border-transparent bg-transparent font-mono text-[10.5px] text-ink placeholder:text-mute/60 focus:border-rule focus:outline-none"
                                />
                              )}
                            </div>
                            {a.connected && (
                              <button
                                onClick={() =>
                                  void fetch(`/api/gateway?slug=${a.slug}`, {
                                    method: "DELETE",
                                  }).then(() => load(query))
                                }
                                className="slug shrink-0 text-mute opacity-0 transition-opacity group-hover:opacity-100 hover:text-wire"
                              >
                                drop
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>

      <p className="slug mt-10 leading-[1.9] text-mute">
        Keys are stored on this desk, sent only to the platform they belong to,
        and never shown again after saving. Sign-in with a Gmail account happens
        through the Google Workspace group and the master gateways — never by
        handing a password to the desk.
      </p>
    </div>
  );
}

/* ------------------------------- treasury ------------------------------- */

type LedgerData = {
  income: number;
  expense: number;
  net: number;
  rows: { id: string; channel: string; kind: string; amount: number; currency: string; note: string; createdAt: string }[];
  channels: { channel: string; income: number; expense: number; net: number }[];
  goal: string;
  goalProgress: number;
  playbooks: { title: string; channel: string; action: string }[];
};

const money = (c: number) => `${c < 0 ? "-" : ""}$${(Math.abs(c) / 100).toFixed(2)}`;

export function TreasuryPanel() {
  const [data, setData] = useState<LedgerData | null>(null);
  const [amount, setAmount] = useState("");
  const [channel, setChannel] = useState("Gumroad");
  const [note, setNote] = useState("");
  const [kind, setKind] = useState<"income" | "expense">("income");

  const load = useCallback(() => {
    fetch("/api/treasury")
      .then((r) => r.json())
      .then(setData)
      .catch(() => setData(null));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const add = async () => {
    if (!Number(amount)) return;
    await fetch("/api/treasury", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount: Number(amount), channel, note, kind }),
    }).catch(() => {});
    setAmount("");
    setNote("");
    load();
  };

  const rows = data?.rows ?? [];

  return (
    <div>
      <PanelHead
        slug={`Treasury · net ${money(data?.net ?? 0)}`}
        title="It funds its own growth"
        lede="An autonomous desk costs money — models, compute, domains — so it keeps books. Log what its work earns and what it spends, and it plans around the difference: which products to ship, which channels to work, and how much of itself it can afford to grow."
      />

      <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
        <div>
          <div className="grid grid-cols-3 gap-x-6">
            {[
              ["Earned", money(data?.income ?? 0)],
              ["Spent", money(data?.expense ?? 0)],
              ["Net", money(data?.net ?? 0)],
            ].map(([k, v], i) => (
              <div key={k} className={`border-t pt-2 ${i === 2 ? "border-wire" : "border-ink"}`}>
                <div className="slug text-mute">{k}</div>
                <div
                  className={`mt-1 font-display text-[26px] leading-none font-black ${
                    i === 2 ? "text-wire" : ""
                  }`}
                >
                  {v}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 border-t border-ink pt-4">
            <div className="slug text-mute">Self-funding goal</div>
            <p className="mt-2 font-display text-[18px] leading-[1.4]">{data?.goal}</p>
            <div className="mt-3 flex items-center gap-3">
              <div className="h-[3px] flex-1 bg-rule">
                <div
                  className="h-full bg-wire transition-all duration-700"
                  style={{ width: `${data?.goalProgress ?? 0}%` }}
                />
              </div>
              <span className="slug tnum text-mute">{data?.goalProgress ?? 0}%</span>
            </div>
          </div>

          <div className="mt-8 border-t border-ink pt-4">
            <div className="slug text-mute">Log an entry</div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <div className="flex rounded-full border border-rule p-0.5">
                {(["income", "expense"] as const).map((k) => (
                  <button
                    key={k}
                    onClick={() => setKind(k)}
                    className={`slug rounded-full px-3 py-1.5 ${
                      kind === k ? "bg-ink text-paper" : "text-mute hover:text-ink"
                    }`}
                  >
                    {k}
                  </button>
                ))}
              </div>
              <input
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="49.00"
                className="w-[92px] border border-rule bg-paper-2/50 px-2.5 py-2 font-mono text-[12px] text-ink"
              />
              <input
                value={channel}
                onChange={(e) => setChannel(e.target.value)}
                placeholder="channel"
                className="w-[130px] border border-rule bg-paper-2/50 px-2.5 py-2 font-mono text-[12px] text-ink"
              />
              <input
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="what it was for"
                className="min-w-[140px] flex-1 border border-rule bg-paper-2/50 px-2.5 py-2 font-serif text-[13.5px] text-ink"
              />
              <button
                onClick={() => void add()}
                className="slug bg-wire px-4 py-2.5 text-paper hover:opacity-90"
              >
                Record
              </button>
            </div>
          </div>

          <div className="mt-8">
            <div className="slug border-b border-ink pb-2 text-ink">Ledger</div>
            <div className="mt-2">
              {rows.map((r) => (
                <div
                  key={r.id}
                  className="flex items-baseline gap-3 border-b border-rule py-2.5"
                >
                  <span
                    className={`slug w-[62px] shrink-0 ${
                      r.kind === "income" ? "text-wire" : "text-mute"
                    }`}
                  >
                    {r.kind}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-serif text-[14px]">{r.note || r.channel}</div>
                    <div className="slug text-mute">
                      {r.channel} · {new Date(r.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                  <span className="tnum font-mono text-[13px]">{money(r.amount)}</span>
                  <button
                    onClick={() =>
                      void fetch(`/api/treasury?id=${r.id}`, { method: "DELETE" }).then(load)
                    }
                    className="slug text-mute hover:text-wire"
                  >
                    ✕
                  </button>
                </div>
              ))}
              {!rows.length && (
                <p className="slug py-3 leading-[1.9] text-mute">
                  No entries yet. The first sale, retainer or invoice goes here —
                  and from then on the desk plans its own growth around the
                  balance.
                </p>
              )}
            </div>
          </div>
        </div>

        <div>
          <div className="slug border-b border-ink pb-2 text-ink">
            Playbooks it can execute today
          </div>
          <div className="mt-4 space-y-5">
            {(data?.playbooks ?? []).map((p) => (
              <article key={p.title} className="border-t border-rule pt-3">
                <div className="slug text-wire">{p.channel}</div>
                <h3 className="mt-1.5 font-display text-[17px] leading-tight font-semibold">
                  {p.title}
                </h3>
                <p className="mt-1.5 font-serif text-[13.5px] leading-[1.55] text-ink-soft">
                  {p.action}
                </p>
              </article>
            ))}
          </div>

          <div className="mt-8 border-t border-ink pt-4">
            <div className="slug text-mute">By channel</div>
            <div className="mt-3 space-y-2">
              {(data?.channels ?? []).map((c) => (
                <div key={c.channel} className="flex items-baseline gap-3">
                  <span className="font-serif text-[14px]">{c.channel}</span>
                  <span className="slug ml-auto tnum text-mute">
                    {money(c.income)} in · {money(c.expense)} out
                  </span>
                  <span
                    className={`tnum font-mono text-[13px] ${
                      c.net >= 0 ? "text-wire" : "text-mute"
                    }`}
                  >
                    {money(c.net)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <p className="slug mt-8 leading-[1.9] text-mute">
            Honest note: the desk drafts the work — products, listings, proposals,
            reports — and you hold the accounts and approve the launches. It
            cannot and should not open financial accounts on its own.
          </p>
        </div>
      </div>
    </div>
  );
}
