"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Markdown } from "./Markdown";
import { Icon, WireMark } from "./icons";
import { AppsPanel, CommandConsole, MemoryPanel, WillPanel } from "./Panels";
import { CreaturePanel, SettingsPanel as MeshSettingsPanel } from "./Mesh";
import { EvolvePanel, SitesPanel } from "./Studio";
import { GatewayPanel, TreasuryPanel } from "./Gateway";
import { EngineerPanel } from "./Engineer";
import { SourcePanel } from "./Source";
import { MindPanel } from "./Mind";
import { AgentsPanel } from "./Lab";
import { SecurityPanel } from "./SecurityLab";
import { ProjectsPanel } from "./Projects";
import { DeployPanel } from "./Deploy";

/* ------------------------------- types ------------------------------- */

export type Wire = {
  idx: number;
  title: string;
  url: string;
  domain: string;
  snippet: string;
  origin: string;
  published: string | null;
  read?: boolean;
};

export type Msg = {
  id: string;
  role: "user" | "assistant";
  content: string;
  model?: string | null;
  provider?: string | null;
  searched?: number;
  sources?: Wire[];
  error?: boolean;
  live?: boolean;
};

type Conv = { id: string; title: string; updatedAt: string; turns: number };

type Settings = {
  brain: string;
  keys: Record<string, string>;
  models: Record<string, string>;
  provider: string;
  apiKey: string;
  baseUrl: string;
  model: string;
};

const DEFAULT_SETTINGS: Settings = {
  brain: "auto",
  keys: {},
  models: {},
  provider: "openrouter",
  apiKey: "",
  baseUrl: "",
  model: "",
};

const STARTERS = [
  "Solve ∂²u/∂t² = c²∇²u and explain what it describes",
  "What actually happened in quantum computing this month?",
  "Explain black hole information paradox like a physicist",
  "Write a fast rate-limiter in TypeScript and prove it works",
];

const VIEWS = [
  ["desk", "Chat"],
  ["apps", "Apps"],
  ["memory", "Memory"],
  ["will", "Will"],
  ["creature", "Creature"],
  ["mind", "Linked mind"],
  ["sites", "Sites"],
  ["evolve", "Self-rewrite"],
  ["gateway", "Gateway"],
  ["treasury", "Treasury"],
  ["projects", "Projects"],
  ["deploy", "Deployments"],
  ["agents", "Agent studio"],
  ["security", "Security lab"],
  ["engineer", "Engineer"],
  ["source", "Source code"],
  ["commands", "Commands"],
] as const;

/* ------------------------------- utils ------------------------------- */

function clock(d?: string | Date) {
  const date = d ? new Date(d) : new Date();
  return `${date.toISOString().slice(11, 16)} UTC`;
}

function greeting() {
  const h = new Date().getUTCHours();
  if (h < 5) return "Still awake";
  if (h < 12) return "Good morning";
  if (h < 18) return "Good afternoon";
  return "Good evening";
}

function dayLabel(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  const same = (a: Date, b: Date) => a.toDateString() === b.toDateString();
  const yest = new Date(now);
  yest.setDate(now.getDate() - 1);
  if (same(d, now)) return "Today";
  if (same(d, yest)) return "Yesterday";
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

function loadSettings(): Settings {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  try {
    const raw = window.localStorage.getItem("wire.settings");
    return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

/* ------------------------------ component ---------------------------- */

export function WireDesk() {
  const [convs, setConvs] = useState<Conv[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [streaming, setStreaming] = useState(false);
  const [status, setStatus] = useState("");
  const [mode, setMode] = useState<"ask" | "deep">("ask");
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const [flash, setFlash] = useState<number | null>(null);
  const [copied, setCopied] = useState<number | null>(null);
  const [draft, setDraft] = useState("");
  const [view, setView] = useState<(typeof VIEWS)[number][0]>("desk");
  const [recalled, setRecalled] = useState<{ kind: string; content: string }[]>([]);
  const [learned, setLearned] = useState(0);
  const [brainNote, setBrainNote] = useState("");
  const [stuck, setStuck] = useState(false);
  const [theme, setTheme] = useState<"paper" | "ink">("ink");
  const [toolsOpen, setToolsOpen] = useState(false);
  const [built, setBuilt] = useState<{ url: string; title: string } | null>(null);

  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const stickRef = useRef(true);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setSettings(loadSettings());
    fetch("/api/conversations")
      .then((r) => r.json())
      .then((d) => setConvs(d.conversations ?? []))
      .catch(() => setConvs([]));
  }, []);

  useEffect(() => {
    const el = scrollRef.current;
    if (el && stickRef.current) el.scrollTop = el.scrollHeight;
  }, [messages, status, view]);

  useEffect(() => {
    const saved =
      (window.localStorage.getItem("wire.theme") as "paper" | "ink") || "ink";
    setTheme(saved);
    document.documentElement.setAttribute("data-theme", saved);
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => {
      const next = prev === "paper" ? "ink" : "paper";
      document.documentElement.setAttribute("data-theme", next);
      try {
        window.localStorage.setItem("wire.theme", next);
      } catch {
        /* private mode */
      }
      return next;
    });
  }, []);

  const refreshConvs = useCallback(async () => {
    try {
      const d = await fetch("/api/conversations").then((r) => r.json());
      setConvs(d.conversations ?? []);
    } catch {
      /* keep list */
    }
  }, []);

  const railSources = useMemo(() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      const m = messages[i];
      if (m.role === "assistant" && m.sources?.length) return m.sources;
    }
    return [];
  }, [messages]);

  const openConversation = useCallback(async (id: string) => {
    setNavOpen(false);
    setView("desk");
    setActiveId(id);
    setMessages([]);
    try {
      const d = await fetch(`/api/conversations/${id}`).then((r) => r.json());
      const byMessage: Record<string, Wire[]> = {};
      for (const s of d.sources ?? []) {
        const key = s.messageId ?? "none";
        (byMessage[key] ??= []).push({
          idx: s.idx,
          title: s.title,
          url: s.url,
          domain: s.domain,
          snippet: s.snippet,
          origin: s.origin,
          published: s.published,
          read: true,
        });
      }
      setMessages(
        (d.messages ?? []).map((m: any) => ({
          id: m.id,
          role: m.role,
          content: m.content,
          model: m.model,
          provider: m.provider,
          searched: m.searched,
          sources: byMessage[m.id] ?? [],
        })),
      );
      stickRef.current = true;
    } catch {
      /* silent */
    }
  }, []);

  const ask = useCallback(
    async (text: string, opts: { regenerate?: boolean } = {}) => {
      const q = text.trim();
      if (!q || streaming) return;
      const assistantId = `a-${Date.now()}`;
      const controller = new AbortController();
      abortRef.current = controller;
      setStreaming(true);
      setStatus("Scanning the wire…");
      setDraft("");
      setView("desk");
      setNavOpen(false);
      stickRef.current = true;
      if (textareaRef.current) textareaRef.current.style.height = "auto";

      setMessages((prev) => {
        const next = opts.regenerate
          ? [...prev]
          : [...prev, { id: `u-${Date.now()}`, role: "user" as const, content: q }];
        next.push({ id: assistantId, role: "assistant", content: "", sources: [], live: true });
        return next;
      });

      const patch = (fn: (m: Msg) => Msg) =>
        setMessages((prev) => prev.map((m) => (m.id === assistantId ? fn(m) : m)));

      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          signal: controller.signal,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            conversationId: activeId,
            message: q,
            mode,
            regenerate: Boolean(opts.regenerate),
            settings: {
              brain: settings.brain,
              ring: settings.keys,
              models: settings.models,
              provider: settings.provider,
              apiKey: settings.apiKey,
              model: settings.model,
            },
          }),
        });

        if (!res.ok || !res.body) {
          const detail = await res.text();
          throw new Error(detail.slice(0, 240) || `Desk error ${res.status}`);
        }

        const reader = res.body.getReader();
        const dec = new TextDecoder();
        let buf = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop() ?? "";
          for (const line of lines) {
            if (!line.trim()) continue;
            let evt: any;
            try {
              evt = JSON.parse(line);
            } catch {
              continue;
            }
            if (evt.type === "thread") {
              setActiveId(evt.conversationId);
            } else if (evt.type === "status") {
              setStatus(evt.message ?? "");
            } else if (evt.type === "memory") {
              setRecalled(evt.memories ?? []);
            } else if (evt.type === "learn") {
              setLearned((n) => n + (evt.learned ?? 0));
            } else if (evt.type === "brain") {
              setBrainNote(`${evt.brain} · ${evt.model}`);
            } else if (evt.type === "mesh") {
              setBrainNote("");
            } else if (evt.type === "site") {
              setBuilt({ url: evt.url, title: evt.title });
            } else if (evt.type === "sources") {
              patch((m) => ({ ...m, sources: evt.sources ?? [] }));
            } else if (evt.type === "token") {
              patch((m) => ({ ...m, content: m.content + evt.text }));
            } else if (evt.type === "done") {
              patch((m) => ({
                ...m,
                live: false,
                model: evt.model,
                provider: evt.provider,
                searched: evt.searched,
              }));
              setStatus("");
              void refreshConvs();
            } else if (evt.type === "error") {
              patch((m) => ({
                ...m,
                live: false,
                error: true,
                content:
                  m.content +
                  `\n\n**The desk stopped.** ${evt.message}\n\nCheck the mind vault in *Settings*, or try again.`,
              }));
              setStatus("");
            }
          }
        }
      } catch (err) {
        const aborted = err instanceof Error && err.name === "AbortError";
        patch((m) => ({
          ...m,
          live: false,
          error: !aborted,
          content: (
            m.content +
            "\n\n" +
            (aborted
              ? "_Stopped._"
              : `**The desk stopped.** ${err instanceof Error ? err.message : "Unknown error"}`)
          ).trim(),
        }));
        setStatus("");
      } finally {
        patch((m) => ({ ...m, live: false }));
        abortRef.current = null;
        setStreaming(false);
        setStatus("");
        void refreshConvs();
      }
    },
    [activeId, mode, refreshConvs, settings, streaming],
  );

  const regenerate = useCallback(() => {
    if (streaming) return;
    const next = [...messages];
    while (next.length && next[next.length - 1].role === "assistant") next.pop();
    const question = next[next.length - 1]?.content ?? "";
    setMessages(next);
    window.setTimeout(() => {
      if (question) void ask(question, { regenerate: true });
    }, 0);
  }, [ask, messages, streaming]);

  const sendFeedback = useCallback(async (messageId: string, vote: number) => {
    let note = "";
    if (vote < 0) note = window.prompt("What should it fix? It will remember this.") ?? "";
    await fetch("/api/commands", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "feedback", messageId, vote, note }),
    }).catch(() => {});
    if (note.trim()) setLearned((n) => n + 1);
  }, []);

  const stop = useCallback(() => abortRef.current?.abort(), []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
        e.preventDefault();
        void ask(draft);
      }
      if (e.key === "Escape") setSettingsOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [ask, draft]);

  const newDispatch = useCallback(() => {
    abortRef.current?.abort();
    setActiveId(null);
    setMessages([]);
    setStatus("");
    setView("desk");
    setNavOpen(false);
    window.setTimeout(() => textareaRef.current?.focus(), 30);
  }, []);

  const removeConv = useCallback(
    async (id: string) => {
      setConvs((prev) => prev.filter((c) => c.id !== id));
      if (id === activeId) newDispatch();
      await fetch(`/api/conversations/${id}`, { method: "DELETE" }).catch(() => {});
      void refreshConvs();
    },
    [activeId, newDispatch, refreshConvs],
  );

  const renameConv = useCallback(async (id: string, title: string) => {
    setConvs((prev) => prev.map((c) => (c.id === id ? { ...c, title } : c)));
    await fetch(`/api/conversations/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title }),
    }).catch(() => {});
  }, []);

  const cite = useCallback((n: number) => {
    setFlash(n);
    const el = document.getElementById(`wire-${n}`);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    window.setTimeout(() => setFlash(null), 1800);
  }, []);

  const saveSettings = useCallback((next: Settings) => {
    setSettings(next);
    try {
      window.localStorage.setItem("wire.settings", JSON.stringify(next));
    } catch {
      /* private mode */
    }
    setSettingsOpen(false);
  }, []);

  const mindLabel =
    settings.brain === "auto"
      ? "Auto"
      : `${settings.brain}${settings.models?.[settings.brain] ? ` · ${settings.models[settings.brain]}` : ""}`;

  /* -------------------------------- view -------------------------------- */

  return (
    <div className="flex h-dvh overflow-hidden bg-paper text-ink">
      {/* ------------------------------ sidebar ----------------------------- */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-[268px] shrink-0 flex-col bg-[#171717] text-[#ececec] transition-transform duration-300 lg:static lg:translate-x-0 ${
          navOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center gap-2.5 px-4 pt-5 pb-4">
          <WireMark className="h-7 w-7 text-[#e9e0d0]" />
          <div>
            <div
              className="font-display text-[21px] leading-none font-black tracking-[-0.02em]"
              style={{ fontVariationSettings: '"WONK" 1' }}
            >
              WIRE
            </div>
            <div className="slug mt-1 text-[#e9e0d0]/45">live answer engine</div>
          </div>
          <button
            onClick={() => setNavOpen(false)}
            className="ml-auto p-1 text-[#e9e0d0]/60 lg:hidden"
            aria-label="Close menu"
          >
            <Icon name="close" className="h-4 w-4" />
          </button>
        </div>

        <div className="px-3">
          <button
            onClick={newDispatch}
            className="flex w-full items-center gap-2.5 rounded-full border border-[#e9e0d0]/15 px-4 py-2.5 text-left transition-colors hover:border-wire hover:bg-wire"
          >
            <Icon name="plus" className="h-4 w-4" />
            <span className="font-serif text-[14.5px]">New chat</span>
          </button>
        </div>

        <nav className="mt-5 px-3">
          <button
            onClick={() => {
              setView("desk");
              setNavOpen(false);
            }}
            className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition-colors ${
              view === "desk"
                ? "bg-[#e9e0d0]/10 text-[#e9e0d0]"
                : "text-[#e9e0d0]/60 hover:bg-[#e9e0d0]/[0.06] hover:text-[#e9e0d0]/90"
            }`}
          >
            <span
              className={`h-[6px] w-[6px] rounded-full ${
                view === "desk" ? "bg-wire" : "bg-[#e9e0d0]/25"
              }`}
            />
            <span className="font-serif text-[14px]">Chat</span>
          </button>

          <button
            onClick={() => setToolsOpen((o) => !o)}
            className="mt-1 flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[#e9e0d0]/45 transition-colors hover:bg-[#e9e0d0]/[0.06] hover:text-[#e9e0d0]/80"
          >
            <span className="h-[6px] w-[6px] rounded-full bg-[#e9e0d0]/20" />
            <span className="font-serif text-[13.5px]">Tools</span>
            <span className="ml-auto text-[11px]">{toolsOpen ? "−" : "+"}</span>
          </button>

          {toolsOpen && (
            <div className="mt-1 space-y-0.5 border-l border-[#e9e0d0]/10 pl-2">
              {VIEWS.filter(([id]) => id !== "desk").map(([id, label]) => (
                <button
                  key={id}
                  onClick={() => {
                    setView(id);
                    setNavOpen(false);
                  }}
                  className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-left transition-colors ${
                    view === id
                      ? "bg-[#e9e0d0]/10 text-[#e9e0d0]"
                      : "text-[#e9e0d0]/55 hover:bg-[#e9e0d0]/[0.06] hover:text-[#e9e0d0]/85"
                  }`}
                >
                  <span className="font-serif text-[13px]">{label}</span>
                </button>
              ))}
            </div>
          )}
        </nav>

        <div className="slug mt-6 px-5 text-[#e9e0d0]/35">Recent</div>
        <nav className="mt-1.5 flex-1 overflow-y-auto px-2 pb-3">
          {convs.length === 0 && (
            <p className="px-3 py-2 font-serif text-[13px] leading-[1.7] text-[#e9e0d0]/35">
              Nothing filed yet.
            </p>
          )}
          {convs.map((c) => {
            const active = c.id === activeId;
            return (
              <div
                key={c.id}
                className={`group relative flex items-center gap-1 rounded-lg px-2.5 py-2 transition-colors ${
                  active ? "bg-[#e9e0d0]/10" : "hover:bg-[#e9e0d0]/[0.06]"
                }`}
              >
                <button
                  onClick={() => openConversation(c.id)}
                  className="min-w-0 flex-1 text-left"
                  title={c.title}
                >
                  <div className="truncate font-serif text-[13.5px] leading-snug text-[#e9e0d0]/85">
                    {c.title}
                  </div>
                  <div className="slug mt-0.5 text-[#e9e0d0]/35">
                    {dayLabel(c.updatedAt)} · {c.turns} turns
                  </div>
                </button>
                <div className="flex shrink-0 items-center opacity-0 transition-opacity group-hover:opacity-100">
                  <button
                    aria-label="Rename chat"
                    onClick={() => {
                      const t = window.prompt("Rename chat", c.title);
                      if (t) void renameConv(c.id, t);
                    }}
                    className="p-1 text-[#e9e0d0]/50 hover:text-[#e9e0d0]"
                  >
                    <Icon name="copy" className="h-3.5 w-3.5" />
                  </button>
                  <button
                    aria-label="Delete chat"
                    onClick={() => void removeConv(c.id)}
                    className="p-1 text-[#e9e0d0]/50 hover:text-wire"
                  >
                    <Icon name="trash" className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </nav>

        <button
          onClick={() => setSettingsOpen(true)}
          className="flex items-center gap-2.5 border-t border-[#e9e0d0]/10 px-4 py-3.5 text-left"
        >
          <Icon name="gear" className="h-4 w-4 text-[#e9e0d0]/60" />
          <div className="min-w-0">
            <div className="slug text-[#e9e0d0]/45">Mind</div>
            <div className="truncate font-serif text-[13px] text-[#e9e0d0]/85">
              {mindLabel}
            </div>
          </div>
        </button>
      </aside>

      {navOpen && (
        <button
          aria-label="Close menu"
          onClick={() => setNavOpen(false)}
          className="fixed inset-0 z-30 bg-ink/50 lg:hidden"
        />
      )}

      {/* -------------------------------- main ------------------------------ */}
      <main className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-rule/70 bg-paper/92 px-4 backdrop-blur-md xl:px-6">
          <button
            onClick={() => setNavOpen(true)}
            className="p-1 text-ink lg:hidden"
            aria-label="Open menu"
          >
            <Icon name="menu" className="h-5 w-5" />
          </button>

          <button
            onClick={() => setSettingsOpen(true)}
            className="flex items-center gap-2 rounded-full border border-rule px-3 py-1.5 transition-colors hover:border-ink"
            title="Change mind"
          >
            <span className="h-[7px] w-[7px] rounded-full bg-wire" />
            <span className="slug text-ink-soft">{mindLabel}</span>
            <Icon name="arrow" className="h-3 w-3 rotate-90 text-mute" />
          </button>

          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={toggleTheme}
              className="slug rounded-full border border-rule px-3 py-1.5 text-mute transition-colors hover:border-ink hover:text-ink"
              title="Toggle night edition"
            >
              {theme === "paper" ? "Dark" : "Light"}
            </button>
            {brainNote && (
              <span className="slug hidden items-center gap-1.5 text-wire sm:flex">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-wire" />
                {brainNote}
              </span>
            )}
            <div className="flex rounded-full border border-rule p-0.5">
              {(["ask", "deep"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  className={`slug rounded-full px-3 py-1.5 transition-colors ${
                    mode === m ? "bg-ink text-paper" : "text-mute hover:text-ink"
                  }`}
                >
                  {m === "ask" ? "Fast" : "Deep"}
                </button>
              ))}
            </div>
          </div>
        </header>

        <div
          ref={scrollRef}
          onScroll={(e) => {
            const el = e.currentTarget;
            const near = el.scrollHeight - el.scrollTop - el.clientHeight < 140;
            stickRef.current = near;
            setStuck(!near && messages.length > 0);
          }}
          className="relative flex-1 overflow-y-auto"
        >
          {view !== "desk" ? (
            <div className="mx-auto w-full max-w-[1180px] px-5 pt-9 pb-16 xl:px-10">
              {view === "apps" ? (
                <AppsPanel />
              ) : view === "memory" ? (
                <MemoryPanel />
              ) : view === "will" ? (
                <WillPanel />
              ) : view === "creature" ? (
                <CreaturePanel />
              ) : view === "mind" ? (
                <MindPanel />
              ) : view === "sites" ? (
                <SitesPanel />
              ) : view === "evolve" ? (
                <EvolvePanel />
              ) : view === "gateway" ? (
                <GatewayPanel />
              ) : view === "treasury" ? (
                <TreasuryPanel />
              ) : view === "projects" ? (
                <ProjectsPanel />
              ) : view === "deploy" ? (
                <DeployPanel />
              ) : view === "agents" ? (
                <AgentsPanel />
              ) : view === "security" ? (
                <SecurityPanel />
              ) : view === "engineer" ? (
                <EngineerPanel />
              ) : view === "source" ? (
                <SourcePanel />
              ) : (
                <CommandConsole />
              )}
            </div>
          ) : messages.length === 0 ? (
            <EmptyDesk onPick={ask} sources={railSources.length} />
          ) : (
            <div className="mx-auto w-full max-w-[820px] px-5 py-8 xl:px-6">
              {messages.map((m, i) =>
                m.role === "user" ? (
                  <UserBubble key={m.id} msg={m} />
                ) : (
                  <AssistantBlock
                    key={m.id}
                    msg={m}
                    index={i}
                    onCite={cite}
                    flash={flash}
                    copied={copied === i}
                    onCopy={() => {
                      void navigator.clipboard.writeText(m.content);
                      setCopied(i);
                      window.setTimeout(() => setCopied(null), 1400);
                    }}
                    onRegenerate={regenerate}
                    onVote={(v) => void sendFeedback(m.id, v)}
                  />
                ),
              )}

              {learned > 0 && (
                <div className="slug mt-2 text-center text-wire">
                  {learned} thing{learned === 1 ? "" : "s"} learned this session
                </div>
              )}

              {streaming && status && (
                <div className="slug mt-5 flex items-center gap-2.5 text-wire">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-wire" />
                  {status}
                </div>
              )}
            </div>
          )}

          {stuck && view === "desk" && (
            <button
              onClick={() => {
                stickRef.current = true;
                const el = scrollRef.current;
                if (el) el.scrollTop = el.scrollHeight;
                setStuck(false);
              }}
              className="sticky bottom-4 left-1/2 z-10 flex h-9 w-9 -translate-x-1/2 items-center justify-center rounded-full border border-rule bg-paper shadow-[0_4px_18px_rgba(22,18,14,0.14)]"
              aria-label="Scroll to latest"
            >
              <Icon name="arrow" className="h-4 w-4 rotate-180 text-ink" />
            </button>
          )}
        </div>

        {/* ----------------------------- composer --------------------------- */}
        {view === "desk" && (
          <div className="border-t border-rule/70 bg-paper px-4 pt-3 pb-4">
            <div className="mx-auto w-full max-w-[820px]">
              <div className="flex items-end gap-2 rounded-[26px] border border-rule bg-paper-2/70 px-3 py-2 shadow-[0_2px_20px_rgba(22,18,14,0.08)] transition-colors focus-within:border-ink">
                <textarea
                  ref={textareaRef}
                  value={draft}
                  onChange={(e) => {
                    setDraft(e.target.value);
                    const el = e.currentTarget;
                    el.style.height = "auto";
                    el.style.height = `${Math.min(el.scrollHeight, 180)}px`;
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      void ask(draft);
                    }
                  }}
                  rows={1}
                  placeholder="Ask anything — physics, history, code, equations…"
                  className="max-h-[180px] min-h-[26px] flex-1 resize-none bg-transparent px-2 py-2 font-serif text-[16px] leading-[1.5] text-ink placeholder:text-mute/70 focus:outline-none"
                />
                {streaming ? (
                  <button
                    onClick={stop}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-rule text-ink hover:border-wire hover:text-wire"
                    aria-label="Stop"
                  >
                    <Icon name="stop" className="h-3.5 w-3.5" />
                  </button>
                ) : (
                  <button
                    onClick={() => void ask(draft)}
                    disabled={!draft.trim()}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-wire text-paper transition-opacity hover:opacity-90 disabled:opacity-30"
                    aria-label="Send"
                  >
                    <Icon name="arrow" className="h-4 w-4 -rotate-90" />
                  </button>
                )}
              </div>

              <div className="slug mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-mute">
                <span>Enter sends · Shift+Enter new line</span>
                {built && (
                  <a
                    href={built.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="text-wire hover:underline"
                  >
                    built: {built.title} ↗
                  </a>
                )}
                <span className="hidden sm:inline">
                  {status ? status : "Sources are cited inline, numbered to the wire"}
                </span>
                <span className="ml-auto">{mode === "deep" ? "Deep search" : "Fast"}</span>
              </div>
            </div>
          </div>
        )}
      </main>

      {settingsOpen && (
        <MeshSettingsPanel
          settings={settings}
          onClose={() => setSettingsOpen(false)}
          onSave={saveSettings}
        />
      )}
    </div>
  );
}

/* ------------------------------ subviews ------------------------------ */

function UserBubble({ msg }: { msg: Msg }) {
  return (
    <div className="rise-in mb-7 flex justify-end">
      <div className="max-w-[82%] rounded-[20px] rounded-br-md bg-paper-2 px-5 py-3.5 text-[16px] leading-[1.55] text-ink">
        {msg.content}
      </div>
    </div>
  );
}

function AssistantBlock({
  msg,
  index,
  onCite,
  flash,
  copied,
  onCopy,
  onRegenerate,
  onVote,
}: {
  msg: Msg;
  index: number;
  onCite: (n: number) => void;
  flash: number | null;
  copied: boolean;
  onCopy: () => void;
  onRegenerate: () => void;
  onVote: (v: number) => void;
}) {
  return (
    <article className="mb-9">
      <div className="flex gap-3.5">
        <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-wire text-paper">
          <WireMark className="h-4.5 w-4.5" />
        </div>

        <div className="min-w-0 flex-1">
          <div className="slug mb-2.5 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-mute">
            <span className="text-ink">WIRE</span>
            <span className="text-rule">·</span>
            <span className="tnum">{clock()}</span>
            {msg.searched ? (
              <>
                <span className="text-rule">·</span>
                <span className="tnum">{msg.searched} pages</span>
              </>
            ) : null}

            {msg.live && (
              <span className="ml-auto flex items-center gap-1.5 text-wire">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-wire" />
                writing
              </span>
            )}
          </div>

          <div className="answer">
            <Markdown text={msg.content} onCite={onCite} />
            {msg.live && <span className="caret" />}
          </div>

          {msg.sources && msg.sources.length > 0 && (
            <div className="mt-5">
              <div className="slug mb-2 text-mute">
                Sources · {msg.sources.length}
              </div>
              <div className="flex flex-wrap gap-2">
                {msg.sources.map((s) => (
                  <a
                    key={s.idx}
                    id={`wire-${s.idx}`}
                    href={s.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    onClick={() => onCite(s.idx)}
                    className={`group flex max-w-[240px] items-center gap-2 rounded-full border px-3 py-1.5 transition-colors ${
                      flash === s.idx
                        ? "border-wire bg-wire/10"
                        : "border-rule hover:border-wire"
                    }`}
                  >
                    <span className="slug tnum shrink-0 text-wire">{s.idx}</span>
                    <span className="truncate font-serif text-[12.5px] text-ink-soft group-hover:text-ink">
                      {s.domain}
                    </span>
                    {s.read && (
                      <span className="slug shrink-0 text-mute">read</span>
                    )}
                  </a>
                ))}
              </div>
            </div>
          )}

          {!msg.live && (
            <div className="mt-4 flex flex-wrap items-center gap-1.5">
              <ActionButton onClick={onCopy} icon="copy" label={copied ? "Copied" : "Copy"} />
              <ActionButton onClick={onRegenerate} icon="refresh" label="Rewrite" />
              <ActionButton onClick={() => onVote(1)} icon="arrow" label="Solid" />
              <ActionButton onClick={() => onVote(-1)} icon="stop" label="Fix this" />
            </div>
          )}
        </div>
      </div>
    </article>
  );
}

function ActionButton({
  onClick,
  icon,
  label,
}: {
  onClick: () => void;
  icon: string;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className="slug flex items-center gap-1.5 rounded-full border border-transparent px-2.5 py-1.5 text-mute transition-colors hover:border-rule hover:text-ink"
    >
      <Icon name={icon} className="h-3 w-3" />
      {label}
    </button>
  );
}

function EmptyDesk({ onPick }: { onPick: (q: string) => void; sources?: number }) {
  return (
    <div className="mx-auto w-full max-w-[820px] px-6 pt-16 pb-10">
      <div className="slug text-wire">The desk is open · {clock()}</div>
      <h1
        className="mt-4 font-display text-[clamp(34px,5.2vw,58px)] leading-[0.98] font-black tracking-[-0.028em]"
        style={{ fontVariationSettings: '"WONK" 1' }}
      >
        {greeting()}.
        <br />
        <span className="font-normal italic">What are we answering?</span>
      </h1>
      <p className="mt-5 max-w-[58ch] font-serif text-[16.5px] leading-[1.62] text-ink-soft">
        It reads the live web before it speaks, remembers what you tell it,
        thinks across a mesh of model servers, and cites every claim to the page
        it came from.
      </p>

      <div className="mt-9 grid gap-3 sm:grid-cols-2">
        {STARTERS.map((s) => (
          <button
            key={s}
            onClick={() => onPick(s)}
            className="group rounded-2xl border border-rule bg-paper-2/50 px-4 py-4 text-left transition-all hover:-translate-y-0.5 hover:border-ink hover:bg-paper-3/70"
          >
            <div className="font-serif text-[15px] leading-[1.45] text-ink">
              {s}
            </div>
            <div className="slug mt-2.5 flex items-center gap-1.5 text-mute group-hover:text-wire">
              Ask the desk
              <Icon name="send" className="h-3 w-3" />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
