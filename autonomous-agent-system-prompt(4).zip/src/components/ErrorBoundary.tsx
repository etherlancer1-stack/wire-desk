"use client";

import React from "react";

/**
 * Nothing in the interface takes the desk down with it. A failing panel falls
 * back to this, and the answer stream keeps running behind it.
 */
export class ErrorBoundary extends React.Component<
  { children: React.ReactNode; label?: string },
  { failed: boolean; message: string }
> {
  constructor(props: { children: React.ReactNode; label?: string }) {
    super(props);
    this.state = { failed: false, message: "" };
  }

  static getDerivedStateFromError(error: Error) {
    return { failed: true, message: error.message ?? "Unknown fault" };
  }

  componentDidCatch(error: Error) {
    console.error("[wire:boundary]", error);
  }

  render() {
    if (this.state.failed) {
      return (
        <div className="mx-auto my-10 max-w-[620px] rounded-2xl border border-rule bg-paper-2/50 px-6 py-5">
          <div className="text-[12px] font-semibold tracking-[0.08em] text-wire uppercase">
            This section failed · the desk is still running
          </div>
          <p className="mt-2.5 font-serif text-[15px] leading-[1.6] text-ink-soft">
            {this.props.label ?? "A panel"} hit a fault and was contained so
            nothing else was affected. Everything behind it — memory, mesh,
            engine, builder — is untouched.
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <button
              onClick={() => this.setState({ failed: false, message: "" })}
              className="rounded-full bg-wire px-4 py-2 text-[13px] font-semibold text-paper hover:opacity-90"
            >
              Try again
            </button>
            <button
              onClick={() => window.location.reload()}
              className="rounded-full border border-rule px-4 py-2 text-[13px] font-semibold text-ink-soft hover:border-ink hover:text-ink"
            >
              Reload the desk
            </button>
            <span className="ml-auto font-mono text-[11px] text-mute">
              {this.state.message.slice(0, 80)}
            </span>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
