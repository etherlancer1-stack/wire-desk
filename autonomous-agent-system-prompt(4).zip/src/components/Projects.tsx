"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Icon } from "./icons";
import { PanelHead } from "./Panels";

type Project = { id: string; name: string; framework: string; description: string; updatedAt: string };
type Entry = { name: string; path: string; type: "file" | "dir"; bytes: number; modified: string };

export function ProjectsPanel() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [active, setActive] = useState<Project | null>(null);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [dir, setDir] = useState("");
  const [openFile, setOpenFile] = useState("");
  const [content, setContent] = useState("");
  const [note, setNote] = useState("");
  const [form, setForm] = useState({ name: "", framework: "static", description: "" });
  const [newName, setNewName] = useState("");
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<{ path: string; line: number; text: string }[]>([]);

  const loadProjects = useCallback(() => {
    fetch("/api/projects")
      .then((r) => r.json())
      .then((d) => setProjects(d.projects ?? []))
      .catch(() => setProjects([]));
  }, []);

  useEffect(() => {
    loadProjects();
  }, [loadProjects]);

  const loadDir = useCallback((p: Project, path = "") => {
    setActive(p);
    setDir(path);
    setOpenFile("");
    fetch(`/api/projects?id=${p.id}&path=${encodeURIComponent(path)}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) setNote(d.error);
        setEntries(d.entries ?? []);
      })
      .catch(() => setEntries([]));
  }, []);

  const open = async (path: string) => {
    if (!active) return;
    const d = await fetch(
      `/api/projects?id=${active.id}&file=${encodeURIComponent(path)}`,
    ).then((r) => r.json());
    if (d.error) return setNote(d.error);
    setOpenFile(path);
    setContent(d.content ?? "");
    setNote("");
  };

  const save = async () => {
    if (!active || !openFile) return;
    const d = await fetch("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "write", id: active.id, path: openFile, content }),
    }).then((r) => r.json());
    setNote(d.ok ? `Saved ${openFile} (${d.bytes} bytes) to the server.` : d.error ?? "Save failed.");
  };

  const create = async () => {
    const d = await fetch("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "create", ...form }),
    }).then((r) => r.json());
    if (d.project) {
      setNote(`Project “${d.project.name}” created on the server.`);
      setForm({ name: "", framework: "static", description: "" });
      loadProjects();
      loadDir(d.project);
    } else setNote(d.error ?? "Could not create the project.");
  };

  const addFile = async () => {
    if (!active || !newName.trim()) return;
    const path = dir ? `${dir}/${newName.trim()}` : newName.trim();
    await fetch("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "write", id: active.id, path, content: "" }),
    });
    setNewName("");
    loadDir(active, dir);
    void open(path);
  };

  const search = async () => {
    if (!active || !query.trim()) return;
    const d = await fetch(
      `/api/projects?id=${active.id}&q=${encodeURIComponent(query)}`,
    ).then((r) => r.json());
    setHits(d.hits ?? []);
    if (d.error) setNote(d.error);
  };

  return (
    <div>
      <PanelHead
        slug={`Projects · ${projects.length} workspaces · persistent server storage`}
        title="Cloud workspace"
        lede="Real projects with real files on the server — create, browse, edit and search them from any phone. Storage survives restarts, paths are sandboxed so nothing can escape a project, and the coding agent works on exactly these files. No development tools are needed on the device."
      />

      {note && (
        <p className="slug mt-4 border-l-2 border-wire py-2 pl-4 leading-[1.9] text-wire">{note}</p>
      )}

      <div className="mt-8 grid gap-10 lg:grid-cols-[260px_minmax(0,1fr)]">
        <div>
          <div className="slug border-b border-ink pb-2 text-ink">Your projects</div>
          <div className="mt-2">
            {projects.map((p) => (
              <button
                key={p.id}
                onClick={() => loadDir(p)}
                className={`mb-1 block w-full rounded-lg px-3 py-2 text-left transition-colors ${
                  active?.id === p.id ? "bg-paper-2" : "hover:bg-paper-2/60"
                }`}
              >
                <div className="truncate font-serif text-[14px] font-semibold">{p.name}</div>
                <div className="slug text-mute">{p.framework}</div>
              </button>
            ))}
            {!projects.length && (
              <p className="slug py-2 leading-[1.9] text-mute">No projects yet.</p>
            )}
          </div>

          <div className="slug mt-7 border-b border-ink pb-2 text-ink">New project</div>
          <div className="mt-3 space-y-2">
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="name"
              className="w-full border border-rule bg-paper-2/50 px-3 py-2 font-serif text-[14px] text-ink placeholder:text-mute/70"
            />
            <select
              value={form.framework}
              onChange={(e) => setForm({ ...form, framework: e.target.value })}
              className="slug w-full border border-rule bg-paper-2/50 px-3 py-2 text-ink"
            >
              {["static", "next.js", "react", "vite", "node", "python"].map((f) => (
                <option key={f} value={f}>
                  {f}
                </option>
              ))}
            </select>
            <textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={2}
              placeholder="what is it for?"
              className="w-full resize-y border border-rule bg-paper-2/50 px-3 py-2 font-serif text-[13.5px] text-ink placeholder:text-mute/70"
            />
            <button
              onClick={() => void create()}
              className="slug w-full bg-wire px-4 py-2.5 text-paper hover:opacity-90"
            >
              Create workspace
            </button>
          </div>
        </div>

        <div>
          {!active ? (
            <div className="rounded-2xl border border-rule px-6 py-10 text-center">
              <p className="font-serif text-[15px] text-ink-soft">
                Select a project — or create one — to open its workspace.
              </p>
            </div>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-2 border-b border-ink pb-3">
                <h2 className="font-display text-[19px] font-bold">{active.name}</h2>
                <span className="slug text-mute">{active.framework}</span>
                <div className="ml-auto flex items-center gap-2">
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && void search()}
                    placeholder="search files…"
                    className="w-[170px] border border-rule bg-paper-2/50 px-2.5 py-1.5 font-mono text-[11px] text-ink placeholder:text-mute/70"
                  />
                  <button
                    onClick={() => void search()}
                    className="slug border border-rule px-2.5 py-1.5 text-mute hover:border-ink hover:text-ink"
                  >
                    Find
                  </button>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-2">
                {dir && (
                  <button
                    onClick={() =>
                      loadDir(active, dir.split("/").slice(0, -1).join("/"))
                    }
                    className="slug border border-rule px-2.5 py-1.5 text-mute hover:border-ink hover:text-ink"
                  >
                    ← up
                  </button>
                )}
                <span className="slug text-mute">/{dir}</span>
                <input
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && void addFile()}
                  placeholder="new file name"
                  className="ml-auto w-[160px] border border-rule bg-paper-2/50 px-2.5 py-1.5 font-mono text-[11px] text-ink placeholder:text-mute/70"
                />
                <button
                  onClick={() => void addFile()}
                  className="slug bg-wire px-3 py-1.5 text-paper hover:opacity-90"
                >
                  + file
                </button>
              </div>

              <div className="mt-3 max-h-[220px] overflow-y-auto rounded-xl border border-rule">
                {entries.map((e) => (
                  <button
                    key={e.path}
                    onClick={() => (e.type === "dir" ? loadDir(active, e.path) : void open(e.path))}
                    className="flex w-full items-center gap-2.5 border-b border-rule px-3 py-2 text-left last:border-0 hover:bg-paper-2/60"
                  >
                    <Icon
                      name={e.type === "dir" ? "menu" : "copy"}
                      className="h-3.5 w-3.5 shrink-0 text-mute"
                    />
                    <span className="truncate font-mono text-[12px]">{e.name}</span>
                    <span className="slug ml-auto tnum text-mute">
                      {e.type === "dir" ? "dir" : `${(e.bytes / 1024).toFixed(1)} kb`}
                    </span>
                  </button>
                ))}
                {!entries.length && (
                  <p className="slug px-3 py-3 text-mute">Empty folder — create a file above.</p>
                )}
              </div>

              {hits.length > 0 && (
                <div className="mt-4">
                  <div className="slug text-mute">Search results</div>
                  {hits.map((h, i) => (
                    <button
                      key={i}
                      onClick={() => void open(h.path)}
                      className="mt-1.5 block w-full border-t border-rule pt-1.5 text-left"
                    >
                      <span className="font-mono text-[11px] text-wire">
                        {h.path}:{h.line}
                      </span>
                      <div className="truncate font-mono text-[11.5px] text-ink-soft">{h.text}</div>
                    </button>
                  ))}
                </div>
              )}

              {openFile && (
                <div className="mt-6">
                  <div className="flex items-center gap-2 border-b border-ink pb-2">
                    <span className="font-mono text-[12px]">{openFile}</span>
                    <button
                      onClick={() => void save()}
                      className="slug ml-auto bg-wire px-4 py-1.5 text-paper hover:opacity-90"
                    >
                      Save to server
                    </button>
                    <button
                      onClick={() =>
                        void fetch("/api/projects", {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({ action: "delete", id: active.id, path: openFile }),
                        }).then(() => {
                          setOpenFile("");
                          loadDir(active, dir);
                        })
                      }
                      className="slug border border-rule px-3 py-1.5 text-mute hover:border-wire hover:text-wire"
                    >
                      delete
                    </button>
                  </div>
                  <textarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    rows={18}
                    spellCheck={false}
                    className="mt-3 w-full resize-y rounded-xl border border-rule bg-paper-2/40 px-4 py-3 font-mono text-[12.5px] leading-[1.65] text-ink"
                  />
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
