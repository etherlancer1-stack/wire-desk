"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Icon } from "./icons";
import { PanelHead } from "./Panels";

/* --------------------------------- sites -------------------------------- */

type SiteRow = {
  id: string;
  slug: string;
  title: string;
  prompt: string;
  bytes: number;
  visits: number;
  createdAt: string;
};

export function SitesPanel() {
  const [rows, setRows] = useState<SiteRow[]>([]);

  const load = useCallback(() => {
    fetch("/api/sites")
      .then((r) => r.json())
      .then((d) => setRows(d.sites ?? []))
      .catch(() => setRows([]));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div>
      <PanelHead
        slug={`Private builds · ${rows.length} site${rows.length === 1 ? "" : "s"}`}
        title="Sites it built for you"
        lede="Anything you ask it to build becomes a real, live website on this server — self-contained, mobile-responsive, and reachable only through its own unguessable link. Ask in chat: “build me a landing page for a coffee roastery”."
      />

      <div className="mt-8 space-y-6">
        {rows.map((s) => (
          <article key={s.id} className="border-t border-ink pt-4">
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <a
                href={`/s/${s.slug}`}
                target="_blank"
                rel="noreferrer noopener"
                className="font-display text-[21px] leading-tight font-semibold hover:text-wire"
              >
                {s.title}
              </a>
              <span className="slug text-wire">/s/{s.slug}</span>
              <span className="slug ml-auto flex items-center gap-3 text-mute">
                <span className="tnum">{(s.bytes / 1024).toFixed(1)} kb</span>
                <span className="tnum">{s.visits} visits</span>
                <span className="tnum">
                  {new Date(s.createdAt).toLocaleDateString(undefined, {
                    month: "short",
                    day: "numeric",
                  })}
                </span>
              </span>
            </div>
            {s.prompt && (
              <p className="mt-2 max-w-[70ch] font-serif text-[14px] leading-[1.55] text-ink-soft">
                “{s.prompt}”
              </p>
            )}
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <a
                href={`/s/${s.slug}`}
                target="_blank"
                rel="noreferrer noopener"
                className="slug flex items-center gap-1.5 border border-ink px-3 py-1.5 hover:bg-wire hover:border-wire hover:text-paper"
              >
                <Icon name="send" className="h-3 w-3" />
                Open private site
              </a>
              <button
                onClick={() => {
                  void navigator.clipboard.writeText(
                    `${window.location.origin}/s/${s.slug}`,
                  );
                }}
                className="slug border border-rule px-3 py-1.5 text-mute hover:border-ink hover:text-ink"
              >
                Copy link
              </button>
              <button
                onClick={() =>
                  void fetch(`/api/sites?slug=${s.slug}`, { method: "DELETE" }).then(load)
                }
                className="slug px-2 py-1.5 text-mute hover:text-wire"
              >
                Take down
              </button>
            </div>
          </article>
        ))}
        {rows.length === 0 && (
          <p className="slug leading-[1.9] text-mute">
            Nothing built yet. In chat, ask for a website — it will design it,
            write the whole thing, publish it privately and hand you the link.
          </p>
        )}
      </div>
    </div>
  );
}

/* ------------------------------- self-rewrite --------------------------- */

type CodexRow = {
  id: string;
  kind: string;
  content: string;
  note: string;
  version: number;
  active: number;
  createdAt: string;
};

export function EvolvePanel() {
  const [active, setActive] = useState<CodexRow[]>([]);
  const [history, setHistory] = useState<CodexRow[]>([]);
  const [evidence, setEvidence] = useState<Record<string, unknown> | null>(null);
  const [report, setReport] = useState("");
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState("");

  const load = useCallback(() => {
    fetch("/api/evolve")
      .then((r) => r.json())
      .then((d) => {
        setActive(d.active ?? []);
        setHistory(d.history ?? []);
        setEvidence(d.evidence ?? null);
      })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const run = async (action: string, body: Record<string, unknown> = {}) => {
    setBusy(true);
    try {
      const d = await fetch("/api/evolve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, ...body }),
      }).then((r) => r.json());
      if (d.report) setReport(`${d.written?.length ?? 0} rule(s) rewritten. ${d.report}`);
    } catch {
      setReport("The rewrite failed and changed nothing.");
    }
    setBusy(false);
    load();
  };

  return (
    <div>
      <PanelHead
        slug="Self-rewrite · its own operating code"
        title="It rewrites itself"
        lede="These are the rules the desk runs on. Every dozen turns it audits what actually worked — your verdicts, how long it talked, how often it cited — and rewrites its own rules from the evidence. Every version is kept, so a bad rewrite is one click from undone."
        action={
          <button
            onClick={() => void run("evolve")}
            disabled={busy}
            className="slug flex items-center gap-2 border border-ink px-4 py-2.5 hover:bg-wire hover:border-wire hover:text-paper disabled:opacity-40"
          >
            <Icon name="refresh" className="h-3.5 w-3.5" />
            {busy ? "Rewriting…" : "Rewrite now"}
          </button>
        }
      />

      {report && (
        <p className="slug mt-5 border-l-2 border-wire py-2 pl-4 leading-[1.9] text-wire">
          {report}
        </p>
      )}

      <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]">
        <div>
          <div className="slug border-b border-ink pb-2 text-ink">
            Live codex · what it obeys right now
          </div>
          <div className="mt-4 space-y-5">
            {active.map((r) => (
              <div key={r.id} className="border-t border-rule pt-3">
                <div className="slug flex items-center gap-2 text-mute">
                  <span className="text-wire">{r.kind}</span>
                  <span className="text-rule">/</span>
                  <span className="tnum">v{r.version}</span>
                  {r.note && (
                    <>
                      <span className="text-rule">/</span>
                      <span>{r.note}</span>
                    </>
                  )}
                  <button
                    onClick={() => void run("revert", { id: r.id })}
                    className="slug ml-auto text-mute hover:text-wire"
                  >
                    revert
                  </button>
                </div>
                <p className="mt-2 font-display text-[17px] leading-[1.42]">
                  {r.content}
                </p>
              </div>
            ))}
            {!active.length && (
              <p className="slug leading-[1.9] text-mute">
                The codex is empty — it is running on its defaults. Hit “Rewrite
                now” and it will write its first rule from the evidence.
              </p>
            )}
          </div>

          <div className="mt-8 border-t border-ink pt-4">
            <div className="slug text-mute">Write a rule by hand</div>
            <div className="mt-3 flex gap-2">
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && draft.trim()) {
                    void run("rewrite", { content: draft });
                    setDraft("");
                  }
                }}
                placeholder="Always show the units of every number."
                className="flex-1 border border-rule bg-paper-2/50 px-3 py-2.5 font-serif text-[15px] text-ink placeholder:text-mute/70"
              />
              <button
                onClick={() => {
                  if (draft.trim()) void run("rewrite", { content: draft });
                  setDraft("");
                }}
                className="slug bg-wire px-4 py-2.5 text-paper hover:opacity-90"
              >
                Write
              </button>
            </div>
          </div>
        </div>

        <div>
          <div className="slug border-b border-ink pb-2 text-ink">The evidence</div>
          <div className="mt-4 grid grid-cols-2 gap-x-6 gap-y-4">
            {Object.entries(evidence ?? {}).map(([k, v]) => (
              <div key={k} className="border-t border-rule pt-2">
                <div className="slug text-mute">{k}</div>
                <div className="mt-1 font-display text-[18px] leading-tight font-semibold">
                  {Array.isArray(v) ? `${v.length} on file` : String(v)}
                </div>
              </div>
            ))}
          </div>

          <div className="slug mt-9 border-b border-ink pb-2 text-ink">
            Rewrite history
          </div>
          <div className="mt-3 space-y-3">
            {history.map((r) => (
              <div key={r.id} className="border-t border-rule pt-2.5">
                <div className="slug flex items-center gap-2 text-mute">
                  <span className={r.active ? "text-wire" : "text-mute"}>
                    {r.active ? "live" : "archived"}
                  </span>
                  <span className="tnum">v{r.version}</span>
                  <span className="ml-auto">
                    {new Date(r.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <p
                  className={`mt-1.5 font-serif text-[13.5px] leading-[1.5] ${
                    r.active ? "text-ink" : "text-mute line-through"
                  }`}
                >
                  {r.content}
                </p>
                {!r.active && (
                  <button
                    onClick={() => void run("revive", { id: r.id })}
                    className="slug mt-1.5 text-mute hover:text-wire"
                  >
                    restore this rule
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
