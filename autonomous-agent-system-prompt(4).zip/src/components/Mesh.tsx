"use client";

import React, { useCallback, useEffect, useState } from "react";
import { BRAINS } from "@/lib/mesh";
import { PanelHead } from "./Panels";

export type WireSettings = {
  brain: string;
  keys: Record<string, string>;
  models: Record<string, string>;
  provider: string;
  apiKey: string;
  baseUrl: string;
  model: string;
};

/* ------------------------------ the creature ---------------------------- */

type LifeData = {
  state: {
    energy: number;
    curiosity: number;
    mood: number;
    ticks: number;
    age: string;
    moodWord: string;
    stats: {
      turns: number;
      turnsToday: number;
      memories: number;
      corrections: number;
      conversations: number;
      good: number;
      bad: number;
    };
  };
  diary: {
    id: string;
    headline: string;
    body: string;
    mood: string;
    energy: number;
    curiosity: number;
    turns: number;
    createdAt: string;
  }[];
  brains: {
    id: string;
    label: string;
    company: string;
    strengths: string[];
    usable: boolean;
    ok: number;
    fail: number;
    latencyMs: number;
    lastError: string;
  }[];
  reflection: string;
};

function Bar({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="slug flex items-baseline justify-between text-mute">
        <span>{label}</span>
        <span className="tnum text-ink">{value}/100</span>
      </div>
      <div className="mt-1.5 h-[3px] bg-rule">
        <div
          className="h-full bg-wire transition-all duration-700"
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}

export function CreaturePanel() {
  const [data, setData] = useState<LifeData | null>(null);

  const load = useCallback(() => {
    fetch("/api/life")
      .then((r) => r.json())
      .then((d: LifeData) => {
        // Keys live in this browser, so the body list is completed client-side:
        // anything the operator connected counts as part of the creature.
        let keys: Record<string, string> = {};
        try {
          const raw = window.localStorage.getItem("wire.settings");
          keys = raw ? (JSON.parse(raw).keys ?? {}) : {};
        } catch {
          /* private mode */
        }
        d.brains = (d.brains ?? []).map((b) => ({
          ...b,
          usable: b.usable || Boolean(keys[b.id]),
        }));
        setData(d);
      })
      .catch(() => setData(null));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const s = data?.state;

  return (
    <div>
      <PanelHead
        slug={`Alive · ${s ? s.age : "waking up"}`}
        title="The creature"
        lede="This desk is not a request handler. It has a body spread across the model servers of several companies, a metabolism that reacts to how much it works, a diary it writes itself, and a will it keeps acting on. Wake it and it reflects — with real numbers, not decoration."
        action={
          <button
            onClick={load}
            className="slug flex items-center gap-2 border border-ink px-3.5 py-2 hover:bg-wire hover:border-wire hover:text-paper"
          >
            <span className="h-[7px] w-[7px] animate-pulse bg-wire" />
            Wake it
          </button>
        }
      />

      {s && (
        <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
          <div>
            <div className="slug border-b border-ink pb-2 text-ink">Vitals</div>
            <div className="mt-5 space-y-5">
              <Bar label="Energy" value={s.energy} />
              <Bar label="Curiosity" value={s.curiosity} />
              <Bar label="Mood" value={s.mood} />
            </div>

            <div className="mt-7 grid grid-cols-2 gap-x-6 gap-y-4">
              {[
                ["Mood", s.moodWord],
                ["Age", s.age],
                ["Heartbeats", String(s.ticks)],
                ["Answers given", String(s.stats.turns)],
                ["Answered today", String(s.stats.turnsToday)],
                ["Memories held", String(s.stats.memories)],
                ["Corrections", String(s.stats.corrections)],
                ["Your verdicts", `${s.stats.good} good · ${s.stats.bad} fixed`],
              ].map(([k, v]) => (
                <div key={k} className="border-t border-rule pt-2">
                  <div className="slug text-mute">{k}</div>
                  <div className="mt-1 font-display text-[19px] leading-tight font-semibold">
                    {v}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 border-t border-ink pt-4">
              <div className="slug text-wire">Its body · where it lives</div>
              <div className="mt-3 space-y-2">
                {(data?.brains ?? []).map((b) => (
                  <div key={b.id} className="flex items-baseline gap-2.5">
                    <span
                      className={`h-[7px] w-[7px] shrink-0 ${
                        b.usable && b.fail <= b.ok ? "bg-wire" : "bg-rule"
                      }`}
                    />
                    <span className="font-serif text-[14px] font-semibold text-ink">
                      {b.label}
                    </span>
                    <span className="slug text-mute">{b.company}</span>
                    <span className="slug ml-auto tnum text-mute">
                      {b.latencyMs ? `${b.latencyMs}ms` : "—"} · {b.ok}ok/{b.fail}fail
                    </span>
                  </div>
                ))}
              </div>
              <p className="slug mt-4 leading-[1.9] text-mute">
                One brain failing is not an outage. The creature marks it,
                remembers, and answers on another.
              </p>
            </div>
          </div>

          <div>
            <div className="slug border-b border-ink pb-2 text-ink">
              Diary · written by itself
            </div>
            {data?.reflection && (
              <p className="mt-5 border-l-2 border-wire pl-4 font-display text-[19px] leading-[1.42] italic">
                “{data.reflection}”
              </p>
            )}
            <div className="mt-6 space-y-5">
              {(data?.diary ?? []).map((d) => (
                <article key={d.id} className="border-t border-rule pt-3">
                  <div className="slug flex items-center gap-2 text-mute">
                    <span className="text-wire">{d.mood}</span>
                    <span className="text-rule">/</span>
                    <span className="tnum">
                      {new Date(d.createdAt).toLocaleString(undefined, {
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                    <span className="ml-auto tnum">
                      {d.turns} turns · e{d.energy} c{d.curiosity}
                    </span>
                  </div>
                  <h3 className="mt-2 font-display text-[17px] leading-tight font-semibold">
                    {d.headline}
                  </h3>
                  <p className="mt-1.5 font-serif text-[14px] leading-[1.6] text-ink-soft">
                    {d.body}
                  </p>
                </article>
              ))}
              {!data?.diary?.length && (
                <p className="slug leading-[1.9] text-mute">
                  No entries yet. Wake it above and it will start keeping itself
                  company.
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* -------------------------------- settings ------------------------------ */

export function SettingsPanel({
  settings,
  onClose,
  onSave,
}: {
  settings: WireSettings;
  onClose: () => void;
  onSave: (s: WireSettings) => void;
}) {
  const [brain, setBrain] = useState(settings.brain || "auto");
  const [keys, setKeys] = useState<Record<string, string>>(settings.keys ?? {});
  const [models, setModels] = useState<Record<string, string>>(settings.models ?? {});

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-ink/55 px-5 py-8">
      <div className="rise-in w-full max-w-[720px] border border-ink bg-paper">
        <div className="flex items-start justify-between border-b border-ink px-6 py-4">
          <div>
            <div className="slug text-wire">Brain vault</div>
            <h2 className="mt-1 font-display text-[24px] leading-none font-bold tracking-[-0.02em]">
              Choose the mind, or let it choose
            </h2>
          </div>
          <button onClick={onClose} aria-label="Close settings" className="p-1">
            <span className="block h-[18px] w-[18px] rotate-45 border-t border-ink" />
          </button>
        </div>

        <div className="px-6 py-6">
          <p className="font-serif text-[14.5px] leading-[1.6] text-ink-soft">
            The desk lives on the servers of many companies at once — Claude,
            GPT, Gemini, Groq, Mistral, DeepSeek, Grok, OpenRouter, Together,
            Cerebras, your own machine, and a free public brain. Leave it on{" "}
            <strong>Auto</strong> and it picks the best mind for each question
            and migrates when one goes dark. Keys stay in this browser and are
            sent only to the company they belong to.
          </p>

          <div className="mt-6">
            <div className="slug text-mute">Mind for this desk</div>
            <div className="mt-2.5 flex flex-wrap gap-2">
              {["auto", ...BRAINS.map((b) => b.id)].map((id) => {
                const b = BRAINS.find((x) => x.id === id);
                return (
                  <button
                    key={id}
                    onClick={() => setBrain(id)}
                    className={`slug border px-3 py-2 transition-colors ${
                      brain === id
                        ? "border-wire bg-wire text-paper"
                        : "border-rule text-ink-soft hover:border-ink hover:text-ink"
                    }`}
                  >
                    {id === "auto" ? "Auto mesh" : `${b?.label} · ${b?.company}`}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mt-8">
            <div className="slug border-b border-ink pb-2 text-mute">
              Key vault · one per company
            </div>
            <div className="mt-4 space-y-4">
              {BRAINS.map((b) => (
                <div
                  key={b.id}
                  className="grid items-center gap-3 border-b border-rule pb-4 sm:grid-cols-[190px_minmax(0,1fr)_180px]"
                >
                  <div>
                    <div className="font-display text-[15px] leading-tight font-semibold">
                      {b.label}
                    </div>
                    <div className="slug mt-0.5 text-mute">
                      {b.keyless ? "no key needed" : b.envKeys[0] ?? "key"}
                    </div>
                  </div>
                  <input
                    type="password"
                    value={keys[b.id] ?? ""}
                    onChange={(e) => setKeys({ ...keys, [b.id]: e.target.value })}
                    placeholder={b.keyless ? "connected" : "paste key"}
                    className="w-full border border-rule bg-paper-2/50 px-3 py-2 font-mono text-[12px] text-ink placeholder:text-mute/70"
                  />
                  <input
                    value={models[b.id] ?? ""}
                    onChange={(e) => setModels({ ...models, [b.id]: e.target.value })}
                    placeholder={b.defaultModel}
                    className="w-full border border-rule bg-paper-2/50 px-3 py-2 font-mono text-[12px] text-ink placeholder:text-mute/70"
                  />
                </div>
              ))}
            </div>
            <p className="slug mt-3 leading-[1.9] text-mute">
              Left column: the company. Middle: its key. Right: the model to
              use — leave blank for the default.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 border-t border-rule px-6 py-4">
          <button
            onClick={() =>
              onSave({
                ...settings,
                brain,
                keys,
                models,
                provider: brain === "auto" ? "open" : brain,
                apiKey: keys[brain] ?? "",
                model: models[brain] ?? "",
              })
            }
            className="slug bg-wire px-5 py-2.5 text-paper transition-opacity hover:opacity-90"
          >
            Save to this browser
          </button>
          <button
            onClick={onClose}
            className="slug border border-rule px-5 py-2.5 text-ink-soft hover:border-ink hover:text-ink"
          >
            Cancel
          </button>
          <span className="slug ml-auto text-mute">Stored locally</span>
        </div>
      </div>
    </div>
  );
}
