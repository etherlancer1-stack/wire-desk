"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Icon } from "./icons";

type Tool = { name: string; category: string; about: string; docs: string };
type Target = { id: string; name: string; host: string; scope: string; authorized: number };
type Finding = { severity: string; check: string; detail: string; fix: string };
type Summary = { high: number; medium: number; low: number; pass: number; score: number };

const SEV_COLOR: Record<string, string> = {
  high: "#e5484d",
  medium: "#f5a524",
  low: "#3b82f6",
  pass: "#10a37f",
};

function ScoreRing({ score }: { score: number }) {
  const r = 38;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative h-[100px] w-[100px]">
      <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
        <circle cx="50" cy="50" r={r} fill="none" stroke="currentColor" strokeWidth="8" className="text-white/10" />
        <circle
          cx="50"
          cy="50"
          r={r}
          fill="none"
          stroke={score > 70 ? "#10a37f" : score > 40 ? "#f5a524" : "#e5484d"}
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={`${(score / 100) * c} ${c}`}
          style={{ transition: "stroke-dasharray 1s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-[26px] leading-none font-black text-white">{score}</span>
        <span className="mt-1 text-[9px] font-semibold tracking-[0.16em] text-white/50 uppercase">
          score
        </span>
      </div>
    </div>
  );
}

export function SecurityPanel() {
  const [tools, setTools] = useState<Tool[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [installed, setInstalled] = useState<Record<string, boolean>>({});
  const [targets, setTargets] = useState<Target[]>([]);
  const [cat, setCat] = useState("all");
  const [search, setSearch] = useState("");
  const [host, setHost] = useState("");
  const [scope, setScope] = useState("owned");
  const [device, setDevice] = useState("server");
  const [declared, setDeclared] = useState(false);
  const [findings, setFindings] = useState<Finding[]>([]);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [activeTarget, setActiveTarget] = useState("");

  const load = useCallback(() => {
    fetch("/api/security")
      .then((r) => r.json())
      .then((d) => {
        setTools(d.tools ?? []);
        setCategories(d.categories ?? []);
        setInstalled(d.installed ?? {});
        setTargets(d.targets ?? []);
      })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(
    () =>
      tools.filter(
        (t) =>
          (cat === "all" || t.category === cat) &&
          (!search ||
            t.name.toLowerCase().includes(search.toLowerCase()) ||
            t.about.toLowerCase().includes(search.toLowerCase())),
      ),
    [tools, cat, search],
  );

  const catCounts = useMemo(() => {
    const map: Record<string, number> = { all: tools.length };
    for (const t of tools) map[t.category] = (map[t.category] ?? 0) + 1;
    return map;
  }, [tools]);

  const addTarget = async () => {
    const d = await fetch("/api/security", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "add",
        host,
        scope,
        name: host,
        notes: `${device} · owner declaration confirmed ${new Date().toISOString().slice(0, 10)}`,
      }),
    }).then((r) => r.json());
    setNote(
      d.ok
        ? `› ${host} registered as your ${device}. Ownership recorded; assessments are logged against this declaration.`
        : d.error ?? "Could not add that target.",
    );
    if (d.ok) {
      setHost("");
      setDeclared(false);
    }
    load();
  };

  const assessTarget = async (h: string) => {
    setBusy(true);
    setActiveTarget(h);
    setNote(`› assessing ${h} — non-destructive checks, scoped execution…`);
    setFindings([]);
    setSummary(null);
    try {
      const d = await fetch("/api/security", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "assess", host: h }),
      }).then((r) => r.json());
      if (d.ok) {
        setFindings(d.findings ?? []);
        setSummary(d.summary ?? null);
        setNote(
          `› scan complete — ${d.summary?.high ?? 0} high · ${d.summary?.medium ?? 0} medium · ${d.summary?.pass ?? 0} passed`,
        );
      } else setNote(`› refused — ${d.error ?? "out of scope"}`);
    } catch {
      setNote("› the assessment failed");
    }
    setBusy(false);
  };

  const verified = Object.values(installed).filter(Boolean).length;

  return (
    <div>
      {/* ============================ hero ============================ */}
      <div className="wire-terminal wire-sweep relative px-6 py-8 sm:px-9 sm:py-10">
        <div className="relative z-10 flex flex-wrap items-end gap-10">
          <div className="min-w-[280px] flex-1">
            <div className="flex items-center gap-2.5">
              <span className="glow-dot h-[8px] w-[8px] rounded-full bg-[#10a37f] text-[#10a37f]" />
              <span className="text-[10px] font-bold tracking-[0.22em] text-[#10a37f] uppercase">
                security lab · armed · scoped
              </span>
            </div>
            <h1 className="mt-4 text-[clamp(30px,4.2vw,52px)] leading-[0.98] font-black tracking-[-0.035em] text-white">
              Offensive security,
              <br />
              <span className="font-light text-white/70">run like engineering.</span>
            </h1>
            <p className="mt-4 max-w-[58ch] text-[13.5px] leading-[1.75] text-white/60">
              Kali-aligned tooling, DNS-proven target ownership, non-destructive
              assessments and server-enforced scope. Every tool status is
              verified against the host it claims to run on.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {["Non-destructive", "Scope enforced", "Audit logged", "Owner approved"].map((t) => (
                <span
                  key={t}
                  className="rounded-full border border-white/15 px-3 py-1.5 text-[10px] font-semibold tracking-[0.12em] text-white/70 uppercase"
                >
                  ✓ {t}
                </span>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-9">
            {[
              ["Tools", String(tools.length)],
              ["Categories", String(categories.length)],
              ["Verified", String(verified)],
              ["Targets", String(targets.length)],
            ].map(([k, v]) => (
              <div key={k}>
                <div className="text-[30px] leading-none font-black text-white tabular-nums">{v}</div>
                <div className="mt-1.5 text-[9.5px] font-semibold tracking-[0.18em] text-white/45 uppercase">
                  {k}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative z-10 mt-7 rounded-xl border border-white/10 bg-black/30 px-4 py-3 font-mono text-[11px] leading-[1.85] text-white/55">
          <div>
            <span className="text-[#10a37f]">wire@lab</span>
            <span className="text-white/35">:~$</span> scope --status
          </div>
          <div>
            targets: {targets.length} authorized · blocked: localhost, private
            ranges, link-local, metadata services · redirects: not followed
          </div>
          <div>
            <span className="text-[#10a37f]">wire@lab</span>
            <span className="text-white/35">:~$</span> registry --verified
            <span className="ml-2 inline-block h-[7px] w-[7px] animate-pulse rounded-full bg-[#10a37f] align-middle" />
          </div>
        </div>
      </div>

      {note && (
        <div className="mt-5 rounded-xl border border-wire/40 bg-wire/[0.08] px-4 py-3">
          <p className="font-mono text-[12px] leading-[1.7] text-ink">{note}</p>
        </div>
      )}

      {/* ======================= scope + results ======================= */}
      <div className="mt-10 grid gap-10 lg:grid-cols-[minmax(0,0.92fr)_minmax(0,1.08fr)]">
        <div>
          <div className="flex items-center justify-between">
            <h2 className="text-[19px] font-black tracking-[-0.02em]">Authorized scope</h2>
            <span className="wire-chip" data-active="true">
              enforced server-side
            </span>
          </div>

          <p className="mt-3 text-[13.5px] leading-[1.7] text-ink-soft">
            Only systems you own or are explicitly permitted to test. Ownership
            is proven by DNS TXT record before anything is scanned.
          </p>

          <div className="mt-4 flex flex-wrap gap-2">
            <input
              value={host}
              onChange={(e) => setHost(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && declared && void addTarget()}
              placeholder="yourdomain.com or public IP of your own device"
              className="min-w-[190px] flex-1 rounded-xl border border-rule bg-paper-2/70 px-4 py-3 font-mono text-[12.5px] text-ink placeholder:text-mute/70"
            />
            <select
              value={device}
              onChange={(e) => setDevice(e.target.value)}
              className="rounded-xl border border-rule bg-paper-2/70 px-3.5 py-3 text-[12px] font-semibold text-ink"
            >
              <option value="server">my server</option>
              <option value="phone">my phone</option>
              <option value="router">my router</option>
              <option value="site">my website</option>
              <option value="lab-vm">my lab VM</option>
            </select>
            <select
              value={scope}
              onChange={(e) => setScope(e.target.value)}
              className="rounded-xl border border-rule bg-paper-2/70 px-3.5 py-3 text-[12px] font-semibold text-ink"
            >
              <option value="owned">owned</option>
              <option value="staging">staging</option>
              <option value="lab">lab</option>
            </select>
            <button
              onClick={() => void addTarget()}
              disabled={!declared}
              className="rounded-xl bg-wire px-6 py-3 text-[12px] font-bold tracking-[0.06em] text-paper uppercase hover:opacity-90 disabled:opacity-40"
            >
              Authorize
            </button>
          </div>

          <label className="mt-3 flex cursor-pointer items-start gap-2.5">
            <input
              type="checkbox"
              checked={declared}
              onChange={(e) => setDeclared(e.target.checked)}
              className="mt-[3px] h-4 w-4 accent-[#10a37f]"
            />
            <span className="text-[12px] leading-[1.6] text-ink-soft">
              I confirm this system <strong>belongs to me or I hold written
              authorization</strong> to test it. Every assessment is logged
              against this declaration, and anything not declared here is
              refused by the server.
            </span>
          </label>

          <div className="mt-5 space-y-2.5">
            {targets.map((t) => (
              <div
                key={t.id}
                className={`wire-card flex items-center gap-3 px-4 py-3.5 ${
                  activeTarget === t.host ? "border-wire" : ""
                }`}
              >
                <span className="glow-dot h-[8px] w-[8px] rounded-full bg-wire text-wire" />
                <div className="min-w-0 flex-1">
                  <div className="truncate font-mono text-[13px] font-semibold">{t.host}</div>
                  <div className="text-[10px] font-semibold tracking-[0.12em] text-mute uppercase">
                    {t.scope} · ownership verified · logged
                  </div>
                </div>
                <button
                  onClick={() => void assessTarget(t.host)}
                  disabled={busy}
                  className="rounded-lg border border-ink px-4 py-2 text-[11px] font-bold tracking-[0.08em] uppercase hover:bg-wire hover:border-wire hover:text-paper disabled:opacity-40"
                >
                  {busy && activeTarget === t.host ? "scanning…" : "assess"}
                </button>
              </div>
            ))}
            {!targets.length && (
              <div className="rounded-xl border border-dashed border-rule px-4 py-8 text-center">
                <p className="text-[13px] text-mute">
                  No authorized targets. Add one you own to unlock assessments.
                </p>
              </div>
            )}
          </div>

          {summary && (
            <div className="mt-9">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <h2 className="text-[19px] font-black tracking-[-0.02em]">Assessment report</h2>
                  <div className="mt-1 font-mono text-[11.5px] text-mute">{activeTarget}</div>
                  <div className="mt-3 flex gap-2">
                    {(["high", "medium", "low", "pass"] as const).map((s) => (
                      <div key={s} className="wire-tile px-3 py-2">
                        <div
                          className="text-[18px] leading-none font-black tabular-nums"
                          style={{ color: SEV_COLOR[s] }}
                        >
                          {(summary as Summary)[s]}
                        </div>
                        <div className="mt-1 text-[9px] font-semibold tracking-[0.14em] text-mute uppercase">
                          {s}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <ScoreRing score={summary.score} />
              </div>

              <div className="scroll-pane mt-6 space-y-2.5">
                {findings.map((f, i) => (
                  <article
                    key={i}
                    className="wire-card severity-stripe px-4 py-3.5"
                    style={{ borderLeftColor: SEV_COLOR[f.severity] ?? SEV_COLOR.pass }}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="text-[9.5px] font-bold tracking-[0.16em] uppercase"
                        style={{ color: SEV_COLOR[f.severity] ?? SEV_COLOR.pass }}
                      >
                        {f.severity}
                      </span>
                      <span className="font-mono text-[12px] font-semibold">{f.check}</span>
                    </div>
                    <p className="mt-1.5 text-[13px] leading-[1.6] text-ink">{f.detail}</p>
                    {f.fix && (
                      <p className="mt-1.5 text-[12px] leading-[1.55] text-ink-soft italic">
                        Fix: {f.fix}
                      </p>
                    )}
                  </article>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* ========================== registry ========================= */}
        <div>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-[19px] font-black tracking-[-0.02em]">
              Tool registry <span className="text-mute">/ {filtered.length}</span>
            </h2>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="search 200+ tools…"
              className="w-[190px] rounded-xl border border-rule bg-paper-2/70 px-3.5 py-2.5 text-[12px] text-ink placeholder:text-mute/70"
            />
          </div>

          <div className="mt-4 flex flex-wrap gap-1.5">
            {["all", ...categories].map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className="wire-chip"
                data-active={cat === c}
              >
                {c}
                <span className="opacity-60 tabular-nums">{catCounts[c] ?? 0}</span>
              </button>
            ))}
          </div>

          <div className="scroll-pane mt-5 grid min-h-0 gap-2.5 sm:grid-cols-2">
            {filtered.map((t) => (
              <article key={t.name} className="wire-card flex flex-col px-4 py-3.5">
                <div className="flex items-baseline gap-2">
                  <span className="font-mono text-[12.5px] font-bold">{t.name}</span>
                  <span
                    className={`ml-auto inline-flex shrink-0 items-center gap-1.5 rounded-full px-2 py-[3px] text-[8.5px] font-bold tracking-[0.12em] uppercase ${
                      installed[t.name] ? "bg-wire text-paper" : "border border-rule text-mute"
                    }`}
                  >
                    <span
                      className={`h-[5px] w-[5px] rounded-full ${
                        installed[t.name] ? "bg-paper" : "bg-mute/60"
                      }`}
                    />
                    {installed[t.name] ? "verified" : "not installed"}
                  </span>
                </div>
                <div className="mt-1.5 text-[9.5px] font-bold tracking-[0.16em] text-wire uppercase">
                  {t.category}
                </div>
                <p className="mt-1.5 flex-1 text-[12px] leading-[1.55] text-ink-soft">{t.about}</p>
                <div className="mt-2 rounded-lg border border-rule bg-paper-2/50 px-2.5 py-1.5">
                  <div className="truncate font-mono text-[10px] text-ink-soft">
                    $ {(t as any).install || "see docs"}
                  </div>
                  <div className="mt-0.5 text-[9px] font-semibold tracking-[0.1em] text-mute uppercase">
                    needs: {(t as any).permissions || "own systems only"}
                  </div>
                </div>
                <a
                  href={t.docs}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="mt-2.5 inline-flex items-center gap-1 text-[10.5px] font-bold tracking-[0.1em] text-mute uppercase hover:text-wire"
                >
                  official docs <Icon name="send" className="h-2.5 w-2.5" />
                </a>
              </article>
            ))}
          </div>

          <div className="wire-terminal mt-8 px-5 py-4">
            <div className="relative z-10 font-mono text-[11px] leading-[1.9] text-white/60">
              <div>
                <span className="text-[#10a37f]">policy</span> — heavy offensive
                tooling runs on an isolated Kali VM, never on the server that
                serves your desk.
              </div>
              <div>
                <span className="text-[#10a37f]">policy</span> — invasive tests
                require explicit authorization per target and are written to the
                audit log.
              </div>
              <div>
                <span className="text-[#10a37f]">policy</span> — a tool is shown
                as installed only when it is verified present. Nothing here is
                faked.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
