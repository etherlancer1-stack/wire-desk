"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Icon } from "./icons";
import { PanelHead } from "./Panels";

type Deployment = {
  id: string;
  project: string;
  provider: string;
  url: string;
  status: string;
  log: string;
  commit: string;
  createdAt: string;
};

type Provider = {
  id: string;
  label: string;
  docs: string;
  needs: string;
  price: string;
  launch: string;
};

const STATUS: Record<string, string> = {
  live: "bg-wire text-paper",
  building: "bg-[#f5a524] text-ink",
  pending: "border border-rule text-mute",
  failed: "bg-[#e5484d] text-paper",
  "rolled back": "border border-rule text-mute",
};

export function DeployPanel() {
  const [rows, setRows] = useState<Deployment[]>([]);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [form, setForm] = useState({ project: "WIRE", provider: "render", url: "", commit: "", log: "" });
  const [note, setNote] = useState("");

  const load = useCallback(() => {
    fetch("/api/deployments")
      .then((r) => r.json())
      .then((d) => {
        setRows(d.deployments ?? []);
        setProviders(d.providers ?? []);
      })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const record = async () => {
    const d = await fetch("/api/deployments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "record", ...form, status: "live" }),
    }).then((r) => r.json());
    setNote(
      d.deployment
        ? `Recorded ${form.project} on ${form.provider}. The dashboard reflects what the provider reports.`
        : "Could not record the deployment.",
    );
    load();
  };

  return (
    <div>
      <PanelHead
        slug={`Deployments · ${rows.length} recorded · ${providers.length} providers`}
        title="Ship it online"
        lede="A deployment dashboard in the Vercel mould: provider connections, launch links, environment requirements, honest pricing, and a history of what is actually live. Nothing here claims a deploy that the provider did not confirm — records are written from real deployment URLs."
        action={
          <a
            href="https://render.com/new/web-service"
            target="_blank"
            rel="noreferrer noopener"
            className="flex items-center gap-2 rounded-full bg-wire px-5 py-2.5 text-[13px] font-semibold text-paper hover:opacity-90"
          >
            Deploy now <Icon name="send" className="h-3.5 w-3.5" />
          </a>
        }
      />

      {note && (
        <div className="mt-5 flex items-start gap-3 rounded-xl border border-wire/40 bg-wire/[0.07] px-4 py-3">
          <span className="mt-[6px] h-[7px] w-[7px] shrink-0 rounded-full bg-wire" />
          <p className="text-[13px] leading-[1.6]">{note}</p>
        </div>
      )}

      {/* --------------------------- history --------------------------- */}
      <div className="mt-8">
        <div className="flex items-center justify-between border-b border-ink pb-2.5">
          <h2 className="text-[17px] font-bold tracking-[-0.015em]">Deployment history</h2>
          <div className="flex flex-wrap items-center gap-2">
            <input
              value={form.project}
              onChange={(e) => setForm({ ...form, project: e.target.value })}
              placeholder="project"
              className="w-[120px] rounded-lg border border-rule bg-paper-2/60 px-2.5 py-1.5 text-[11px] text-ink"
            />
            <input
              value={form.url}
              onChange={(e) => setForm({ ...form, url: e.target.value })}
              placeholder="https://your-app.onrender.com"
              className="w-[230px] rounded-lg border border-rule bg-paper-2/60 px-2.5 py-1.5 font-mono text-[11px] text-ink placeholder:text-mute/70"
            />
            <button
              onClick={() => void record()}
              className="rounded-lg bg-wire px-3.5 py-1.5 text-[11px] font-semibold text-paper hover:opacity-90"
            >
              Record live URL
            </button>
          </div>
        </div>

        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[620px] border-collapse">
            <thead>
              <tr className="border-b border-rule">
                {["Project", "Provider", "Status", "URL", "Recorded"].map((h) => (
                  <th
                    key={h}
                    className="py-2 pr-4 text-left text-[10px] font-semibold tracking-[0.12em] text-mute uppercase"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((d) => (
                <tr key={d.id} className="border-b border-rule hover:bg-paper-2/40">
                  <td className="py-3 pr-4 text-[13px] font-semibold">{d.project}</td>
                  <td className="py-3 pr-4 text-[12px] text-ink-soft">{d.provider}</td>
                  <td className="py-3 pr-4">
                    <span
                      className={`rounded-full px-2.5 py-1 text-[9.5px] font-semibold tracking-[0.1em] uppercase ${
                        STATUS[d.status] ?? STATUS.pending
                      }`}
                    >
                      {d.status}
                    </span>
                  </td>
                  <td className="py-3 pr-4">
                    {d.url ? (
                      <a
                        href={d.url}
                        target="_blank"
                        rel="noreferrer noopener"
                        className="font-mono text-[11.5px] text-wire hover:underline"
                      >
                        {d.url.replace(/^https?:\/\//, "").slice(0, 38)}
                      </a>
                    ) : (
                      <span className="text-[11.5px] text-mute">—</span>
                    )}
                  </td>
                  <td className="py-3 text-[11px] text-mute">
                    {new Date(d.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!rows.length && (
            <p className="mt-4 rounded-xl border border-dashed border-rule px-4 py-6 text-center text-[13px] text-mute">
              No deployments recorded yet. Launch one with a provider below, then
              record its live URL here — the desk tracks what is actually online.
            </p>
          )}
        </div>
      </div>

      {/* --------------------------- providers ------------------------- */}
      <div className="mt-10">
        <div className="flex items-center justify-between border-b border-ink pb-2.5">
          <h2 className="text-[17px] font-bold tracking-[-0.015em]">Where it can run</h2>
          <span className="rounded-full border border-rule px-2.5 py-1 text-[10px] font-semibold tracking-[0.12em] text-mute uppercase">
            your account, your bill
          </span>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {providers.map((p) => (
            <article
              key={p.id}
              className="flex flex-col rounded-xl border border-rule px-4 py-4 transition-all hover:-translate-y-[1px] hover:border-ink"
            >
              <div className="flex items-center gap-2.5">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-panel text-paper">
                  <Icon name="arrow" className="h-3.5 w-3.5" />
                </span>
                <h3 className="text-[15px] font-bold">{p.label}</h3>
              </div>
              <dl className="mt-3 space-y-1.5 text-[11.5px] leading-[1.55]">
                <div className="flex gap-2">
                  <dt className="w-[62px] shrink-0 font-semibold tracking-[0.08em] text-mute uppercase">
                    needs
                  </dt>
                  <dd className="text-ink-soft">{p.needs}</dd>
                </div>
                <div className="flex gap-2">
                  <dt className="w-[62px] shrink-0 font-semibold tracking-[0.08em] text-mute uppercase">
                    price
                  </dt>
                  <dd className="text-ink-soft">{p.price}</dd>
                </div>
              </dl>
              <div className="mt-4 flex items-center gap-2">
                <a
                  href={p.launch}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="rounded-lg bg-ink px-3.5 py-2 text-[11.5px] font-semibold text-paper hover:opacity-90"
                >
                  Launch
                </a>
                <a
                  href={p.docs}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="rounded-lg border border-rule px-3.5 py-2 text-[11.5px] font-semibold text-mute hover:border-ink hover:text-ink"
                >
                  Docs
                </a>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-8 rounded-xl border border-rule px-5 py-4">
          <h3 className="text-[13px] font-bold tracking-[0.06em] uppercase">
            What the desk deploys for you
          </h3>
          <ul className="mt-2.5 space-y-1.5 text-[12.5px] leading-[1.7] text-ink-soft">
            <li>
              • <strong>Environment checklist</strong> — DATABASE_URL,
              OPENROUTER_API_KEY, WIRE_OWNER_KEY, NEXT_PUBLIC_SITE_URL.
            </li>
            <li>
              • <strong>Build definition</strong> — Dockerfile and render.yaml in
              the source, so the provider builds it without configuration.
            </li>
            <li>
              • <strong>Private builds</strong> — every site it generates is
              already hosted at its own unguessable link on this server.
            </li>
            <li>
              • <strong>Health monitoring</strong> — /api/health for the
              provider's checks and automatic restarts.
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
