"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Icon } from "./icons";
import { PanelHead } from "./Panels";

type Finding = {
  severity: string;
  file: string;
  line: number;
  issue: string;
  fix: string;
};

type PatchRow = {
  id: string;
  file: string;
  kind: string;
  title: string;
  rationale: string;
  body: string;
  status: string;
  createdAt: string;
};

type Data = {
  analysis: {
    score: number;
    findings: Finding[];
    metrics: Record<string, number>;
  };
  runs: { id: string; kind: string; report: string; score: number; createdAt: string }[];
  patches: PatchRow[];
  daily: { ran: boolean; report: string };
  ownedFiles: { file: string; lines: number; bytes: number }[];
};

export function EngineerPanel() {
  const [data, setData] = useState<Data | null>(null);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");

  const load = useCallback(() => {
    fetch("/api/engineer")
      .then((r) => r.json())
      .then(setData)
      .catch(() => setData(null));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const upgrade = async () => {
    setBusy(true);
    setNote("Analysing its own code and writing patches…");
    try {
      const d = await fetch("/api/engineer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "upgrade" }),
      }).then((r) => r.json());
      setNote(`${d.report} — ${d.patches?.length ?? 0} patch(es) filed.`);
    } catch {
      setNote("The cycle failed and changed nothing.");
    }
    setBusy(false);
    load();
  };

  const act = async (action: string, id: string) => {
    const d = await fetch("/api/engineer", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, id }),
    }).then((r) => r.json());
    setNote(d.message ?? (d.ok ? "Done." : "Refused."));
    load();
  };

  const a = data?.analysis;
  const score = a?.score ?? 0;

  return (
    <div>
      <PanelHead
        slug={`Resident engineer · system score ${score}/100`}
        title="It rewrites its own code"
        lede="Inside the desk there is an agent whose job is the desk itself. It reads its own source code, finds real defects — unbounded network calls, swallowed errors, functions too long to reason about — writes precise patches, and applies them under version control. Every day it runs the cycle again by itself."
        action={
          <button
            onClick={() => void upgrade()}
            disabled={busy}
            className="slug flex items-center gap-2 border border-ink px-4 py-2.5 hover:bg-wire hover:border-wire hover:text-paper disabled:opacity-40"
          >
            <Icon name="refresh" className="h-3.5 w-3.5" />
            {busy ? "Working…" : "Run upgrade cycle"}
          </button>
        }
      />

      {note && (
        <p className="slug mt-5 border-l-2 border-wire py-2 pl-4 leading-[1.9] text-wire">
          {note}
        </p>
      )}

      <div className="mt-8 grid grid-cols-2 gap-x-8 gap-y-5 sm:grid-cols-4">
        {[
          ["Score", `${score}/100`],
          ["Files owned", String(a?.metrics?.files ?? 0)],
          ["Lines of code", String(a?.metrics?.lines ?? 0)],
          ["Functions", String(a?.metrics?.functions ?? 0)],
          ["High defects", String(a?.metrics?.high ?? 0)],
          ["Medium", String(a?.metrics?.medium ?? 0)],
          ["Low", String(a?.metrics?.low ?? 0)],
          ["Daily cycle", data?.daily?.ran ? "ran now" : "scheduled"],
        ].map(([k, v]) => (
          <div key={k} className="border-t border-ink pt-2">
            <div className="slug text-mute">{k}</div>
            <div className="mt-1 font-display text-[22px] leading-none font-black">{v}</div>
          </div>
        ))}
      </div>

      <div className="mt-10 grid gap-10 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)]">
        <div>
          <div className="slug border-b border-ink pb-2 text-ink">
            Findings from its own source
          </div>
          <div className="mt-4 space-y-3.5">
            {(a?.findings ?? []).slice(0, 12).map((f, i) => (
              <div key={i} className="border-t border-rule pt-2.5">
                <div className="slug flex items-center gap-2 text-mute">
                  <span
                    className={
                      f.severity === "high"
                        ? "text-wire"
                        : f.severity === "medium"
                          ? "text-ink"
                          : "text-mute"
                    }
                  >
                    {f.severity}
                  </span>
                  <span className="text-rule">/</span>
                  <span className="truncate">
                    {f.file}:{f.line}
                  </span>
                </div>
                <p className="mt-1.5 font-serif text-[14.5px] leading-[1.5]">{f.issue}</p>
                <p className="mt-1 font-serif text-[13px] leading-[1.5] text-mute italic">
                  {f.fix}
                </p>
              </div>
            ))}
            {!a?.findings?.length && (
              <p className="slug leading-[1.9] text-mute">
                No defects found. The codebase is clean on this pass.
              </p>
            )}
          </div>

          <div className="slug mt-9 border-b border-ink pb-2 text-ink">
            Files it owns and may rewrite
          </div>
          <div className="mt-3 space-y-1.5">
            {(data?.ownedFiles ?? []).map((f) => (
              <div key={f.file} className="flex items-baseline gap-3">
                <span className="font-mono text-[12px] text-ink-soft">{f.file}</span>
                <span className="slug ml-auto tnum text-mute">
                  {f.lines} lines · {(f.bytes / 1024).toFixed(1)} kb
                </span>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="slug border-b border-ink pb-2 text-ink">
            Patches it has written
          </div>
          <div className="mt-4 space-y-5">
            {(data?.patches ?? []).map((p) => (
              <article key={p.id} className="border-t border-rule pt-3">
                <div className="slug flex items-center gap-2 text-mute">
                  <span
                    className={
                      p.status === "applied"
                        ? "text-wire"
                        : p.status === "reverted"
                          ? "text-mute"
                          : "text-ink"
                    }
                  >
                    {p.status}
                  </span>
                  <span className="text-rule">/</span>
                  <span>{p.kind}</span>
                  <span className="text-rule">/</span>
                  <span className="truncate">{p.file}</span>
                </div>
                <h3 className="mt-1.5 font-display text-[16.5px] leading-tight font-semibold">
                  {p.title}
                </h3>
                <p className="mt-1 font-serif text-[13px] leading-[1.5] text-ink-soft">
                  {p.rationale}
                </p>
                <details className="mt-2">
                  <summary className="slug cursor-pointer text-mute hover:text-wire">
                    inspect the change
                  </summary>
                  <pre className="mt-2 overflow-x-auto bg-panel px-3 py-2.5 font-mono text-[11px] leading-[1.6] whitespace-pre-wrap text-paper/85">
                    {p.body.slice(0, 1600)}
                  </pre>
                </details>
                <div className="mt-2.5 flex items-center gap-2">
                  {p.status === "proposed" ? (
                    <button
                      onClick={() => void act("apply", p.id)}
                      className="slug border border-ink px-3 py-1.5 hover:bg-wire hover:border-wire hover:text-paper"
                    >
                      Apply
                    </button>
                  ) : (
                    <button
                      onClick={() => void act("revert", p.id)}
                      className="slug border border-rule px-3 py-1.5 text-mute hover:border-wire hover:text-wire"
                    >
                      Revert
                    </button>
                  )}
                </div>
              </article>
            ))}
            {!data?.patches?.length && (
              <p className="slug leading-[1.9] text-mute">
                No patches yet. Run the upgrade cycle and the engineer will file
                its first changes here for review.
              </p>
            )}
          </div>

          <div className="slug mt-9 border-b border-ink pb-2 text-ink">Cycle history</div>
          <div className="mt-3 space-y-3">
            {(data?.runs ?? []).map((r) => (
              <div key={r.id} className="border-t border-rule pt-2.5">
                <div className="slug flex items-center gap-2 text-mute">
                  <span className="text-wire">{r.kind}</span>
                  <span className="tnum">score {r.score}</span>
                  <span className="ml-auto tnum">
                    {new Date(r.createdAt).toLocaleString(undefined, {
                      month: "short",
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                </div>
                <p className="mt-1.5 font-serif text-[13px] leading-[1.5] text-ink-soft">
                  {r.report}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
