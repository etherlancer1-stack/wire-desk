import {
  integer,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

export const brains = pgTable("brains", {
  id: text("id").primaryKey(), // brain id in the mesh
  label: text("label").notNull().default(""),
  company: text("company").notNull().default(""),
  model: text("model").notNull().default(""),
  ok: integer("ok").notNull().default(0),
  fail: integer("fail").notNull().default(0),
  latencyMs: integer("latency_ms").notNull().default(0),
  lastAlive: timestamp("last_alive", { withTimezone: true }),
  lastError: text("last_error").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const vitals = pgTable("vitals", {
  id: text("id").primaryKey().default("wire"),
  energy: integer("energy").notNull().default(60),
  curiosity: integer("curiosity").notNull().default(55),
  mood: integer("mood").notNull().default(65),
  ticks: integer("ticks").notNull().default(0),
  lastTick: timestamp("last_tick", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const diary = pgTable("diary", {
  id: uuid("id").primaryKey().defaultRandom(),
  headline: text("headline").notNull(),
  body: text("body").notNull().default(""),
  mood: text("mood").notNull().default("steady"),
  energy: integer("energy").notNull().default(50),
  curiosity: integer("curiosity").notNull().default(50),
  turns: integer("turns").notNull().default(0),
  learned: integer("learned").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type BrainHealth = typeof brains.$inferSelect;
export type Vitals = typeof vitals.$inferSelect;
export type DiaryEntry = typeof diary.$inferSelect;
