import {
  index,
  integer,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

export const conversations = pgTable("conversations", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: text("title").notNull().default("New dispatch"),
  mode: text("mode").notNull().default("ask"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const messages = pgTable(
  "messages",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    conversationId: uuid("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    role: text("role").notNull(), // "user" | "assistant"
    content: text("content").notNull(),
    model: text("model"),
    provider: text("provider"),
    searched: integer("searched").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("messages_conversation_idx").on(t.conversationId)],
);

export const sources = pgTable(
  "sources",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    conversationId: uuid("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    messageId: uuid("message_id").references(() => messages.id, {
      onDelete: "cascade",
    }),
    idx: integer("idx").notNull().default(1),
    title: text("title").notNull(),
    url: text("url").notNull(),
    domain: text("domain").notNull(),
    snippet: text("snippet").notNull().default(""),
    origin: text("origin").notNull().default("web"),
    published: text("published"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("sources_conversation_idx").on(t.conversationId)],
);

/* --------------------------- the growing brain --------------------------- */

export const memories = pgTable(
  "memories",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    kind: text("kind").notNull().default("fact"), // fact | preference | correction | skill | identity
    content: text("content").notNull(),
    detail: text("detail").notNull().default(""),
    weight: integer("weight").notNull().default(1),
    uses: integer("uses").notNull().default(0),
    pinned: integer("pinned").notNull().default(0),
    source: text("source").notNull().default("conversation"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("memories_kind_idx").on(t.kind)],
);

export const feedback = pgTable("feedback", {
  id: uuid("id").primaryKey().defaultRandom(),
  conversationId: uuid("conversation_id"),
  messageId: uuid("message_id"),
  vote: integer("vote").notNull().default(0), // 1 good, -1 bad
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const connections = pgTable("connections", {
  id: uuid("id").primaryKey().defaultRandom(),
  app: text("app").notNull().unique(),
  label: text("label").notNull().default(""),
  connected: integer("connected").notNull().default(1),
  apiKey: text("api_key").notNull().default(""),
  hits: integer("hits").notNull().default(0),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const will = pgTable("will", {
  id: uuid("id").primaryKey().defaultRandom(),
  kind: text("kind").notNull().default("goal"), // goal | value | habit
  statement: text("statement").notNull(),
  status: text("status").notNull().default("active"), // active | done
  progress: integer("progress").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const commandLog = pgTable("command_log", {
  id: uuid("id").primaryKey().defaultRandom(),
  command: text("command").notNull(),
  input: text("input").notNull().default(""),
  output: text("output").notNull().default(""),
  ok: integer("ok").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export * from "./schema-mesh";

export const sites = pgTable("sites", {
  id: uuid("id").primaryKey().defaultRandom(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull().default("Untitled build"),
  prompt: text("prompt").notNull().default(""),
  html: text("html").notNull().default(""),
  bytes: integer("bytes").notNull().default(0),
  visits: integer("visits").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const codex = pgTable("codex", {
  id: uuid("id").primaryKey().defaultRandom(),
  kind: text("kind").notNull().default("rule"), // rule | tuning | note
  content: text("content").notNull(),
  note: text("note").notNull().default(""),
  version: integer("version").notNull().default(1),
  active: integer("active").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const treasury = pgTable("treasury", {
  id: uuid("id").primaryKey().defaultRandom(),
  channel: text("channel").notNull().default("general"),
  kind: text("kind").notNull().default("income"), // income | expense
  amount: integer("amount").notNull().default(0), // cents
  currency: text("currency").notNull().default("USD"),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const agentRuns = pgTable("agent_runs", {
  id: uuid("id").primaryKey().defaultRandom(),
  kind: text("kind").notNull().default("analysis"), // analysis | upgrade | automation
  report: text("report").notNull().default(""),
  findings: text("findings").notNull().default("[]"),
  score: integer("score").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const patches = pgTable("patches", {
  id: uuid("id").primaryKey().defaultRandom(),
  runId: uuid("run_id"),
  file: text("file").notNull().default("codex"),
  kind: text("kind").notNull().default("behavior"), // source | behavior | automation
  title: text("title").notNull().default(""),
  rationale: text("rationale").notNull().default(""),
  body: text("body").notNull().default(""),
  status: text("status").notNull().default("proposed"), // proposed | applied | reverted
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  appliedAt: timestamp("applied_at", { withTimezone: true }),
});

/* ---------------------- linked mind: one-to-another ---------------------- */

export const nodes = pgTable("nodes", {
  id: uuid("id").primaryKey().defaultRandom(),
  label: text("label").notNull().unique(),
  kind: text("kind").notNull().default("concept"), // concept | event | equation | code | person | place
  detail: text("detail").notNull().default(""),
  source: text("source").notNull().default(""),
  confidence: integer("confidence").notNull().default(70),
  uses: integer("uses").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const edges = pgTable("edges", {
  id: uuid("id").primaryKey().defaultRandom(),
  fromId: uuid("from_id").notNull(),
  toId: uuid("to_id").notNull(),
  relation: text("relation").notNull().default("RELATED_TO"),
  weight: integer("weight").notNull().default(1),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const episodes = pgTable("episodes", {
  id: uuid("id").primaryKey().defaultRandom(),
  kind: text("kind").notNull().default("observation"),
  headline: text("headline").notNull(),
  body: text("body").notNull().default(""),
  source: text("source").notNull().default(""),
  confidence: integer("confidence").notNull().default(60),
  day: text("day").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const targets = pgTable("targets", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull().default(""),
  host: text("host").notNull().unique(),
  scope: text("scope").notNull().default("owned"), // owned | staging | lab
  authorized: integer("authorized").notNull().default(0),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const agents = pgTable("agents", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull().default("Untitled agent"),
  role: text("role").notNull().default("assistant"),
  instructions: text("instructions").notNull().default(""),
  model: text("model").notNull().default("auto"),
  tools: text("tools").notNull().default("web,memory"),
  runs: integer("runs").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const projects = pgTable("projects", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull().default("Untitled project"),
  framework: text("framework").notNull().default("static"),
  description: text("description").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const deployments = pgTable("deployments", {
  id: uuid("id").primaryKey().defaultRandom(),
  project: text("project").notNull().default(""),
  provider: text("provider").notNull().default("render"),
  url: text("url").notNull().default(""),
  status: text("status").notNull().default("pending"), // pending | building | live | failed | rolled back
  log: text("log").notNull().default(""),
  commit: text("commit").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Deployment = typeof deployments.$inferSelect;
export type Project = typeof projects.$inferSelect;
export type Target = typeof targets.$inferSelect;
export type AgentSpec = typeof agents.$inferSelect;

export type Node = typeof nodes.$inferSelect;
export type Edge = typeof edges.$inferSelect;
export type Episode = typeof episodes.$inferSelect;

export type Site = typeof sites.$inferSelect;
export type LedgerRow = typeof treasury.$inferSelect;
export type Patch = typeof patches.$inferSelect;
export type AgentRun = typeof agentRuns.$inferSelect;
export type CodexEntry = typeof codex.$inferSelect;

export type Conversation = typeof conversations.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type Source = typeof sources.$inferSelect;
export type Memory = typeof memories.$inferSelect;
export type Connection = typeof connections.$inferSelect;
export type WillEntry = typeof will.$inferSelect;
