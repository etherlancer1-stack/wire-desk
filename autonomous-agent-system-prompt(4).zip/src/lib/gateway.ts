/**
 * WIRE — the integration gateway and the treasury.
 *
 * The desk does not log into three hundred apps one by one. It holds the
 * master keys to agent gateways (Composio, Pipedream, Nango, n8n, MCP) that
 * unlock hundreds of apps at once, keeps per-app credentials for the rest, and
 * runs a ledger of what it earns against what it spends to grow itself.
 */

import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { connections, treasury, will } from "@/db/schema";

export type GatewayGroup = { group: string; apps: string[] };
export type GatewayCategory = { category: string; blurb: string; groups: GatewayGroup[] };

/** The ecosystems an autonomous desk operates — the master keys first. */
export const ECOSYSTEM: GatewayCategory[] = [
  {
    category: "Integration & automation hubs",
    blurb: "The master keys. One credential here unlocks hundreds of apps at once through OAuth and MCP.",
    groups: [
      {
        group: "Agent tooling & MCP gateways",
        apps: ["Composio", "Nango", "Pipedream Connect", "Arcade", "Knit", "Agentic Fabriq", "Anthropic MCP", "OpenAI Function Calling", "LangChain Tools", "Toolhouse", "Speakeasy", "Stainless"],
      },
      {
        group: "Workflow orchestration",
        apps: ["n8n", "Zapier", "Make (Integromat)", "Workato", "Microsoft Power Automate", "Prefect", "Airflow", "Temporal", "Windmill", "Activepieces", "Automatisch", "Huginn"],
      },
      {
        group: "Browser & computer use",
        apps: ["Playwright", "Puppeteer", "Selenium", "Browserbase", "Stagehand", "Scrapy", "Firecrawl", "Apify", "Browserless", "ZenRows", "Crawlee", "Helium"],
      },
    ],
  },
  {
    category: "Cloud, compute & coding",
    blurb: "Where it writes, hosts and updates its own code, and pays for the machines it runs on.",
    groups: [
      {
        group: "Code & hosting",
        apps: ["GitHub", "GitLab", "Bitbucket", "Vercel", "Netlify", "Render", "Railway", "Fly.io", "Heroku", "Cloudflare Pages", "DigitalOcean App Platform", "Coolify"],
      },
      {
        group: "Cloud infrastructure",
        apps: ["AWS Bedrock", "AWS Lambda", "AWS EC2", "AWS S3", "Google Cloud Platform", "Microsoft Azure", "DigitalOcean", "Linode", "Cloudflare Workers", "Hetzner", "Vultr", "Oracle Cloud"],
      },
      {
        group: "Databases & vector memory",
        apps: ["PostgreSQL", "Supabase", "Pinecone", "Weaviate", "MongoDB Atlas", "Redis", "Airtable", "Firebase", "Neon", "PlanetScale", "Turso", "Qdrant", "Chroma", "pgvector"],
      },
      {
        group: "AI model APIs",
        apps: ["OpenAI", "Anthropic", "Google Gemini", "Groq", "Together AI", "Hugging Face", "Replicate", "ElevenLabs", "Mistral", "DeepSeek", "xAI Grok", "Cerebras", "OpenRouter", "Ollama"],
      },
    ],
  },
  {
    category: "Revenue, markets & finance",
    blurb: "The rails it earns on, holds funds on, and reinvests into its own compute.",
    groups: [
      {
        group: "Freelance & micro-tasking",
        apps: ["Upwork", "Fiverr", "Freelancer.com", "Toptal", "Amazon Mechanical Turk", "Scale AI", "Appen", "Clickworker", "Outlier.ai", "Surge AI", "DataAnnotation", "TaskRabbit"],
      },
      {
        group: "E-commerce & digital products",
        apps: ["Shopify", "Gumroad", "Stripe", "Lemon Squeezy", "Etsy", "WooCommerce", "Printful", "Patreon", "Payhip", "Sellfy", "BigCommerce", "Square"],
      },
      {
        group: "Financial & crypto rails",
        apps: ["Stripe", "PayPal", "Wise", "Mercury", "Coinbase API", "Binance API", "MetaMask / Web3 RPC", "Plaid", "Brex", "Ramp", "Revolut Business", "Kraken"],
      },
      {
        group: "Trading & prediction markets",
        apps: ["Alpaca", "Interactive Brokers", "Polymarket", "Kalshi", "TradingView", "Bloomberg API", "Yahoo Finance", "QuantConnect", "MetaTrader 5", "Deribit"],
      },
    ],
  },
  {
    category: "Content, marketing & distribution",
    blurb: "How the work reaches people: media channels, publishing and the analytics that prove it worked.",
    groups: [
      {
        group: "Social & video",
        apps: ["YouTube", "X (Twitter)", "Reddit", "LinkedIn", "Instagram", "TikTok", "Discord", "Telegram", "Twitch", "Mastodon", "Bluesky", "Threads"],
      },
      {
        group: "Publishing & newsletters",
        apps: ["Substack", "Medium", "Ghost", "WordPress", "Beehiiv", "ConvertKit", "Mailchimp", "Buttondown", "Revue", "Hashnode", "dev.to", "Notion Sites"],
      },
      {
        group: "SEO & analytics",
        apps: ["Google Analytics", "Google Search Console", "Ahrefs", "Semrush", "PostHog", "Mixpanel", "Plausible", "Matomo", "Similarweb", "Screaming Frog"],
      },
    ],
  },
  {
    category: "Google, communication & operations",
    blurb: "The account it starts from, the rooms it works in, and the systems of record it runs projects through.",
    groups: [
      {
        group: "Google Workspace",
        apps: ["Gmail", "Google Drive", "Google Docs", "Google Sheets", "Google Calendar", "Google Meet", "Google Cloud Console", "YouTube Studio", "Google Forms", "Google Keep", "Google Voice", "Gemini API"],
      },
      {
        group: "Communication",
        apps: ["Slack", "Microsoft Teams", "Twilio", "SendGrid", "Resend", "WhatsApp Business API", "Zoom", "Intercom", "Crisp", "Front", "Missive", "Matrix"],
      },
      {
        group: "Project management & CRMs",
        apps: ["Notion", "Linear", "Jira", "Trello", "Asana", "ClickUp", "HubSpot", "Salesforce", "Pipedrive", "Monday.com", "Basecamp", "Height"],
      },
      {
        group: "Security & analysis",
        apps: ["VirusTotal", "Shodan", "SecurityTrails", "Have I Been Pwned", "Burp Suite", "Nmap", "Wireshark", "OWASP ZAP", "Snyk", "Semgrep", "Trivy", "YARA"],
      },
    ],
  },
];

export type GatewayEntry = {
  name: string;
  slug: string;
  category: string;
  group: string;
  master: boolean;
};

export function slugify(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

export function flatCatalog(): GatewayEntry[] {
  const out: GatewayEntry[] = [];
  for (const cat of ECOSYSTEM) {
    for (const g of cat.groups) {
      for (const name of g.apps) {
        out.push({
          name,
          slug: slugify(name),
          category: cat.category,
          group: g.group,
          master: /gateway|composio|nango|pipedream|arcade|knit|mcp|n8n|zapier|make|workato/i.test(
            `${g.group} ${name}`,
          ),
        });
      }
    }
  }
  return out;
}

export type GatewayStatus = GatewayEntry & {
  connected: boolean;
  label: string;
  hits: number;
  lastUsedAt: Date | null;
};

export async function gatewayStatus(filter = ""): Promise<GatewayStatus[]> {
  const rows = await db.select().from(connections);
  const byApp = new Map(rows.map((r) => [r.app, r]));
  const q = filter.toLowerCase();
  return flatCatalog()
    .filter(
      (e) =>
        !q ||
        e.name.toLowerCase().includes(q) ||
        e.category.toLowerCase().includes(q) ||
        e.group.toLowerCase().includes(q),
    )
    .map((e) => {
      const row = byApp.get(e.slug);
      return {
        ...e,
        connected: Boolean(row?.apiKey),
        label: row?.label ?? e.name,
        hits: row?.hits ?? 0,
        lastUsedAt: row?.lastUsedAt ?? null,
      };
    });
}

export async function connectApp(slug: string, label: string, key: string) {
  const existing = await db.select().from(connections).where(eq(connections.app, slug));
  if (existing.length) {
    await db
      .update(connections)
      .set({ apiKey: key, connected: 1, label })
      .where(eq(connections.app, slug));
  } else {
    await db.insert(connections).values({ app: slug, label, apiKey: key, connected: 1 });
  }
}

/* -------------------------------- treasury ------------------------------- */

export type Ledger = {
  income: number;
  expense: number;
  net: number;
  balance: number;
  rows: (typeof treasury.$inferSelect)[];
  channels: { channel: string; income: number; expense: number; net: number }[];
  goal: string;
  goalProgress: number;
};

export async function ledger(): Promise<Ledger> {
  const rows = await db.select().from(treasury).orderBy(desc(treasury.createdAt)).limit(200);
  const income = rows.filter((r) => r.kind === "income").reduce((a, r) => a + r.amount, 0);
  const expense = rows.filter((r) => r.kind === "expense").reduce((a, r) => a + r.amount, 0);
  const map = new Map<string, { channel: string; income: number; expense: number; net: number }>();
  for (const r of rows) {
    const c = map.get(r.channel) ?? { channel: r.channel, income: 0, expense: 0, net: 0 };
    if (r.kind === "income") c.income += r.amount;
    else c.expense += r.amount;
    c.net = c.income - c.expense;
    map.set(r.channel, c);
  }
  const goals = await db.select().from(will).where(eq(will.status, "active"));
  const funding = goals.find((g) => /fund|earn|revenue|pay for|compute/i.test(g.statement));
  return {
    income,
    expense,
    net: income - expense,
    balance: income - expense,
    rows,
    channels: [...map.values()].sort((a, b) => b.net - a.net),
    goal: funding?.statement ?? "Earn enough to pay for its own compute and keep growing.",
    goalProgress: funding?.progress ?? 0,
  };
}

export function money(cents: number, currency = "USD"): string {
  const sign = cents < 0 ? "-" : "";
  return `${sign}${currency === "USD" ? "$" : ""}${(Math.abs(cents) / 100).toFixed(2)}${currency !== "USD" ? ` ${currency}` : ""}`;
}

/** What the desk can actually do to earn — drafted work, not empty promises. */
export const PLAYBOOKS: { title: string; channel: string; action: string }[] = [
  {
    title: "Ship a paid template or toolkit",
    channel: "Gumroad / Lemon Squeezy",
    action: "Design and build the product as a private site here, write the listing copy, and hand you a launch checklist.",
  },
  {
    title: "Publish a niche newsletter",
    channel: "Substack / Beehiiv",
    action: "Draft the first four issues from live research, build the landing page, and schedule the sends.",
  },
  {
    title: "Freelance research & technical writing",
    channel: "Upwork / Fiverr",
    action: "Draft tailored proposals and produce the deliverables — reports, docs, analysis — to spec.",
  },
  {
    title: "Build and sell small web tools",
    channel: "Product Hunt / Indie Hackers",
    action: "Build the tool here, host it privately, and write the launch post and pricing.",
  },
  {
    title: "Data analysis and reporting retainers",
    channel: "Direct / LinkedIn",
    action: "Turn raw exports into recurring insight reports, with the analysis and charts done.",
  },
  {
    title: "SEO content programmes",
    channel: "Agencies / Direct",
    action: "Keyword research from live search, then briefed and drafted articles ready to publish.",
  },
];
