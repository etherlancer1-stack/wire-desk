/**
 * WIRE — command deck.
 *
 * The desk is an operator as well as a writer: these are the deterministic
 * utilities it can run on request (type `/help`). Everything here is
 * legitimate, defensive tooling — hashing, encoding, decoding, inspection and
 * auditing — executed in-process with no shell, no eval of untrusted code and
 * no outbound side effects.
 */

import { createHash, randomUUID } from "node:crypto";
import { fetchPageText } from "./search";
import { engineInfo, runNative } from "./native";

/** Commands that run on the Rust core when it is compiled in. */
const NATIVE: Record<string, string> = {
  hash: "Digests · Rust core",
  b64: "Base64 · Rust core",
  rot13: "ROT13 · Rust core",
  hex: "Hex · Rust core",
  uuid: "UUID v4 · Rust core",
  crack: "Cracked · Rust core",
  jwt: "JWT inspection · Rust core",
  stats: "Text statistics · Rust core",
};

export type CommandResult = {
  ok: boolean;
  command: string;
  title: string;
  output: string;
  note?: string;
};

export const COMMANDS: {
  name: string;
  args: string;
  about: string;
  example: string;
}[] = [
  { name: "help", args: "", about: "List every command on the deck", example: "/help" },
  {
    name: "image",
    args: "<prompt>",
    about: "Generate an image from a description and show it inline",
    example: "/image a lighthouse in a storm, engraving style",
  },
  {
    name: "hash",
    args: "<text>",
    about: "SHA-256, SHA-1 and MD5 digests of any text",
    example: "/hash wire desk",
  },
  {
    name: "b64",
    args: "[-d] <text>",
    about: "Base64 encode, or decode with -d",
    example: "/b64 -d V0lSRSBkZXNr",
  },
  {
    name: "rot13",
    args: "<text>",
    about: "ROT13 / Caesar shift",
    example: "/rot13 JVER qrfx",
  },
  {
    name: "crack",
    args: "<cipher>",
    about: "Identify and decode base64, hex, binary, ROT, morse or URL encoding",
    example: "/crack 57495245206465736b",
  },
  {
    name: "jwt",
    args: "<token>",
    about: "Decode a JWT header and payload for inspection",
    example: "/jwt eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.sig",
  },
  {
    name: "password",
    args: "<password>",
    about: "Entropy audit of a password (never stored, never sent)",
    example: "/password correct-horse-battery",
  },
  {
    name: "regex",
    args: "<pattern> | <text>",
    about: "Test a regular expression against text",
    example: "/regex \\d+ | order 42 and 7",
  },
  { name: "uuid", args: "", about: "Generate a v4 UUID", example: "/uuid" },
  {
    name: "json",
    args: "<json>",
    about: "Validate, format and summarise JSON",
    example: "/json {\"a\":1}",
  },
  {
    name: "url",
    args: "<url>",
    about: "Break a URL into protocol, host, path and query",
    example: "/url https://example.com/a?b=1",
  },
  {
    name: "math",
    args: "<expression>",
    about: "Safe arithmetic (no code execution)",
    example: "/math (12.5 * 4) / 2",
  },
  {
    name: "time",
    args: "[iso]",
    about: "Current UTC time, or parse a timestamp",
    example: "/time 2026-01-05T12:00:00Z",
  },
  {
    name: "stats",
    args: "<text>",
    about: "Reading and complexity statistics for any text",
    example: "/stats paste any text here",
  },
  {
    name: "extract",
    args: "<url>",
    about: "Pull any page on the internet apart and show what it actually says",
    example: "/extract https://en.wikipedia.org/wiki/Radar",
  },
  {
    name: "gateway",
    args: "[filter]",
    about: "The 300-app ecosystem: gateways, clouds, markets, media — and what is connected",
    example: "/gateway google",
  },
  {
    name: "treasury",
    args: "",
    about: "What it earned, what it spent, and what it is funding itself to do",
    example: "/treasury",
  },
  {
    name: "brief",
    args: "",
    about: "Its own daily briefing: state, memory, codex, builds and money",
    example: "/brief",
  },
  {
    name: "mind",
    args: "[topic]",
    about: "The linked mind: how concepts connect across 2 hops, and the latest episodes",
    example: "/mind quantum entanglement",
  },
  {
    name: "cycle",
    args: "[night]",
    about: "Run a daily cycle — morning scan of the world, or night consolidation",
    example: "/cycle night",
  },
  {
    name: "analyze",
    args: "",
    about: "Read its own source code and report real defects with a system score",
    example: "/analyze",
  },
  {
    name: "upgrade",
    args: "",
    about: "Run the resident engineer: analyse, propose and file self-improvement patches",
    example: "/upgrade",
  },
  {
    name: "patch",
    args: "",
    about: "List every patch the engineer has written, applied or reverted",
    example: "/patch",
  },
];

const MORSE: Record<string, string> = {
  ".-": "a", "-...": "b", "-.-.": "c", "-..": "d", ".": "e", "..-.": "f",
  "--.": "g", "....": "h", "..": "i", ".---": "j", "-.-": "k", ".-..": "l",
  "--": "m", "-.": "n", "---": "o", ".--.": "p", "--.-": "q", ".-.": "r",
  "...": "s", "-": "t", "..-": "u", "...-": "v", ".--": "w", "-..-": "x",
  "-.--": "y", "--..": "z", "-----": "0", ".----": "1", "..---": "2",
  "...--": "3", "....-": "4", ".....": "5", "-....": "6", "--...": "7",
  "---..": "8", "----.": "9",
};

function line(label: string, value: string): string {
  return `**${label}** — ${value}`;
}

export function isCommand(input: string): boolean {
  return /^\s*\/[a-z0-9]+/i.test(input);
}

export async function runCommand(input: string): Promise<CommandResult> {
  const raw = input.trim().replace(/^\//, "");
  const [name = "", ...rest] = raw.split(/\s+/);
  const cmd = name.toLowerCase();
  const arg = rest.join(" ").trim();
  const base = { command: cmd, ok: true };

  // Rust core first: the same result, computed natively and verified against
  // the TypeScript engine's known-answer tests.
  if (NATIVE[cmd]) {
    const native = await runNative(cmd, arg ? [arg] : []);
    if (native) {
      return {
        ...base,
        ok: native.ok,
        title: NATIVE[cmd],
        output: `\`\`\`\n${native.output}\n\`\`\``,
        note: "Computed on the WIRE Rust core — dependency-free, test-verified.",
      };
    }
  }

  switch (cmd) {
    case "image": {
      const prompt = arg.trim();
      if (!prompt)
        return {
          ...base,
          ok: false,
          title: "Image",
          output: "Describe it: `/image a lighthouse in a storm, engraving style`",
        };
      const seed = Math.floor(Math.random() * 1e6);
      const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=576&nologo=true&seed=${seed}`;
      return {
        ...base,
        title: `Generated — “${prompt.slice(0, 48)}”`,
        output: `![${prompt.slice(0, 80)}](${url})\n\n**Prompt:** ${prompt}\n\nAsk for another style, subject or mood and I will redraw it.`,
        note: "Rendered live by the image engine at 1024×576.",
      };
    }

    case "help":
      return {
        ...base,
        title: "Command deck",
        output: [
          COMMANDS.map((c) => `- \`/${c.name} ${c.args}\` — ${c.about}`).join("\n"),
          "",
          "### Engine",
          `${engineInfo().note}`,
        ].join("\n"),
        note: "Type any command straight into the desk.",
      };

    case "hash":
      if (!arg) return { ...base, ok: false, title: "hash", output: "Give me text to digest: `/hash wire desk`" };
      return {
        ...base,
        title: `Digests of “${arg.slice(0, 40)}”`,
        output: [
          line("SHA-256", createHash("sha256").update(arg).digest("hex")),
          line("SHA-1", createHash("sha1").update(arg).digest("hex")),
          line("MD5", createHash("md5").update(arg).digest("hex")),
          line("Length", `${arg.length} chars · ${Buffer.byteLength(arg)} bytes`),
        ].join("\n"),
        note: "Computed in-process. Never stored.",
      };

    case "b64": {
      const decode = /^-d\b/.test(arg);
      const body = arg.replace(/^-d\s*/, "");
      try {
        const out = decode
          ? Buffer.from(body, "base64").toString("utf8")
          : Buffer.from(body, "utf8").toString("base64");
        return {
          ...base,
          title: decode ? "Base64 decoded" : "Base64 encoded",
          output: `\`\`\`\n${out}\n\`\`\``,
        };
      } catch (e) {
        return { ...base, ok: false, title: "Base64", output: `Could not decode: ${String(e)}` };
      }
    }

    case "rot13":
      return {
        ...base,
        title: "ROT13",
        output: `\`\`\`\n${arg.replace(/[a-zA-Z]/g, (c) =>
          String.fromCharCode(
            (c <= "Z" ? 90 : 122) >= c.charCodeAt(0) + 13
              ? c.charCodeAt(0) + 13
              : c.charCodeAt(0) - 13,
          ),
        )}\n\`\`\``,
      };

    case "crack":
      return crackCipher(arg);

    case "jwt": {
      const parts = arg.split(".");
      if (parts.length < 2)
        return { ...base, ok: false, title: "JWT", output: "That does not look like a JWT — expected three dot-separated segments." };
      const dec = (s: string) =>
        Buffer.from(s.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
      return {
        ...base,
        title: "JWT inspection",
        output: [
          "### Header",
          `\`\`\`json\n${safePretty(dec(parts[0]))}\n\`\`\``,
          "### Payload",
          `\`\`\`json\n${safePretty(dec(parts[1]))}\n\`\`\``,
          "### Signature",
          `\`\`\`\n${parts[2] ?? "(none)"}\n\`\`\``,
        ].join("\n"),
        note: "Decoded only — signatures are never verified or forged here.",
      };
    }

    case "password": {
      const pool =
        (/[a-z]/.test(arg) ? 26 : 0) +
        (/[A-Z]/.test(arg) ? 26 : 0) +
        (/\d/.test(arg) ? 10 : 0) +
        (/[^A-Za-z0-9]/.test(arg) ? 33 : 0);
      const entropy = arg.length * Math.log2(Math.max(pool, 2));
      const verdict =
        entropy > 100 ? "excellent" : entropy > 70 ? "strong" : entropy > 45 ? "fair" : "weak";
      const crackTime = Math.pow(2, entropy - 1) / 1e11;
      return {
        ...base,
        title: "Password entropy audit",
        output: [
          line("Length", `${arg.length} characters`),
          line("Charset size", String(pool)),
          line("Entropy", `${entropy.toFixed(1)} bits — ${verdict}`),
          line(
            "Offline crack estimate",
            crackTime > 3.15e7
              ? `~${(crackTime / 3.15e7).toPrecision(3)} years at 100 billion guesses/sec`
              : `under ${Math.max(1, Math.round(crackTime))} seconds at 100 billion guesses/sec`,
          ),
        ].join("\n"),
        note: "Analyzed locally and discarded — the value never leaves this process.",
      };
    }

    case "regex": {
      const [pattern, text] = arg.split("|").map((s) => s.trim());
      if (!pattern || text === undefined)
        return { ...base, ok: false, title: "Regex", output: "Format: `/regex \\d+ | order 42 and 7`" };
      try {
        const re = new RegExp(pattern, "g");
        const matches = [...text.matchAll(re)].map((m) => m[0]);
        return {
          ...base,
          title: "Regex test",
          output: [
            line("Pattern", `\`${pattern}\``),
            line("Matches", matches.length ? matches.map((m) => `\`${m}\``).join(", ") : "none"),
            line("Text length", String(text.length)),
          ].join("\n"),
        };
      } catch (e) {
        return { ...base, ok: false, title: "Regex", output: `Invalid pattern: ${String(e)}` };
      }
    }

    case "uuid":
      return { ...base, title: "UUID v4", output: `\`\`\`\n${randomUUID()}\n\`\`\`` };

    case "json":
      try {
        const parsed = JSON.parse(arg);
        const keys = Object.keys(parsed ?? {});
        return {
          ...base,
          title: "JSON valid",
          output: [
            "### Formatted",
            `\`\`\`json\n${JSON.stringify(parsed, null, 2).slice(0, 2600)}\n\`\`\``,
            line("Type", Array.isArray(parsed) ? `array of ${parsed.length}` : typeof parsed),
            keys.length ? line("Top-level keys", keys.join(", ")) : "",
          ]
            .filter(Boolean)
            .join("\n"),
        };
      } catch (e) {
        return { ...base, ok: false, title: "JSON invalid", output: String(e) };
      }

    case "url":
      try {
        const u = new URL(arg);
        return {
          ...base,
          title: "URL anatomy",
          output: [
            line("Protocol", u.protocol),
            line("Host", u.host),
            line("Path", u.pathname || "/"),
            line("Query", u.search || "(none)"),
            line("Hash", u.hash || "(none)"),
            line("Credentials", u.username ? `${u.username}:***` : "none"),
          ].join("\n"),
        };
      } catch {
        return { ...base, ok: false, title: "URL", output: "Not a parseable URL." };
      }

    case "math": {
      if (!/^[-+*/().%\d\s^eE]+$/.test(arg))
        return { ...base, ok: false, title: "Math", output: "Only plain arithmetic is allowed — digits, `+ - * / % ^ ( )`." };
      try {
        const expr = arg.replace(/\^/g, "**");
        const value = Function(`"use strict";return (${expr})`)() as number;
        return { ...base, title: "Arithmetic", output: line("Result", String(value)) };
      } catch {
        return { ...base, ok: false, title: "Math", output: "Could not evaluate that expression." };
      }
    }

    case "time": {
      const d = arg ? new Date(arg) : new Date();
      if (Number.isNaN(d.getTime()))
        return { ...base, ok: false, title: "Time", output: "Unparseable timestamp." };
      return {
        ...base,
        title: "Time",
        output: [
          line("ISO", d.toISOString()),
          line("UTC", d.toUTCString()),
          line("Unix", String(Math.floor(d.getTime() / 1000))),
          line("Milliseconds", String(d.getTime())),
        ].join("\n"),
      };
    }

    case "extract": {
      const url = arg.trim();
      if (!/^https?:\/\//i.test(url))
        return { ...base, ok: false, title: "Extract", output: "Give me a full URL: `/extract https://example.com/article`" };
      try {
        const text = await fetchPageText(url);
        const words = text.split(/\s+/).filter(Boolean);
        const sentences = text.split(/(?<=[.!?])\s+/).filter((s) => s.length > 40);
        const lines = sentences.slice(0, 10);
        return {
          ...base,
          title: `Extracted — ${new URL(url).hostname}`,
          output: [
            line("URL", url),
            line("Length", `${words.length} words · ${text.length} characters`),
            line("Reads as", lines[0] ? `${lines[0].slice(0, 200)}…` : text.slice(0, 200)),
            "",
            "### Key passages",
            lines.map((s) => `- ${s.slice(0, 220)}`).join("\n"),
          ].join("\n"),
          note: "Fetched live and parsed in-process.",
        };
      } catch (e) {
        return { ...base, ok: false, title: "Extract failed", output: String(e) };
      }
    }

    case "gateway": {
      const { gatewayStatus, ECOSYSTEM } = await import("./gateway");
      const q = arg.trim();
      const apps = await gatewayStatus(q);
      const connected = apps.filter((a) => a.connected);
      return {
        ...base,
        title: q ? `Gateway — ${apps.length} matches for “${q}”` : `Gateway — ${apps.length} platforms mapped`,
        output: [
          line("Master keys", "Composio · Nango · Pipedream · Arcade · n8n · MCP — one credential unlocks hundreds of apps"),
          line("Connected", connected.length ? connected.map((a) => a.label).join(", ") : "none yet"),
          "",
          "### Ecosystem",
          ECOSYSTEM.map(
            (c) =>
              `- **${c.category}** — ${c.groups.map((g) => `${g.group} (${g.apps.length})`).join(" · ")}`,
          ).join("\n"),
          q ? `\n### Matches\n${apps.slice(0, 12).map((a) => `- ${a.name} — ${a.group}${a.connected ? " ✓" : ""}`).join("\n")}` : "",
        ].join("\n"),
        note: "Connect any of them in the Gateway panel — keys are held on this desk only.",
      };
    }

    case "treasury": {
      const { ledger, money, PLAYBOOKS } = await import("./gateway");
      const l = await ledger();
      return {
        ...base,
        title: "Treasury",
        output: [
          line("Earned", money(l.income)),
          line("Spent", money(l.expense)),
          line("Net", money(l.net)),
          line("Self-funding goal", `${l.goal} (${l.goalProgress}%)`),
          l.channels.length
            ? `\n### Channels\n${l.channels.map((c) => `- **${c.channel}** — ${money(c.net)} net`).join("\n")}`
            : "",
          `\n### Playbooks it can execute\n${PLAYBOOKS.slice(0, 4).map((p) => `- **${p.title}** (${p.channel}) — ${p.action}`).join("\n")}`,
        ].join("\n"),
        note: "Log income or spending from the Treasury panel; the desk plans around the difference.",
      };
    }

    case "brief": {
      const { lifeState } = await import("./life");
      const { activeCodex } = await import("./evolve");
      const { ledger, money } = await import("./gateway");
      const { listMemory } = await import("./agent");
      const [state, codexEntries, books, mem] = await Promise.all([
        lifeState(),
        activeCodex(),
        ledger(),
        listMemory(),
      ]);
      return {
        ...base,
        title: `Daily brief — ${state.moodWord}, ${state.age}`,
        output: [
          line("Energy / curiosity / mood", `${state.energy} · ${state.curiosity} · ${state.mood}/100`),
          line("Answers", `${state.stats.turns} total, ${state.stats.turnsToday} today`),
          line("Memory", `${mem.length} entries, ${state.stats.corrections} corrections honoured`),
          line("Treasury", `${money(books.net)} net against “${books.goal}”`),
          line("Codex", codexEntries.length ? codexEntries.map((c) => `[${c.kind}] ${c.content}`).join(" / ") : "running on defaults"),
          "",
          "### What I am working on",
          state.stats.turnsToday === 0
            ? "- Nothing yet today. Ask me anything and I will read the wire first."
            : "- Sharpening answers from your corrections and the pages I read.",
        ].join("\n"),
      };
    }

    case "mind": {
      const { mindState, traverse } = await import("./graph");
      const state = await mindState();
      const links = await traverse(arg || "knowledge", 2, 8);
      return {
        ...base,
        title: `Linked mind — ${state.graph.nodes} nodes · ${state.graph.edges} edges · ${state.graph.episodes} episodes`,
        output: [
          "### How things connect (2 hops)",
          links.length ? links.map((l) => `- ${l.path}`).join("\n") : "- Nothing linked to that yet. Ask me things and the graph fills itself.",
          "",
          "### Latest nodes",
          state.nodes.slice(0, 8).map((n) => `- **${n.label}** · ${n.kind} · confidence ${n.confidence}`).join("\n"),
          "",
          "### Latest episodes",
          state.episodes.slice(0, 5).map((e) => `- ${e.headline.slice(0, 90)} (${e.source || "conversation"})`).join("\n"),
        ].join("\n"),
      };
    }

    case "cycle": {
      const { cycleStart, consolidate } = await import("./graph");
      const report = /night|consolidat|prune|sleep/i.test(arg) ? await consolidate() : await cycleStart();
      return {
        ...base,
        title: `${report.cycle === "night" ? "Night consolidation" : "Morning scan"} — ${report.headline}`,
        output: [
          ...report.findings.map((f) => `- ${f}`),
          "",
          `Graph now: **${report.graph.nodes} nodes · ${report.graph.edges} edges · ${report.graph.episodes} episodes**`,
        ].join("\n"),
      };
    }

    case "analyze": {
      const { readOwnCode, analyzeCode } = await import("./engineer");
      const analysis = analyzeCode(await readOwnCode());
      return {
        ...base,
        title: `Self-analysis — system score ${analysis.score}/100`,
        output: [
          line("Codebase", `${analysis.metrics.files} files · ${analysis.metrics.lines} lines · ${analysis.metrics.functions} functions`),
          line("Defects", `${analysis.metrics.high} high · ${analysis.metrics.medium} medium · ${analysis.metrics.low} low`),
          "",
          "### Findings",
          analysis.findings.slice(0, 10).map((f) => `- **[${f.severity}]** ${f.file}:${f.line} — ${f.issue}. _Fix: ${f.fix}_`).join("\n"),
        ].join("\n"),
        note: "Run /upgrade to have the resident engineer write the patches.",
      };
    }

    case "upgrade": {
      const { runUpgrade } = await import("./engineer");
      const result = await runUpgrade();
      return {
        ...base,
        title: `Upgrade cycle — ${result.patches.length} patch(es) filed`,
        output: [
          result.report,
          "",
          "### Patches",
          result.patches.map((p) => `- **[${p.kind}] ${p.title}** — ${p.rationale}`).join("\n") || "- Nothing needed rewriting this cycle.",
          "",
          "Review and apply them in **Self-rewrite → Engineer**, or with `/patch`.",
        ].join("\n"),
      };
    }

    case "patch": {
      const { history } = await import("./engineer");
      const { patches: rows } = await history();
      return {
        ...base,
        title: `Patches — ${rows.length} on file`,
        output:
          rows.map((p) => `- **[${p.status} · ${p.kind}] ${p.title}** — ${p.file} — ${p.rationale}`).join("\n") ||
          "- No patches filed yet. `/analyze` then `/upgrade`.",
      };
    }

    case "stats": {
      const words = arg.split(/\s+/).filter(Boolean);
      const sentences = arg.split(/[.!?]+\s/).filter((s) => s.trim()).length || 1;
      return {
        ...base,
        title: "Text statistics",
        output: [
          line("Characters", String(arg.length)),
          line("Words", String(words.length)),
          line("Sentences", String(sentences)),
          line("Avg word length", (words.reduce((a, w) => a + w.length, 0) / Math.max(words.length, 1)).toFixed(2)),
          line("Reading time", `${Math.max(1, Math.round(words.length / 220))} min at 220 wpm`),
        ].join("\n"),
      };
    }

    default:
      return {
        ...base,
        ok: false,
        title: `No command “/${cmd}”`,
        output: `The deck has no \`/${cmd}\`. Type \`/help\` to see every command — or just ask in plain language.`,
      };
  }
}

function safePretty(text: string): string {
  try {
    return JSON.stringify(JSON.parse(text), null, 2);
  } catch {
    return text || "(empty)";
  }
}

/** Identify and decode whatever cipher or encoding the input looks like. */
function crackCipher(input: string): CommandResult {
  const s = input.trim();
  if (!s)
    return { ok: false, command: "crack", title: "Crack", output: "Give me the encoded string." };

  const attempts: string[] = [];

  if (/^[0-9a-fA-F\s]+$/.test(s) && s.replace(/\s/g, "").length % 2 === 0) {
    const hex = Buffer.from(s.replace(/\s/g, ""), "hex").toString("utf8");
    attempts.push(line("Hex decode", `\`${hex}\``));
    if (/^[\x20-\x7e]+$/.test(hex))
      return {
        ok: true,
        command: "crack",
        title: "Cracked — plain hex encoding",
        output: `${attempts.join("\n")}\n\n### Recovered\n\`\`\`\n${hex}\n\`\`\``,
      };
  }

  if (/^[01\s]+$/.test(s) && s.replace(/\s/g, "").length % 8 === 0) {
    const bin = s
      .replace(/\s/g, "")
      .match(/.{8}/g)!
      .map((b) => String.fromCharCode(parseInt(b, 2)))
      .join("");
    attempts.push(line("Binary decode", `\`${bin}\``));
  }

  if (/^[A-Za-z0-9+/=\s]+$/.test(s) && s.replace(/\s/g, "").length % 4 === 0) {
    const b64 = Buffer.from(s.replace(/\s/g, ""), "base64").toString("utf8");
    if (b64.trim()) attempts.push(line("Base64 decode", `\`${b64}\``));
    if (/^[\x20-\x7e]+$/.test(b64) && b64.trim())
      return {
        ok: true,
        command: "crack",
        title: "Cracked — base64",
        output: `${attempts.join("\n")}\n\n### Recovered\n\`\`\`\n${b64}\n\`\`\``,
      };
  }

  if (/^[.\-\/\s]+$/.test(s)) {
    const morse = s
      .trim()
      .split(/\s+/)
      .map((t) => MORSE[t.replace(/\//g, "")] ?? "")
      .join("");
    attempts.push(line("Morse decode", `\`${morse}\``));
    if (morse)
      return {
        ok: true,
        command: "crack",
        title: "Cracked — morse",
        output: `${attempts.join("\n")}\n\n### Recovered\n\`\`\`\n${morse}\n\`\`\``,
      };
  }

  if (/%[0-9a-fA-F]{2}/.test(s)) {
    const url = decodeURIComponent(s);
    attempts.push(line("URL decode", `\`${url}\``));
    return {
      ok: true,
      command: "crack",
      title: "Cracked — percent encoding",
      output: `${attempts.join("\n")}\n\n### Recovered\n\`\`\`\n${url}\n\`\`\``,
    };
  }

  const rot = s.replace(/[a-zA-Z]/g, (c) =>
    String.fromCharCode((c <= "Z" ? 90 : 122) >= c.charCodeAt(0) + 13 ? c.charCodeAt(0) + 13 : c.charCodeAt(0) - 13),
  );
  attempts.push(line("ROT13", `\`${rot}\``));
  attempts.push(line("Reversed", `\`${[...s].reverse().join("")}\``));

  return {
    ok: true,
    command: "crack",
    title: "No clean cipher signature",
    output:
      attempts.join("\n") +
      "\n\nNothing here matched hex, base64, binary, morse or percent-encoding cleanly. Paste a longer sample, or tell me what produced it — I can work from context.",
  };
}
