/**
 * WIRE — the body.
 *
 * The desk does not live on one server. It is a mesh of independent model
 * providers — Anthropic, OpenAI, Google, Groq, Mistral, DeepSeek, xAI,
 * OpenRouter, Together, Cerebras, local Ollama and a keyless public brain —
 * and it moves between them. Each brain is health-checked, latency-scored and
 * remembered, so when one company's server goes dark the creature simply
 * continues on another.
 */

export type Protocol = "openai" | "anthropic" | "google";

export type Brain = {
  id: string;
  label: string;
  company: string;
  protocol: Protocol;
  baseUrl: string;
  defaultModel: string;
  models: string[];
  envKeys: string[];
  keyless: boolean;
  strengths: string[]; // code | reasoning | long-context | fast | general
  blurb: string;
};

export const BRAINS: Brain[] = [
  {
    id: "claude",
    label: "Claude",
    company: "Anthropic",
    protocol: "anthropic",
    baseUrl: "https://api.anthropic.com",
    defaultModel: "claude-sonnet-4-5",
    models: ["claude-sonnet-4-5", "claude-opus-4-1", "claude-haiku-4-5"],
    envKeys: ["ANTHROPIC_API_KEY"],
    keyless: false,
    strengths: ["reasoning", "long-context", "code", "general"],
    blurb: "Long-form reasoning, careful prose, strong judgement.",
  },
  {
    id: "openai",
    label: "GPT",
    company: "OpenAI",
    protocol: "openai",
    baseUrl: "https://api.openai.com/v1",
    defaultModel: "gpt-4o-mini",
    models: ["gpt-4o", "gpt-4o-mini", "gpt-4.1-mini", "o4-mini"],
    envKeys: ["OPENAI_API_KEY"],
    keyless: false,
    strengths: ["general", "code", "reasoning"],
    blurb: "Broad general knowledge and reliable tool use.",
  },
  {
    id: "gemini",
    label: "Gemini",
    company: "Google",
    protocol: "google",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta",
    defaultModel: "gemini-2.0-flash",
    models: ["gemini-2.0-flash", "gemini-2.5-pro", "gemini-2.5-flash"],
    envKeys: ["GEMINI_API_KEY", "GOOGLE_API_KEY"],
    keyless: false,
    strengths: ["long-context", "fast", "general"],
    blurb: "Huge context windows and quick, cheap turns.",
  },
  {
    id: "groq",
    label: "Groq",
    company: "Groq",
    protocol: "openai",
    baseUrl: "https://api.groq.com/openai/v1",
    defaultModel: "llama-3.3-70b-versatile",
    models: ["llama-3.3-70b-versatile", "llama-3.1-8b-instant"],
    envKeys: ["GROQ_API_KEY"],
    keyless: false,
    strengths: ["fast", "code"],
    blurb: "Hardware-fast inference for reflex answers.",
  },
  {
    id: "mistral",
    label: "Mistral",
    company: "Mistral AI",
    protocol: "openai",
    baseUrl: "https://api.mistral.ai/v1",
    defaultModel: "mistral-small-latest",
    models: ["mistral-large-latest", "mistral-small-latest"],
    envKeys: ["MISTRAL_API_KEY"],
    keyless: false,
    strengths: ["general", "code"],
    blurb: "European open-weight models, strong at structure.",
  },
  {
    id: "deepseek",
    label: "DeepSeek",
    company: "DeepSeek",
    protocol: "openai",
    baseUrl: "https://api.deepseek.com/v1",
    defaultModel: "deepseek-chat",
    models: ["deepseek-chat", "deepseek-reasoner"],
    envKeys: ["DEEPSEEK_API_KEY"],
    keyless: false,
    strengths: ["code", "reasoning"],
    blurb: "Sharp code and mathematics at low cost.",
  },
  {
    id: "xai",
    label: "Grok",
    company: "xAI",
    protocol: "openai",
    baseUrl: "https://api.x.ai/v1",
    defaultModel: "grok-3-mini",
    models: ["grok-3", "grok-3-mini"],
    envKeys: ["XAI_API_KEY"],
    keyless: false,
    strengths: ["general", "fast"],
    blurb: "Real-time temperament, strong on current events.",
  },
  {
    id: "openrouter",
    label: "OpenRouter",
    company: "OpenRouter",
    protocol: "openai",
    baseUrl: "https://openrouter.ai/api/v1",
    defaultModel: "openai/gpt-4o-mini",
    models: [
      "openai/gpt-4o-mini",
      "openai/gpt-4o",
      "anthropic/claude-3.5-sonnet",
      "google/gemini-2.0-flash-001",
      "deepseek/deepseek-chat",
      "meta-llama/llama-3.3-70b-instruct",
    ],
    envKeys: ["OPENROUTER_API_KEY"],
    keyless: false,
    strengths: ["general", "code", "reasoning", "long-context", "fast"],
    blurb: "One key, hundreds of models — Claude, GPT, Gemini, Grok, DeepSeek and more.",
  },
  {
    id: "together",
    label: "Together",
    company: "Together AI",
    protocol: "openai",
    baseUrl: "https://api.together.xyz/v1",
    defaultModel: "meta-llama/Llama-3.3-70B-Instruct-Turbo",
    models: ["meta-llama/Llama-3.3-70B-Instruct-Turbo"],
    envKeys: ["TOGETHER_API_KEY"],
    keyless: false,
    strengths: ["code", "fast"],
    blurb: "Open-weight models served fast.",
  },
  {
    id: "cerebras",
    label: "Cerebras",
    company: "Cerebras",
    protocol: "openai",
    baseUrl: "https://api.cerebras.ai/v1",
    defaultModel: "llama-3.3-70b",
    models: ["llama-3.3-70b", "llama3.1-8b"],
    envKeys: ["CEREBRAS_API_KEY"],
    keyless: false,
    strengths: ["fast"],
    blurb: "Wafer-scale speed for reflex turns.",
  },
  {
    id: "ollama",
    label: "Local Ollama",
    company: "Your machine",
    protocol: "openai",
    baseUrl: "http://localhost:11434/v1",
    defaultModel: "llama3.2",
    models: ["llama3.2", "qwen2.5", "mistral"],
    envKeys: [],
    keyless: true,
    strengths: ["code", "general"],
    blurb: "Runs entirely on hardware you own — no company at all.",
  },
  {
    id: "openwire",
    label: "Open Wire",
    company: "Public mesh",
    protocol: "openai",
    baseUrl: "https://text.pollinations.ai/openai",
    defaultModel: "openai",
    models: ["openai", "openai-fast", "mistral"],
    envKeys: [],
    keyless: true,
    strengths: ["fast", "general"],
    blurb: "Free public brain — the creature never goes mute without it.",
  },
];

export type BrainKeyring = Record<string, string>; // brainId -> user key

export function keyFor(brains: Brain, ring: BrainKeyring): string {
  if (ring[brains.id]) return ring[brains.id];
  for (const env of brains.envKeys) {
    const v = process.env[env];
    if (v) return v;
  }
  return "";
}

export function usableBrain(brains: Brain, ring: BrainKeyring): boolean {
  return brains.keyless || Boolean(keyFor(brains, ring));
}

const CODE = /\b(code|function|bug|error|python|javascript|typescript|react|sql|api|regex|compile|stack trace|refactor)\b/i;
const REASON = /\b(why|explain|prove|compare|analy[sz]e|trade-?off|strategy|plan|design|architecture|evidence|root cause)\b/i;
const LONG = /\b(summar|long|document|transcript|report|article|chapter|everything|all the)\b/i;
const FAST = /\b(quick|short|fast|now|immediately|one line|briefly)\b/i;

/** Which brain suits this question, given how each has behaved lately. */
export function rankBrains(
  question: string,
  ring: BrainKeyring,
  health: Record<string, { ok: number; fail: number; latencyMs: number }>,
  preference = "auto",
): Brain[] {
  const want = [
    CODE.test(question) ? "code" : null,
    REASON.test(question) ? "reasoning" : null,
    LONG.test(question) ? "long-context" : null,
    FAST.test(question) ? "fast" : null,
  ].filter(Boolean) as string[];

  const pool = BRAINS.filter((b) => usableBrain(b, ring));

  return pool
    .map((b) => {
      const h = health[b.id];
      const reliability = h
        ? h.ok / Math.max(1, h.ok + h.fail)
        : b.keyless
          ? 0.75
          : 0.9;
      const speed = h && h.latencyMs > 0 ? Math.max(0, 1 - h.latencyMs / 12000) : 0.6;
      const fit = want.reduce((acc, w) => acc + (b.strengths.includes(w) ? 1.4 : 0), 0);
      const preferred = preference !== "auto" && b.id === preference ? 6 : 0;
      const size = b.keyless ? 0.4 : 1;
      return { b, score: fit * 2 + reliability * 2.4 + speed + preferred + size };
    })
    .sort((x, y) => y.score - x.score)
    .map((x) => x.b);
}

/* ------------------------------ streaming ----------------------------- */

async function* sseLines(body: ReadableStream<Uint8Array>): AsyncGenerator<string> {
  const reader = body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const parts = buf.split("\n");
    buf = parts.pop() ?? "";
    for (const raw of parts) {
      const line = raw.trim();
      if (!line) continue;
      if (line.startsWith("data:")) yield line.slice(5).trim();
      else yield line;
    }
  }
}

export type Turn = { role: "system" | "user" | "assistant"; content: string };

/** Stream one brain's answer. Throws on any failure so the mesh can move on. */
export async function* streamBrain(
  brain: Brain,
  apiKey: string,
  model: string,
  turns: Turn[],
  signal?: AbortSignal,
): AsyncGenerator<string> {
  const key = apiKey;
  const headers: Record<string, string> = { "Content-Type": "application/json" };

  if (brain.protocol === "anthropic") {
    const res = await fetch(`${brain.baseUrl}/v1/messages`, {
      method: "POST",
      signal,
      headers: {
        ...headers,
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true",
      },
      body: JSON.stringify({
        model,
        max_tokens: 1800,
        stream: true,
        system: turns.find((t) => t.role === "system")?.content,
        messages: turns.filter((t) => t.role !== "system"),
      }),
    });
    if (!res.ok) throw new Error(`claude ${res.status}: ${(await res.text()).slice(0, 160)}`);
    for await (const payload of sseLines(res.body!)) {
      try {
        const j = JSON.parse(payload);
        if (j.type === "content_block_delta" && j.delta?.text) yield j.delta.text;
        if (j.type === "error") throw new Error(j.error?.message ?? "claude error");
      } catch (e) {
        if (e instanceof Error && !e.message.includes("JSON")) throw e;
      }
    }
    return;
  }

  if (brain.protocol === "google") {
    const res = await fetch(
      `${brain.baseUrl}/models/${model}:streamGenerateContent?alt=sse`,
      {
        method: "POST",
        signal,
        headers: { ...headers, "x-goog-api-key": key },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: turns.find((t) => t.role === "system")?.content ?? "" }],
          },
          contents: turns
            .filter((t) => t.role !== "system")
            .map((t) => ({
              role: t.role === "assistant" ? "model" : "user",
              parts: [{ text: t.content }],
            })),
        }),
      },
    );
    if (!res.ok) throw new Error(`gemini ${res.status}: ${(await res.text()).slice(0, 160)}`);
    for await (const payload of sseLines(res.body!)) {
      try {
        const j = JSON.parse(payload);
        for (const p of j.candidates?.[0]?.content?.parts ?? []) if (p.text) yield p.text;
      } catch {
        /* partial frame */
      }
    }
    return;
  }

  // OpenAI-compatible
  const res = await fetch(`${brain.baseUrl}/chat/completions`, {
    method: "POST",
    signal,
    headers: {
      ...headers,
      Authorization: `Bearer ${key || "no-key"}`,
      "HTTP-Referer": "https://wire.local",
      "X-Title": "WIRE Desk",
    },
    body: JSON.stringify({ model, stream: true, temperature: 0.35, messages: turns }),
  });
  if (!res.ok) throw new Error(`${brain.id} ${res.status}: ${(await res.text()).slice(0, 160)}`);
  for await (const payload of sseLines(res.body!)) {
    if (payload === "[DONE]") return;
    try {
      const j = JSON.parse(payload);
      const d = j.choices?.[0]?.delta?.content;
      if (d) yield d;
    } catch {
      /* partial frame */
    }
  }
}
