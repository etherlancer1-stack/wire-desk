/**
 * WIRE — model layer.
 *
 * Real streaming calls to whichever provider the desk is configured for
 * (OpenAI-compatible, Anthropic, Google). Keys come from the environment or
 * from the user's own settings panel (sent per request, never stored server side).
 *
 * If no key is available at all, `synthesize()` produces an honest extractive
 * brief from the pages that were actually read — labelled as such in the UI.
 */

import type { Wire } from "./search";

export type Provider =
  | "open"
  | "openai"
  | "anthropic"
  | "google"
  | "groq"
  | "custom";

export type ChatSettings = {
  provider: Provider;
  apiKey: string;
  baseUrl: string;
  model: string;
};

export const PROVIDERS: Record<
  Provider,
  { label: string; defaultModel: string; placeholder: string; baseUrl: string }
> = {
  open: {
    label: "Open Wire",
    defaultModel: "openai",
    placeholder: "no key required",
    baseUrl: "https://text.pollinations.ai/openai",
  },
  openai: {
    label: "OpenAI",
    defaultModel: "gpt-4o-mini",
    placeholder: "sk-…",
    baseUrl: "https://api.openai.com/v1",
  },
  groq: {
    label: "Groq",
    defaultModel: "llama-3.3-70b-versatile",
    placeholder: "gsk_…",
    baseUrl: "https://api.groq.com/openai/v1",
  },
  anthropic: {
    label: "Anthropic",
    defaultModel: "claude-3-5-haiku-latest",
    placeholder: "sk-ant-…",
    baseUrl: "https://api.anthropic.com",
  },
  google: {
    label: "Google Gemini",
    defaultModel: "gemini-2.0-flash",
    placeholder: "AIza…",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta",
  },
  custom: {
    label: "OpenAI-compatible",
    defaultModel: "gpt-4o-mini",
    placeholder: "key (optional)",
    baseUrl: "http://localhost:11434/v1",
  },
};

export function resolveSettings(input: Partial<ChatSettings> | undefined): ChatSettings {
  const provider = (input?.provider ?? "open") as Provider;
  const meta = PROVIDERS[provider] ?? PROVIDERS.open;
  const envKey =
    provider === "open"
      ? ""
      : provider === "anthropic"
      ? process.env.ANTHROPIC_API_KEY
      : provider === "google"
        ? process.env.GEMINI_API_KEY ?? process.env.GOOGLE_API_KEY
        : provider === "groq"
          ? process.env.GROQ_API_KEY
          : process.env.OPENAI_API_KEY;
  return {
    provider,
    apiKey: input?.apiKey?.trim() || envKey || "",
    baseUrl: (input?.baseUrl?.trim() || process.env.OPENAI_BASE_URL || meta.baseUrl).replace(
      /\/$/,
      "",
    ),
    model: input?.model?.trim() || process.env.WIRE_MODEL || meta.defaultModel,
  };
}

export function hasModel(settings: ChatSettings): boolean {
  return (
    Boolean(settings.apiKey) ||
    settings.provider === "custom" ||
    settings.provider === "open"
  );
}

export type Turn = { role: "system" | "user" | "assistant"; content: string };

function firstUsable(res: Response, label: string) {
  if (!res.ok) {
    return res.text().then((t) => {
      throw new Error(`${label} ${res.status}: ${t.slice(0, 220)}`);
    });
  }
  return Promise.resolve(res);
}

async function* sseLines(body: ReadableStream<Uint8Array>): AsyncGenerator<string> {
  const reader = body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const parts = buf.split("\n");
    buf = parts.pop() ?? "";
    for (const raw of parts) {
      const line = raw.trim();
      if (!line) continue;
      if (line.startsWith("data:")) yield line.slice(5).trim();
      else yield line;
    }
  }
  if (buf.trim()) yield buf.trim();
}

/** Streams answer text from the configured provider. */
export async function* streamAnswer(
  turns: Turn[],
  settings: ChatSettings,
  signal?: AbortSignal,
): AsyncGenerator<string> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };

  if (settings.provider === "anthropic") {
    const res = await fetch(`${settings.baseUrl}/v1/messages`, {
      method: "POST",
      signal,
      headers: {
        ...headers,
        "x-api-key": settings.apiKey,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true",
      },
      body: JSON.stringify({
        model: settings.model,
        max_tokens: 1600,
        stream: true,
        system: turns.find((t) => t.role === "system")?.content,
        messages: turns.filter((t) => t.role !== "system"),
      }),
    });
    await firstUsable(res, "Anthropic");
    for await (const payload of sseLines(res.body!)) {
      if (payload === "[DONE]") return;
      let j: any;
      try {
        j = JSON.parse(payload);
      } catch {
        continue;
      }
      if (j.type === "content_block_delta" && j.delta?.text) yield j.delta.text;
      if (j.type === "error") throw new Error(j.error?.message ?? "provider error");
    }
    return;
  }

  if (settings.provider === "google") {
    const res = await fetch(
      `${settings.baseUrl}/models/${settings.model}:streamGenerateContent?alt=sse`,
      {
        method: "POST",
        signal,
        headers: { ...headers, "x-goog-api-key": settings.apiKey },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: turns.find((t) => t.role === "system")?.content ?? "" }],
          },
          contents: turns
            .filter((t) => t.role !== "system")
            .map((t) => ({
              role: t.role === "assistant" ? "model" : "user",
              parts: [{ text: t.content }],
            })),
        }),
      },
    );
    await firstUsable(res, "Gemini");
    for await (const payload of sseLines(res.body!)) {
      try {
        const j = JSON.parse(payload);
        const parts = j.candidates?.[0]?.content?.parts ?? [];
        for (const p of parts) if (p.text) yield p.text;
      } catch {
        /* partial frame */
      }
    }
    return;
  }

  // OpenAI-compatible: OpenAI, Groq, Ollama, vLLM, OpenRouter…
  const res = await fetch(`${settings.baseUrl}/chat/completions`, {
    method: "POST",
    signal,
    headers: {
      ...headers,
      Authorization: `Bearer ${settings.apiKey || "no-key"}`,
    },
    body: JSON.stringify({
      model: settings.model,
      stream: true,
      temperature: 0.3,
      messages: turns,
    }),
  });
  await firstUsable(res, settings.provider);
  for await (const payload of sseLines(res.body!)) {
    if (payload === "[DONE]") return;
    try {
      const j = JSON.parse(payload);
      const d = j.choices?.[0]?.delta?.content;
      if (d) yield d;
    } catch {
      /* partial frame */
    }
  }
}

/** Honest extractive brief when no model key is configured. */
export function synthesize(question: string, wires: Wire[]): string {
  const scored = wires
    .map((w) => {
      const pool = `${w.snippet} ${w.text ?? ""}`.trim();
      const sentences = pool
        .split(/(?<=[.!?])\s+/)
        .map((s) => s.trim())
        .filter((s) => s.length > 45 && s.length < 320);
      const terms = question
        .toLowerCase()
        .replace(/[^\w\s]/g, " ")
        .split(/\s+/)
        .filter((t) => t.length > 3);
      const best = sentences
        .map((s) => ({
          s,
          score: terms.reduce(
            (acc, t) => acc + (s.toLowerCase().includes(t) ? 1 : 0),
            0,
          ),
        }))
        .sort((a, b) => b.score - a.score)
        .slice(0, 2)
        .filter((x) => x.score > 0 || sentences.length < 3)
        .map((x) => x.s);
      return { w, best };
    })
    .filter((x) => x.best.length > 0)
    .slice(0, 6);

  const lines: string[] = [];
  lines.push(
    `Here is what the ${wires.length} pages just read actually establish, in their own words — every line carries the number of the page it came from:`,
  );
  lines.push("");
  lines.push(`### What the sources say`);
  for (const { w, best } of scored) {
    for (const s of best) {
      lines.push(`- ${s} [${w.idx}]`);
    }
  }
  if (!scored.length) {
    lines.push(
      `- No passage on the wire matched this question directly. Try rephrasing, or switch on Deep Search to read whole pages. [1]`,
    );
  }
  lines.push("");
  lines.push(`### Question`);
  lines.push(`> ${question}`);
  return lines.join("\n");
}
