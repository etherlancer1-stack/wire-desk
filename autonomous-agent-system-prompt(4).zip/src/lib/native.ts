/**
 * WIRE — native core bridge.
 *
 * The performance-critical engine (hashing, encoding, cipher identification,
 * inspection) is implemented in Rust in `wire-core/` — dependency-free,
 * test-verified, and orders of magnitude faster than interpreted code.
 *
 * This bridge uses the native binary whenever it is present and falls back to
 * the TypeScript implementation otherwise, so the desk keeps working before
 * the core has been compiled. Nothing else in the system needs to know which
 * engine answered.
 */

import { execFile } from "node:child_process";
import { existsSync } from "node:fs";
import path from "node:path";

const CANDIDATES = [
  path.join(process.cwd(), "wire-core", "target", "release", "wire-core"),
  path.join(process.cwd(), "wire-core", "target", "debug", "wire-core"),
  "/usr/local/bin/wire-core",
  "/usr/bin/wire-core",
];

export function nativePath(): string | null {
  return CANDIDATES.find((p) => existsSync(p)) ?? null;
}

export function nativeAvailable(): boolean {
  return nativePath() !== null;
}

export type NativeResult = { ok: boolean; engine: "rust" | "typescript"; output: string };

/** Run a core command natively. Returns null when the binary is unavailable. */
export async function runNative(command: string, args: string[]): Promise<NativeResult | null> {
  const bin = nativePath();
  if (!bin) return null;
  return new Promise<NativeResult | null>((resolve) => {
    try {
      execFile(
        bin,
        [command, ...args],
        { timeout: 4000, maxBuffer: 256 * 1024, windowsHide: true },
        (err, stdout, stderr) => {
          if (err && !stdout) {
            // The binary exists but refused — let the TypeScript path answer.
            resolve(null);
            return;
          }
          resolve({
            ok: !err && !stderr?.trim(),
            engine: "rust",
            output: (stdout || stderr || "").trim(),
          });
        },
      );
    } catch {
      resolve(null);
    }
  });
}

export function engineInfo() {
  return {
    engine: nativeAvailable() ? "rust" : "typescript",
    binary: nativePath(),
    note: nativeAvailable()
      ? "Hashing, encoding and cipher work run on the Rust core (dependency-free, test-verified)."
      : "Rust core not compiled — running the TypeScript engine. Build it with: cd wire-core && cargo build --release",
  };
}
