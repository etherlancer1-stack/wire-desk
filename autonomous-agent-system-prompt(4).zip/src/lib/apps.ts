/**
 * WIRE — app connectors.
 *
 * The desk can be wired into other apps and work through them: Google (via
 * Serper or Custom Search), the open web, Wikipedia, GitHub, Stack Overflow,
 * arXiv, Semantic Scholar, Hacker News, world news, live weather, geocoding
 * and currency rates. Every connector returns the same shape, so anything the
 * desk reads lands in the wire rail as a numbered, citable source.
 */

export type AppHit = {
  title: string;
  url: string;
  domain: string;
  snippet: string;
  origin: string;
  published: string | null;
};

export type Connector = {
  id: string;
  label: string;
  kind: string;
  needs: "none" | "key";
  keyHint: string;
  blurb: string;
  keywords: RegExp;
  run: (query: string, key: string) => Promise<AppHit[]>;
};

const UA = "Mozilla/5.0 (compatible; WIRE-Desk/2.0; +https://wire.local)";

function host(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "web";
  }
}

function clean(s: string): string {
  return (s ?? "")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#?\w+;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

async function get(url: string, headers: Record<string, string> = {}): Promise<any> {
  const res = await fetch(url, {
    signal: AbortSignal.timeout(5000),
    headers: { "User-Agent": UA, Accept: "application/json", ...headers },
  });
  if (!res.ok) throw new Error(`${host(url)} ${res.status}`);
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

function hit(
  title: string,
  url: string,
  snippet: string,
  origin: string,
  published: string | null = null,
): AppHit {
  return {
    title: clean(title) || host(url),
    url,
    domain: host(url),
    snippet: clean(snippet).slice(0, 340),
    origin,
    published,
  };
}

/* ------------------------------ connectors ----------------------------- */

export const CONNECTORS: Connector[] = [
  {
    id: "google",
    label: "Google Search",
    kind: "search",
    needs: "key",
    keyHint: "SERPER API KEY (google.serper.dev)",
    blurb:
      "Real Google results — snippets, top stories and answer boxes. Paste a Serper key to connect.",
    keywords: /.*/,
    async run(query, key) {
      const res = await fetch("https://google.serper.dev/search", {
        method: "POST",
        signal: AbortSignal.timeout(9000),
        headers: {
          "Content-Type": "application/json",
          "X-API-KEY": key,
          "User-Agent": UA,
        },
        body: JSON.stringify({ q: query, num: 10 }),
      });
      if (!res.ok) throw new Error(`google ${res.status}`);
      const data = await res.json();
      const organic = (data.organic ?? []).map((r: any) =>
        hit(r.title, r.link, r.snippet ?? "", "google", r.date ?? null),
      );
      const news = (data.news ?? []).map((r: any) =>
        hit(r.title, r.link, r.snippet ?? "", "google news", r.date ?? null),
      );
      return [...organic, ...news];
    },
  },
  {
    id: "web",
    label: "Open Web",
    kind: "search",
    needs: "none",
    keyHint: "connected by default",
    blurb: "The independent web index — general pages, docs and blogs.",
    keywords: /.*/,
    async run(query) {
      const { runSearch } = await import("./search");
      const wires = await runSearch(query, { deep: true, keys: {} });
      return wires.map((w) => ({
        title: w.title,
        url: w.url,
        domain: w.domain,
        snippet: w.snippet,
        origin: `web · ${w.origin}`,
        published: w.published,
      }));
    },
  },
  {
    id: "wikipedia",
    label: "Wikipedia",
    kind: "reference",
    needs: "none",
    keyHint: "connected by default",
    blurb: "Encyclopedic grounding with full page extracts.",
    keywords: /.*/,
    async run(query) {
      const data = await get(
        `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
          query,
        )}&srlimit=5&format=json`,
      );
      const hits: any[] = data.query?.search ?? [];
      const out: AppHit[] = [];
      await Promise.all(
        hits.slice(0, 3).map(async (h: any) => {
          try {
            const s = await get(
              `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(h.title)}`,
            );
            out.push(
              hit(
                s.title ?? h.title,
                s.content_urls?.desktop?.page ??
                  `https://en.wikipedia.org/wiki/${encodeURIComponent(h.title)}`,
                s.extract ?? clean(h.snippet),
                "wikipedia",
              ),
            );
          } catch {
            /* skip */
          }
        }),
      );
      return out;
    },
  },
  {
    id: "github",
    label: "GitHub",
    kind: "developer",
    needs: "none",
    keyHint: "connected by default",
    blurb: "Repositories, stars and READMEs from the developer world.",
    keywords: /\b(code|repo|github|library|framework|package|open.?source|bug|api|sdk)\b/i,
    async run(query) {
      const data = await get(
        `https://api.github.com/search/repositories?q=${encodeURIComponent(
          query,
        )}&sort=stars&order=desc&per_page=5`,
      );
      return (data.items ?? []).map((r: any) =>
        hit(
          r.full_name,
          r.html_url,
          `${r.description ?? ""} · ★${r.stars ?? 0} · ${r.language ?? "mixed"} · updated ${
            (r.updated_at ?? "").slice(0, 10)
          }`,
          "github",
          (r.updated_at ?? "").slice(0, 10),
        ),
      );
    },
  },
  {
    id: "stackoverflow",
    label: "Stack Overflow",
    kind: "developer",
    needs: "none",
    keyHint: "connected by default",
    blurb: "Solved programming problems with vote counts.",
    keywords: /\b(error|code|function|python|javascript|typescript|react|sql|css|bug|debug|how do i|exception)\b/i,
    async run(query) {
      const data = await get(
        `https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q=${encodeURIComponent(
          query,
        )}&site=stackoverflow&pagesize=5`,
      );
      return (data.items ?? []).map((r: any) =>
        hit(
          clean(r.title),
          r.link,
          `Score ${r.score} · ${r.answer_count} answers · tags: ${(r.tags ?? []).join(", ")}`,
          "stackoverflow",
        ),
      );
    },
  },
  {
    id: "arxiv",
    label: "arXiv",
    kind: "science",
    needs: "none",
    keyHint: "connected by default",
    blurb: "Preprints straight from the research frontier.",
    keywords: /\b(paper|research|study|arxiv|physics|math|model|neural|quantum|algorithm|proof)\b/i,
    async run(query) {
      const res = await fetch(
        `https://export.arxiv.org/api/query?search_query=all:${encodeURIComponent(
          query,
        )}&max_results=5&sortBy=relevance`,
        { signal: AbortSignal.timeout(10000), headers: { "User-Agent": UA } },
      );
      const xml = await res.text();
      const entries = xml.split("<entry>").slice(1);
      return entries.map((e) => {
        const pick = (tag: string) =>
          clean(
            new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`).exec(e)?.[1] ?? "",
          );
        const url = (new RegExp("<id>(.*?)</id>").exec(e)?.[1] ?? "").trim();
        return hit(
          pick("title"),
          url,
          pick("summary"),
          "arxiv",
          pick("published").slice(0, 10),
        );
      });
    },
  },
  {
    id: "papers",
    label: "Semantic Scholar",
    kind: "science",
    needs: "none",
    keyHint: "connected by default",
    blurb: "Peer-reviewed papers with abstracts and citation trails.",
    keywords: /\b(paper|study|research|evidence|meta.?analysis|trial|science|academic)\b/i,
    async run(query) {
      const data = await get(
        `https://api.semanticscholar.org/graph/v1/paper/search?query=${encodeURIComponent(
          query,
        )}&limit=4&fields=title,abstract,url,year,authors,externalIds`,
      );
      return (data.data ?? []).map((p: any) =>
        hit(
          p.title,
          p.url ??
            (p.externalIds?.DOI
              ? `https://doi.org/${p.externalIds.DOI}`
              : "https://www.semanticscholar.org"),
          `${p.abstract ?? "Peer-reviewed paper."}`,
          "paper",
          p.year ? String(p.year) : null,
        ),
      );
    },
  },
  {
    id: "news",
    label: "World News",
    kind: "news",
    needs: "none",
    keyHint: "connected by default",
    blurb: "Global coverage from the last 7 days via GDELT.",
    keywords: /\b(news|today|latest|this week|breaking|happened|election|war|market|update)\b/i,
    async run(query) {
      const data = await get(
        `https://api.gdeltproject.org/api/v2/doc/doc?query=${encodeURIComponent(
          query,
        )}&mode=ArtList&maxrecords=6&format=json&timespan=1week`,
      );
      return (data.articles ?? []).map((a: any) =>
        hit(a.title, a.url, `Coverage · ${a.domain ?? ""}`, "news", a.seendate),
      );
    },
  },
  {
    id: "weather",
    label: "Weather",
    kind: "live data",
    needs: "none",
    keyHint: "connected by default",
    blurb: "Live conditions and 3-day forecast for any place on earth.",
    keywords: /\b(weather|temperature|forecast|rain|snow|climate|hot|cold|storm)\b/i,
    async run(query) {
      const place =
        /(?:in|for|at|of)\s+([A-Za-zÀ-ÿ' \-]{2,40})/i.exec(query)?.[1] ??
        query.replace(/[^A-Za-zÀ-ÿ' \-]/g, " ").trim().slice(0, 40);
      const geo = await get(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
          place.trim(),
        )}&count=1&language=en&format=json`,
      );
      const loc = geo?.results?.[0];
      if (!loc) return [];
      const wx = await get(
        `https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,precipitation,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=3`,
      );
      const c = wx.current ?? {};
      const d = wx.daily ?? {};
      const days = (d.time ?? [])
        .map(
          (t: string, i: number) =>
            `${t}: ${d.temperature_2m_min?.[i]}–${d.temperature_2m_max?.[i]}°C, rain ${d.precipitation_probability_max?.[i]}%`,
        )
        .join(" · ");
      return [
        hit(
          `Weather — ${loc.name}, ${loc.country ?? ""}`,
          `https://open-meteo.com/en/docs#latitude=${loc.latitude}&longitude=${loc.longitude}`,
          `Now ${c.temperature_2m}°C, humidity ${c.relative_humidity_2m}%, wind ${c.wind_speed_10m} km/h, precipitation ${c.precipitation} mm (code ${c.weather_code}). Next days: ${days}`,
          "live data",
          wx.current?.time ?? null,
        ),
      ];
    },
  },
  {
    id: "geocode",
    label: "Places & Maps",
    kind: "live data",
    needs: "none",
    keyHint: "connected by default",
    blurb: "Coordinates and administrative data for anywhere (Open-Meteo / OSM).",
    keywords: /\b(where|located|capital|coordinates|map|distance|city|country|place)\b/i,
    async run(query) {
      const name = query.replace(/[^A-Za-zÀ-ÿ' \-]/g, " ").trim().slice(0, 48);
      const geo = await get(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
          name,
        )}&count=3&language=en&format=json`,
      );
      return (geo?.results ?? []).map((r: any) =>
        hit(
          `${r.name}, ${r.admin1 ?? ""} ${r.country ?? ""}`,
          `https://www.openstreetmap.org/#map=9/${r.latitude}/${r.longitude}`,
          `lat ${r.latitude}, lon ${r.longitude} · population ${r.population ?? "n/a"} · timezone ${r.timezone ?? "n/a"}`,
          "places",
        ),
      );
    },
  },
  {
    id: "gmail",
    label: "Gmail",
    kind: "communication",
    needs: "key",
    keyHint: "GOOGLE OAUTH / API TOKEN",
    blurb:
      "Read your own mailbox on request — search messages, pull subjects and senders, and answer from them. Paste a Google OAuth token with gmail.readonly.",
    keywords: /\b(email|inbox|gmail|mail|message from|sent me|correspondence)\b/i,
    async run(query, key) {
      if (!key) return [];
      const q = encodeURIComponent(query.slice(0, 120));
      const list = await get(
        `https://gmail.googleapis.com/gmail/v1/users/me/messages?q=${q}&maxResults=5`,
        { Authorization: `Bearer ${key}` },
      );
      const ids: string[] = (list.messages ?? []).map((m: any) => m.id);
      const out: AppHit[] = [];
      for (const id of ids.slice(0, 5)) {
        try {
          const msg = await get(
            `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date`,
            { Authorization: `Bearer ${key}` },
          );
          const headers = Object.fromEntries(
            (msg.payload?.headers ?? []).map((h: any) => [h.name.toLowerCase(), h.value]),
          );
          out.push(
            hit(
              headers.subject ?? "(no subject)",
              `https://mail.google.com/mail/u/0/#inbox/${id}`,
              `From ${headers.from ?? "unknown"} · ${headers.date ?? ""} · snippet: ${(msg.snippet ?? "").slice(0, 180)}`,
              "gmail",
              headers.date ?? null,
            ),
          );
        } catch {
          /* skip unreadable message */
        }
      }
      return out;
    },
  },
  {
    id: "books",
    label: "Books & Literature",
    kind: "reference",
    needs: "none",
    keyHint: "connected by default",
    blurb: "Millions of books, editions and authors via Open Library.",
    keywords: /\b(book|novel|author|written by|literature|publish(ed|ing)|nonfiction|fiction|poetry|history of)\b/i,
    async run(query) {
      const data = await get(
        `https://openlibrary.org/search.json?q=${encodeURIComponent(query)}&limit=5`,
      );
      return (data.docs ?? []).map((d: any) =>
        hit(
          d.title,
          `https://openlibrary.org${d.key ?? ""}`,
          `${(d.author_name ?? []).slice(0, 2).join(", ")} · first published ${d.first_publish_year ?? "unknown"} · ${(d.subject ?? []).slice(0, 5).join(", ")}`,
          "books",
          d.first_publish_year ? String(d.first_publish_year) : null,
        ),
      );
    },
  },
  {
    id: "earthquakes",
    label: "Live Earth Hazards",
    kind: "live data",
    needs: "none",
    keyHint: "connected by default",
    blurb: "Real-time seismic activity worldwide from the USGS network.",
    keywords: /\b(earthquake|seismic|tremor|magnitude|volcano|tsunami|disaster|happening now)\b/i,
    async run(query) {
      const data = await get(
        "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson",
      );
      return (data.features ?? []).slice(0, 6).map((f: any) =>
        hit(
          `M${f.properties.mag?.toFixed?.(1) ?? "?"} — ${f.properties.place}`,
          f.properties.url,
          `USGS · ${new Date(f.properties.time).toUTCString()} · depth ${f.geometry?.coordinates?.[2] ?? "?"} km`,
          "live data",
          new Date(f.properties.time).toISOString(),
        ),
      );
    },
  },
  {
    id: "currency",
    label: "Currency Rates",
    kind: "live data",
    needs: "none",
    keyHint: "connected by default",
    blurb: "Live ECB exchange rates.",
    keywords: /\b(usd|eur|gbp|jpy|inr|currency|exchange|rate|convert|bitcoin|money|price of)\b/i,
    async run(query) {
      const pair = /([A-Z]{3})\s*(?:to|in|->|\/)\s*([A-Z]{3})/i.exec(query);
      const from = (pair?.[1] ?? "USD").toUpperCase();
      const to = (pair?.[2] ?? "EUR").toUpperCase();
      const data = await get(
        `https://api.frankfurter.app/latest?from=${from}&to=${to}`,
      );
      const rate = data?.rates?.[to];
      return [
        hit(
          `${from} → ${to} exchange rate`,
          `https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html`,
          `1 ${from} = ${rate ?? "n/a"} ${to} · ECB reference rate, date ${data?.date ?? "latest"}`,
          "live data",
          data?.date ?? null,
        ),
      ];
    },
  },
];

/** Pick the connectors that match the question (always includes web + wikipedia). */
export function routeApps(
  question: string,
  enabled: Set<string>,
  deep: boolean,
): Connector[] {
  const always = new Set(["web", "wikipedia", "google"]);
  const picked = CONNECTORS.filter((c) => {
    if (!enabled.has(c.id)) return false;
    if (always.has(c.id)) return true;
    return c.keywords.test(question);
  });
  const core = picked.filter((c) => always.has(c.id));
  const extra = picked.filter((c) => !always.has(c.id));
  return [...core, ...(deep ? extra : extra.slice(0, 2))];
}
