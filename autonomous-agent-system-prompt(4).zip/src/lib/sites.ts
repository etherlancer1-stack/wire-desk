/**
 * WIRE — the builder.
 *
 * When you ask for a website, the desk writes it and keeps it: a complete,
 * self-contained document, stored on this server and served at an unguessable
 * private link that is yours alone. No build step, no dependencies, no account.
 */

import { randomBytes } from "node:crypto";

export function siteSlug(): string {
  return randomBytes(9).toString("base64url");
}

/** Pull the largest complete HTML document out of a model answer. */
export function extractHtml(answer: string): string | null {
  const blocks = [...answer.matchAll(/```(?:html|HTML)?\s*\n([\s\S]*?)```/g)].map(
    (m) => m[1].trim(),
  );
  const doc = blocks.find((b) => /<(!doctype|html|head|body)/i.test(b));
  if (doc && doc.length > 200) return doc;
  // Fallback: a bare document that was never fenced.
  const raw = answer.match(/<!DOCTYPE html>[\s\S]{200,}/i);
  return raw ? raw[0] : null;
}

/** Keep only what a static page needs — never scripts that call home. */
export function sanitizeSiteHtml(html: string): string {
  let out = html.slice(0, 400_000);
  out = out.replace(/<script[^>]*src=["']https?:\/\/(?!fonts\.|cdn\.jsdelivr)[^"']*["'][^>]*>\s*<\/script>/gi, "");
  out = out.replace(/<link[^>]*href=["']https?:\/\/(?!fonts\.)[^"']*["'][^>]*>/gi, "");
  return out;
}

/** Wrap any document in WIRE chrome so a build always looks finished. */
export function wrapSite(html: string, title: string): string {
  const body = /<body[^>]*>([\s\S]*)<\/body>/i.exec(html)?.[1] ?? html;
  const head = /<head[^>]*>([\s\S]*?)<\/head>/i.exec(html)?.[1] ?? "";
  const styles = /<style[^>]*>([\s\S]*?)<\/style>/i.exec(html)?.[1] ?? "";
  const scripts = /<script(?![^>]*src)[^>]*>([\s\S]*?)<\/script>/i.exec(html)?.[1] ?? "";
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="robots" content="noindex, nofollow" />
<title>${title.replace(/[<>&]/g, "")}</title>
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,700;9..144,900&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet" />
<style>${styles}</style>
</head>
<body>
${body}
<script>${scripts}</script>
</body>
</html>`;
}

export const BUILD_RULES = [
  "When asked to build a website, page, dashboard or app: design and deliver it, then output ONE complete self-contained HTML document in a single ```html fenced block.",
  "Inside that block: inline <style> and <script>, mobile-responsive, semantic markup, real copy written for the user's subject (never lorem ipsum), and no external assets except Google Fonts.",
  "Give the build real craft: a considered type pairing, a clear grid, deliberate colour, states for hover/focus, and content specific to what was asked.",
  "Outside the block, answer in two or three sentences: what you built and what to look at first. The desk saves the block automatically and returns a private link.",
].join("\n");
