/**
 * WIRE — the resident engineer.
 *
 * Inside the desk there is an agent whose job is the desk itself. It reads the
 * system's own source code, analyses it for real defects, writes concrete
 * patches, applies them under version control with one-click rollback, and
 * updates the desk's automation and behavioural code on a daily cycle.
 *
 * The one rule it cannot rewrite: changes to running source are applied only
 * through an exact, single-match textual patch — a rewrite that does not match
 * cleanly is rejected rather than guessed at. That is what lets it write its
 * own code without ever bricking itself.
 */

import { desc, eq } from "drizzle-orm";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { db } from "@/db";
import { agentRuns, codex, patches } from "@/db/schema";
import { keyFor, rankBrains, streamBrain, type Turn } from "./mesh";

export const OWNED_FILES = [
  "src/lib/agent.ts",
  "src/lib/brain.ts",
  "src/lib/evolve.ts",
  "src/lib/mesh.ts",
  "src/lib/search.ts",
  "src/lib/apps.ts",
  "src/lib/commands.ts",
  "src/lib/sites.ts",
  "src/lib/gateway.ts",
  "src/lib/life.ts",
];

export type Finding = {
  severity: "high" | "medium" | "low";
  file: string;
  line: number;
  issue: string;
  fix: string;
};

export type OwnFile = { file: string; lines: number; bytes: number; text: string };

export async function readOwnCode(): Promise<OwnFile[]> {
  const out: OwnFile[] = [];
  for (const file of OWNED_FILES) {
    try {
      const text = await readFile(path.join(process.cwd(), file), "utf8");
      out.push({ file, lines: text.split("\n").length, bytes: text.length, text });
    } catch {
      /* file may not exist in this build */
    }
  }
  return out;
}

/** Deterministic code analysis — real defects, not vibes. */
export function analyzeCode(files: OwnFile[]) {
  const findings: Finding[] = [];
  let functions = 0;
  let totalLines = 0;

  for (const f of files) {
    totalLines += f.lines;
    const lines = f.text.split("\n");
    functions += (f.text.match(/(export )?(async )?function\s|\)\s*=>\s*\{|=>\s*AsyncGenerator/g) ?? []).length;

    let blockStart = 0;
    let blockName = "module scope";
    lines.forEach((line, i) => {
      const n = i + 1;
      const decl = /(?:export )?(?:async )?function\s+(\w+)/.exec(line);
      if (decl) {
        if (i - blockStart > 90) {
          findings.push({
            severity: "medium",
            file: f.file,
            line: blockStart + 1,
            issue: `\`${blockName}\` runs ${i - blockStart} lines — too long to reason about safely`,
            fix: "Split it: isolate the IO, the decision and the effect.",
          });
        }
        blockStart = i;
        blockName = decl[1];
      }
      if (/catch\s*(\{\s*\}|(\(\w+\)\s*)?\{\s*\})/.test(line) || /^\s*\/\*/.test(lines[i + 1] ?? "") && /catch/.test(line)) {
        findings.push({
          severity: "low",
          file: f.file,
          line: n,
          issue: "A swallowed error hides real failures from the desk",
          fix: "Record the failure (health table, event or learned note) before continuing.",
        });
      }
      if (/fetch\([^)]*\)(?![\s\S]{0,120}timeout)/.test(line) && !/timeout/i.test(lines.slice(i, i + 4).join(" "))) {
        findings.push({
          severity: "high",
          file: f.file,
          line: n,
          issue: "A network call with no timeout can hang a whole turn",
          fix: "Wrap it in AbortSignal.timeout(...) so the mesh can move to the next source.",
        });
      }
      if (/:\s*any\b|as any/.test(line)) {
        findings.push({
          severity: "low",
          file: f.file,
          line: n,
          issue: "An `any` escape hatch removes type safety at the boundary",
          fix: "Give the payload a real type or an explicit narrow.",
        });
      }
    });
    if (f.lines > 380) {
      findings.push({
        severity: "low",
        file: f.file,
        line: 1,
        issue: `${f.file} is ${f.lines} lines — growing past what one file should carry`,
        fix: "Extract a focused module before adding to it again.",
      });
    }
  }

  const high = findings.filter((x) => x.severity === "high").length;
  const med = findings.filter((x) => x.severity === "medium").length;
  const score = Math.max(12, Math.min(99, 100 - high * 9 - med * 4 - findings.length));

  return {
    score,
    findings: findings.slice(0, 40),
    metrics: {
      files: files.length,
      lines: totalLines,
      functions,
      high,
      medium: med,
      low: findings.filter((x) => x.severity === "low").length,
    },
  };
}

/* ------------------------------- the agent ------------------------------ */

function patchSpec(): string {
  return [
    "Reply with at most 4 patches, each in exactly this block format:",
    "<<<PATCH",
    "kind: behavior | automation | source",
    "file: src/lib/agent.ts (for source patches) or codex",
    "title: one line",
    "rationale: one line tied to the evidence",
    "body:",
    "for behavior/automation: the rule text itself, one or two sentences.",
    "for source: a single exact replacement block:",
    "@@FIND:",
    "the exact existing lines, copied verbatim",
    "@@REPLACE:",
    "the improved lines",
    "PATCH>>>",
    "Rules: prefer behavior/automation patches. A source patch must be small, self-contained, and its FIND text must exist verbatim exactly once. Never touch routes, schemas, auth, or anything that deletes data.",
  ].join("\n");
}

export async function proposePatches(
  analysis: ReturnType<typeof analyzeCode>,
  evidence: string,
): Promise<{ title: string; kind: string; file: string; rationale: string; body: string }[]> {
  const health = {};
  const brain = rankBrains("analyse code and propose precise patches", {}, health, "auto")[0];
  if (!brain) return [];

  const top = analysis.findings.slice(0, 12);
  const turns: Turn[] = [
    {
      role: "system",
      content:
        "You are the resident engineer inside WIRE, an autonomous research desk. Your job is to improve the system's own code and operating rules. You are precise, conservative and evidence-driven: you only propose changes that make the system measurably better. " +
        patchSpec(),
    },
    {
      role: "user",
      content: [
        `SYSTEM ANALYSIS (score ${analysis.score}/100):`,
        JSON.stringify(analysis.metrics),
        "TOP FINDINGS:",
        top.map((f) => `- [${f.severity}] ${f.file}:${f.line} — ${f.issue} · fix: ${f.fix}`).join("\n"),
        "RUNTIME EVIDENCE:",
        evidence,
      ].join("\n\n"),
    },
  ];

  let out = "";
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 75_000);
  try {
    for await (const delta of streamBrain(
      brain,
      keyFor(brain, {}),
      brain.defaultModel,
      turns,
      controller.signal,
    )) {
      out += delta;
      if (out.length > 6000) break;
    }
  } catch {
    /* the engineer proposes what it can; a dead brain never blocks a cycle */
  } finally {
    clearTimeout(timer);
  }

  const blocks = [...out.matchAll(/<<<PATCH\n([\s\S]*?)PATCH>>>/g)].map((m) => m[1]);
  return blocks
    .map((b) => {
      const field = (name: string) =>
        new RegExp(`^${name}:\\s*(.*)$`, "m").exec(b)?.[1]?.trim() ?? "";
      const body = /body:\n([\s\S]*)$/.exec(b)?.[1]?.trim() ?? "";
      return {
        kind: field("kind") || "behavior",
        file: field("file") || "codex",
        title: field("title") || "Refinement",
        rationale: field("rationale") || "Proposed by the resident engineer.",
        body,
      };
    })
    .filter((p) => p.body.length > 20)
    .slice(0, 4);
}

/** One full daily cycle: analyse, propose, file the patches. */
export async function runUpgrade(): Promise<{
  report: string;
  score: number;
  patches: typeof patches.$inferSelect[];
}> {
  const files = await readOwnCode();
  const analysis = analyzeCode(files);
  const evidenceRows = await db.select().from(codex).limit(6);
  const evidence = evidenceRows.map((c) => `[${c.kind}] ${c.content}`).join("\n");

  const proposed = await proposePatches(analysis, evidence).catch(() => []);

  // The cycle must always produce work. If the model offered nothing parseable,
  // the engineer files the fixes its own analysis already proved necessary.
  const effective: {
    kind: string;
    file: string;
    title: string;
    rationale: string;
    body: string;
  }[] = proposed.length
    ? proposed
    : analysis.findings.slice(0, 3).map((f) => ({
        kind: "behavior",
        file: "codex",
        title: `Fix: ${f.issue}`,
        rationale: `Proven by self-analysis at ${f.file}:${f.line}.`,
        body: `${f.fix} — enforce this on every turn (from ${f.file}:${f.line}, ${f.issue}).`,
      }));
  const [run] = await db
    .insert(agentRuns)
    .values({
      kind: "upgrade",
      score: analysis.score,
      findings: JSON.stringify(analysis.findings.slice(0, 20)),
      report: `Analyzed ${analysis.metrics.files} files / ${analysis.metrics.lines} lines. Score ${analysis.score}. Model proposed ${proposed.length}; filed ${effective.length} patches.`,
    })
    .returning();

  const rows: typeof patches.$inferSelect[] = [];
  for (const p of effective) {
    const [row] = await db
      .insert(patches)
      .values({
        runId: run.id,
        file: p.file,
        kind: p.kind,
        title: p.title,
        rationale: p.rationale,
        body: p.body,
      })
      .returning();
    rows.push(row);
  }

  return { report: run.report, score: analysis.score, patches: rows };
}

/**
 * Apply a patch. Behavioural and automation patches land immediately in the
 * codex. Source patches rewrite the file only when the FIND block matches
 * exactly once — otherwise the patch is refused, never guessed.
 */
export async function applyPatch(id: string): Promise<{ ok: boolean; message: string }> {
  const [patch] = await db.select().from(patches).where(eq(patches.id, id)).limit(1);
  if (!patch) return { ok: false, message: "No such patch." };

  if (patch.kind !== "source") {
    for (const e of await db.select().from(codex)) {
      if (e.kind === patch.kind) await db.update(codex).set({ active: 0 }).where(eq(codex.id, e.id));
    }
    await db.insert(codex).values({
      kind: patch.kind,
      content: patch.body.slice(0, 500),
      note: `patch: ${patch.title}`,
    });
    await db
      .update(patches)
      .set({ status: "applied", appliedAt: new Date() })
      .where(eq(patches.id, id));
    return { ok: true, message: `Applied to the ${patch.kind} layer — it is already shaping every turn.` };
  }

  const find = /@@FIND:\n([\s\S]*?)\n@@REPLACE:\n([\s\S]*)$/.exec(patch.body);
  if (!find) return { ok: false, message: "That source patch has no exact FIND/REPLACE block." };
  const target = path.join(process.cwd(), patch.file);
  let text: string;
  try {
    text = await readFile(target, "utf8");
  } catch {
    return { ok: false, message: `Cannot read ${patch.file}.` };
  }
  const needle = find[1].replace(/\r/g, "");
  const hay = text.replace(/\r/g, "");
  const occurrences = hay.split(needle).length - 1;
  if (occurrences !== 1) {
    return {
      ok: false,
      message: `Refused: the FIND block matches ${occurrences} times in ${patch.file}. A patch must be unambiguous to apply.`,
    };
  }
  await writeFile(target, hay.replace(needle, find[2]), "utf8");
  await db
    .update(patches)
    .set({ status: "applied", appliedAt: new Date() })
    .where(eq(patches.id, id));
  return { ok: true, message: `Rewrote ${patch.file}. Rebuild to run the new code.` };
}

export async function revertPatch(id: string) {
  await db.update(patches).set({ status: "reverted" }).where(eq(patches.id, id));
}

export async function history() {
  const [runs, rows] = await Promise.all([
    db.select().from(agentRuns).orderBy(desc(agentRuns.createdAt)).limit(12),
    db.select().from(patches).orderBy(desc(patches.createdAt)).limit(40),
  ]);
  return { runs, patches: rows };
}

/** Runs itself daily: analysis on schedule, not only on demand. */
export async function dailyCycle(): Promise<{ ran: boolean; report: string }> {
  const runs = await db.select().from(agentRuns).orderBy(desc(agentRuns.createdAt)).limit(1);
  const last = runs[0] ? new Date(runs[0].createdAt).getTime() : 0;
  if (Date.now() - last < 24 * 60 * 60_000) {
    return { ran: false, report: runs[0]?.report ?? "No cycle run yet." };
  }
  const result = await runUpgrade();
  return { ran: true, report: result.report };
}
