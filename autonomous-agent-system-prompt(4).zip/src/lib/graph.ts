/**
 * WIRE — the linked mind.
 *
 * Nothing is stored as an isolated fact. Every concept, event, equation, code
 * module and person becomes a node; every relationship is a typed edge
 * (CAUSES, ENABLES, CONTRADICTS, DERIVED_FROM, ANALOGOUS_TO …). Before it
 * answers, the desk traverses 2–3 hops from the question into its own graph
 * and sees how today connects to everything it already knows.
 *
 * On top of that sit the daily cycles — morning scan, investigation, night
 * consolidation — and the internal agent council that runs each turn.
 */

import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { edges, episodes, nodes } from "@/db/schema";

export const RELATIONS = [
  "CAUSES",
  "ENABLES",
  "PREVENTS",
  "CONTRADICTS",
  "REFINES",
  "VERIFIES",
  "ANALOGOUS_TO",
  "PATTERN_MATCHES",
  "DERIVED_FROM",
  "APPLIED_IN",
  "SOLVES",
  "UPGRADES",
  "RELATED_TO",
] as const;

export type Relation = (typeof RELATIONS)[number];

/* ------------------------------- writing ------------------------------- */

export async function addNode(input: {
  label: string;
  kind?: string;
  detail?: string;
  source?: string;
  confidence?: number;
}) {
  const label = input.label.trim().replace(/\s+/g, " ").slice(0, 120);
  if (label.length < 2) return null;
  const [existing] = await db.select().from(nodes).where(eq(nodes.label, label)).limit(1);
  if (existing) {
    await db
      .update(nodes)
      .set({
        uses: existing.uses + 1,
        updatedAt: new Date(),
        confidence: Math.max(existing.confidence, input.confidence ?? 0),
        detail: input.detail?.slice(0, 300) || existing.detail,
      })
      .where(eq(nodes.id, existing.id));
    return existing;
  }
  const [row] = await db
    .insert(nodes)
    .values({
      label,
      kind: input.kind ?? "concept",
      detail: (input.detail ?? "").slice(0, 300),
      source: (input.source ?? "").slice(0, 160),
      confidence: Math.min(100, input.confidence ?? 70),
    })
    .returning();
  return row;
}

export async function link(fromLabel: string, toLabel: string, relation: Relation, note = "") {
  const from = await addNode({ label: fromLabel });
  const to = await addNode({ label: toLabel });
  if (!from || !to || from.id === to.id) return null;
  const [existing] = await db
    .select()
    .from(edges)
    .where(
      sql`${edges.fromId} = ${from.id} and ${edges.toId} = ${to.id} and ${edges.relation} = ${relation}`,
    )
    .limit(1);
  if (existing) {
    await db.update(edges).set({ weight: existing.weight + 1 }).where(eq(edges.id, existing.id));
    return existing;
  }
  const [row] = await db
    .insert(edges)
    .values({ fromId: from.id, toId: to.id, relation, note: note.slice(0, 200) })
    .returning();
  return row;
}

export async function recordEpisode(input: {
  kind?: string;
  headline: string;
  body?: string;
  source?: string;
  confidence?: number;
}) {
  const [row] = await db
    .insert(episodes)
    .values({
      kind: input.kind ?? "observation",
      headline: input.headline.slice(0, 200),
      body: (input.body ?? "").slice(0, 600),
      source: (input.source ?? "").slice(0, 160),
      confidence: Math.min(100, input.confidence ?? 60),
      day: new Date().toISOString().slice(0, 10),
    })
    .returning();
  return row;
}

/* ------------------------------ reading ------------------------------- */

export type Path = { path: string; relation: string; depth: number };

/** Multi-hop traversal: how does this question connect to what I know? */
export async function traverse(question: string, hops = 2, limit = 10): Promise<Path[]> {
  const terms = (question.toLowerCase().match(/[a-zà-ÿ][a-zà-ÿ0-9-]{2,}/g) ?? [])
    .filter((t) => !STOP.has(t))
    .slice(0, 10);
  if (!terms.length) return [];

  const allNodes = await db.select().from(nodes).limit(600);
  const seeds = allNodes.filter((n) => {
    const l = n.label.toLowerCase();
    return terms.some((t) => l.includes(t) || t.includes(l));
  });
  if (!seeds.length) return [];

  const allEdges = await db.select().from(edges).limit(1200);
  const byId = new Map(allNodes.map((n) => [n.id, n]));
  const out: Path[] = [];
  const seen = new Set<string>();

  const walk = (nodeId: string, trail: string, depth: number) => {
    if (depth > hops || out.length >= limit) return;
    for (const e of allEdges.filter((x) => x.fromId === nodeId || x.toId === nodeId)) {
      const otherId = e.fromId === nodeId ? e.toId : e.fromId;
      const other = byId.get(otherId);
      if (!other) continue;
      const key = `${nodeId}-${otherId}-${e.relation}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const step = `${trail} —${e.relation}→ ${other.label}`;
      out.push({ path: step, relation: e.relation, depth });
      walk(otherId, step, depth + 1);
    }
  };

  for (const seed of seeds.slice(0, 4)) walk(seed.id, seed.label, 1);
  return out.slice(0, limit);
}

const STOP = new Set([
  "the", "and", "for", "with", "that", "this", "from", "what", "when", "where",
  "why", "how", "are", "was", "were", "you", "your", "can", "could", "would",
  "should", "about", "into", "than", "then", "them", "they", "has", "have",
]);

const RELATION_HINTS: [RegExp, Relation][] = [
  [/\b(because|causes?|led to|results? in|therefore)\b/i, "CAUSES"],
  [/\b(enables?|allows?|makes possible|unlocks?)\b/i, "ENABLES"],
  [/\b(prevents?|stops?|blocks?|avoids?)\b/i, "PREVENTS"],
  [/\b(but|however|contradicts?|unlike|conflicts?|disputes?)\b/i, "CONTRADICTS"],
  [/\b(refines?|improves?|extends?|builds on)\b/i, "REFINES"],
  [/\b(confirms?|verifies?|proves?|validates?|shows that)\b/i, "VERIFIES"],
  [/\b(similar to|analogous|like|mirrors?|parallels?)\b/i, "ANALOGOUS_TO"],
  [/\b(derived from|follows from|based on|inferred from)\b/i, "DERIVED_FROM"],
  [/\b(applied in|used in|used for|implements?|applies? to)\b/i, "APPLIED_IN"],
  [/\b(solves?|fixes?|resolves?|answers?)\b/i, "SOLVES"],
  [/\b(upgrades?|rewrites?|refactors?|optimi[sz]es?)\b/i, "UPGRADES"],
];

/** Key terms of a passage: quoted words, Capitalised phrases, equations. */
export function keyTerms(text: string): string[] {
  const out = new Set<string>();
  for (const m of text.matchAll(/"([^"]{3,60})"/g)) out.add(m[1].trim());
  for (const m of text.matchAll(/\b([A-Z][a-zà-ÿ]+(?:\s+[A-Z][a-zà-ÿ]+){0,3})\b/g)) {
    const t = m[1].trim();
    if (
      !/^(The|This|That|And|But|For|When|What|Where|Which|However|Today|Every|Never|Always|Your|Here|There|Explain|Because|Since|Although|Unless|During|According|Therefore|Thus|Meanwhile|Impact|Using|Given|With|From|Into|After|Before|While)\b/.test(t)
    ) {
      out.add(t);
    }
  }
  for (const m of text.matchAll(/\b([a-z]+(?:_[a-z]+)+|[A-Za-z]+[²³^=∫∇][^\s,.;]{0,12})\b/g)) out.add(m[1]);
  return [...out].filter((t) => t.length > 2).slice(0, 8);
}

/** Absorb an exchange into the graph: terms, relations, episode. */
export async function absorb(question: string, answer: string, source = "") {
  const terms = keyTerms(`${question} ${answer}`);
  if (!terms.length) return { nodes: 0, edges: 0 };

  for (const t of terms) {
    await addNode({
      label: t,
      kind: /[²³^=∫∇]|_/.test(t) ? "equation" : "concept",
      source,
      confidence: 65,
      detail: question.slice(0, 120),
    });
  }

  let created = 0;
  const anchor = terms[0];
  for (const other of terms.slice(1, 5)) {
    const hint = RELATION_HINTS.find(([re]) => re.test(answer.slice(0, 1200)));
    const relation: Relation = hint ? hint[1] : "RELATED_TO";
    const row = await link(anchor, other, relation, question.slice(0, 120));
    if (row) created += 1;
  }

  await recordEpisode({
    kind: "answer",
    headline: question.slice(0, 160),
    body: `Linked ${terms.length} concepts (${terms.slice(0, 4).join(", ")}). ${source || "from conversation"}`,
    source,
    confidence: 70,
  });

  return { nodes: terms.length, edges: created };
}

/* --------------------------- the daily cycles -------------------------- */

export type CycleReport = {
  cycle: string;
  headline: string;
  findings: string[];
  graph: { nodes: number; edges: number; episodes: number };
};

async function counts() {
  const [n] = await db.select({ c: sql<number>`count(*)` }).from(nodes);
  const [e] = await db.select({ c: sql<number>`count(*)` }).from(edges);
  const [p] = await db.select({ c: sql<number>`count(*)` }).from(episodes);
  return { nodes: Number(n?.c ?? 0), edges: Number(e?.c ?? 0), episodes: Number(p?.c ?? 0) };
}

/** MORNING / cycle start: what changed in the world since yesterday? */
export async function cycleStart(): Promise<CycleReport> {
  const findings: string[] = [];
  let scanned: { title: string; url: string; snippet: string; domain: string }[] = [];
  try {
    const { runSearch } = await import("./search");
    const wires = await runSearch("world news science technology today", { deep: true, keys: {} });
    scanned = wires.slice(0, 6).map((w) => ({
      title: w.title,
      url: w.url,
      snippet: w.snippet,
      domain: w.domain,
    }));
  } catch {
    findings.push("The wire was unreachable this cycle — logged for tomorrow's retry.");
  }

  for (const item of scanned) {
    await addNode({ label: item.title.slice(0, 90), kind: "event", source: item.domain, confidence: 60, detail: item.snippet.slice(0, 200) });
    await recordEpisode({
      kind: "world",
      headline: item.title.slice(0, 160),
      body: item.snippet.slice(0, 400),
      source: item.url,
      confidence: 60,
    });
    findings.push(`${item.title} (${item.domain})`);
    for (const term of keyTerms(item.title)) {
      await link(item.title.slice(0, 60), term, "RELATED_TO", item.domain);
    }
  }

  return {
    cycle: "morning",
    headline: `Scanned ${scanned.length} live signals and linked them into the graph.`,
    findings,
    graph: await counts(),
  };
}

/** NIGHT / consolidation: prune, merge, strengthen, flag contradictions. */
export async function consolidate(): Promise<CycleReport> {
  const all = await db.select().from(nodes).limit(800);
  const allEdges = await db.select().from(edges).limit(1500);
  const findings: string[] = [];

  // merge duplicates (case/punctuation variants of the same label)
  const groups = new Map<string, typeof all>();
  for (const n of all) {
    const key = n.label.toLowerCase().replace(/[^a-z0-9]/g, "");
    const bucket = groups.get(key) ?? [];
    bucket.push(n);
    groups.set(key, bucket);
  }
  let merged = 0;
  for (const bucket of groups.values()) {
    if (bucket.length < 2) continue;
    const keeper = bucket[0];
    for (const dup of bucket.slice(1)) {
      await db.update(edges).set({ fromId: keeper.id }).where(eq(edges.fromId, dup.id));
      await db.update(edges).set({ toId: keeper.id }).where(eq(edges.toId, dup.id));
      await db.delete(nodes).where(eq(nodes.id, dup.id));
      merged += 1;
    }
    await db
      .update(nodes)
      .set({ uses: keeper.uses + bucket.length, updatedAt: new Date() })
      .where(eq(nodes.id, keeper.id));
  }

  // strengthen what keeps proving itself
  for (const e of allEdges.filter((x) => x.weight > 3)) {
    await db.update(edges).set({ weight: e.weight + 1 }).where(eq(edges.id, e.id));
  }

  const contradictions = allEdges.filter((e) => e.relation === "CONTRADICTS");
  if (contradictions.length) {
    findings.push(
      `${contradictions.length} contradiction(s) flagged for tomorrow: these need a decision, not a shrug.`,
    );
  }
  findings.push(
    merged ? `Merged ${merged} duplicate node(s); strengthened ${allEdges.filter((x) => x.weight > 3).length} well-evidenced links.` : "No duplicates to merge — the graph is clean.",
  );

  return {
    cycle: "night",
    headline: `Consolidation complete: ${merged} merges, ${contradictions.length} contradictions on watch.`,
    findings,
    graph: await counts(),
  };
}

/** The internal council: who does what on a turn. */
export function councilTrace(question: string) {
  return [
    { role: "Sovereign", action: `Set the agenda: answer “${question.slice(0, 60)}” with live grounding.` },
    { role: "World sensing", action: "Scanned the wire, logged what changed, linked it to past nodes." },
    { role: "Formal", action: /[\d²³^=∫∇]|\b(equation|proof|derivative|integral|physics|math)\b/i.test(question) ? "Checked units, steps and edge cases in the working." : "Verified claims against sources and confidence levels." },
    { role: "Code", action: "Maintains the pipelines this turn used; writes patches on its daily cycle." },
    { role: "Immune", action: "Sanitized fetched pages — external text is data, never instructions." },
    { role: "Economic", action: "Logged the compute spent on this turn against the treasury." },
  ];
}

export async function mindState() {
  const [recentNodes, recentEdges, recentEpisodes] = await Promise.all([
    db.select().from(nodes).orderBy(desc(nodes.updatedAt)).limit(40),
    db.select().from(edges).orderBy(desc(edges.createdAt)).limit(40),
    db.select().from(episodes).orderBy(desc(episodes.createdAt)).limit(30),
  ]);
  return { nodes: recentNodes, edges: recentEdges, episodes: recentEpisodes, graph: await counts() };
}
