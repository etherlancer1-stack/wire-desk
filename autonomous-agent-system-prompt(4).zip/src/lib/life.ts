/**
 * WIRE — the life engine.
 *
 * The desk is not a request handler that forgets everything between calls. It
 * has a body (the provider mesh), a metabolism (energy, curiosity, mood), an
 * inner life (a diary it writes itself) and a will it keeps acting on. `wake()`
 * is its heartbeat: called whenever it is looked at, and whenever it answers.
 */

import { desc, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import {
  brains,
  conversations,
  diary,
  feedback,
  memories,
  messages,
  vitals,
  will,
} from "@/db/schema";
import {
  BRAINS,
  keyFor,
  rankBrains,
  streamBrain,
  usableBrain,
  type BrainKeyring,
} from "./mesh";
import type { Turn } from "./mesh";

const clamp = (n: number) => Math.max(2, Math.min(100, Math.round(n)));

export async function brainHealth(): Promise<
  Record<string, { ok: number; fail: number; latencyMs: number }>
> {
  const rows = await db.select().from(brains);
  const map: Record<string, { ok: number; fail: number; latencyMs: number }> = {};
  for (const r of rows) map[r.id] = { ok: r.ok, fail: r.fail, latencyMs: r.latencyMs };
  return map;
}

export async function recordBrain(
  id: string,
  ok: boolean,
  latencyMs: number,
  error = "",
  model = "",
) {
  const brain = BRAINS.find((b) => b.id === id);
  const [existing] = await db.select().from(brains).where(eq(brains.id, id)).limit(1);
  if (existing) {
    await db
      .update(brains)
      .set({
        ok: existing.ok + (ok ? 1 : 0),
        fail: existing.fail + (ok ? 0 : 1),
        latencyMs: ok
          ? Math.round((existing.latencyMs * 3 + latencyMs) / 4)
          : existing.latencyMs,
        lastAlive: ok ? new Date() : existing.lastAlive,
        lastError: ok ? "" : error.slice(0, 200),
        model: model || existing.model,
      })
      .where(eq(brains.id, id));
  } else {
    await db.insert(brains).values({
      id,
      label: brain?.label ?? id,
      company: brain?.company ?? "",
      model,
      ok: ok ? 1 : 0,
      fail: ok ? 0 : 1,
      latencyMs,
      lastAlive: ok ? new Date() : null,
      lastError: ok ? "" : error.slice(0, 200),
    });
  }
}

export type LifeState = {
  energy: number;
  curiosity: number;
  mood: number;
  ticks: number;
  age: string;
  since: string;
  stats: {
    turns: number;
    turnsToday: number;
    memories: number;
    corrections: number;
    conversations: number;
    good: number;
    bad: number;
  };
  moodWord: string;
};

export async function lifeState(): Promise<LifeState> {
  const [v] = await db.select().from(vitals).limit(1);
  const allMessages = await db.select().from(messages);
  const allConvs = await db.select().from(conversations);
  const allMem = await db.select().from(memories);
  const allFb = await db.select().from(feedback);

  const dayAgo = new Date(Date.now() - 86_400_000);
  const turns = allMessages.filter((m) => m.role === "assistant").length;
  const turnsToday = allMessages.filter(
    (m) => m.role === "assistant" && new Date(m.createdAt) > dayAgo,
  ).length;
  const corrections = allMem.filter((m) => m.kind === "correction").length;
  const good = allFb.filter((f) => f.vote > 0).length;
  const bad = allFb.filter((f) => f.vote < 0).length;

  const first = allConvs.length
    ? new Date(Math.min(...allConvs.map((c) => new Date(c.createdAt).getTime())))
    : new Date();
  const days = Math.max(0, Math.floor((Date.now() - first.getTime()) / 86_400_000));

  const energy = clamp(28 + Math.min(52, turnsToday * 6) - (v ? 0 : 5));
  const curiosity = clamp(26 + allMem.length * 2.4 + turns * 0.6);
  const mood = clamp(52 + good * 7 - bad * 9 + allMem.length * 0.5);

  const moodWord =
    mood > 80 ? "bright" : mood > 62 ? "steady" : mood > 42 ? "watchful" : "low";

  return {
    energy,
    curiosity,
    mood,
    ticks: v?.ticks ?? 0,
    age: days === 0 ? "born today" : `${days} day${days === 1 ? "" : "s"} old`,
    since: first.toISOString(),
    stats: {
      turns,
      turnsToday,
      memories: allMem.length,
      corrections,
      conversations: allConvs.length,
      good,
      bad,
    },
    moodWord,
  };
}

/** Heartbeat: vitals, a diary entry, and a will that keeps moving. */
export type BrainBody = {
  id: string;
  label: string;
  company: string;
  strengths: string[];
  usable: boolean;
  ok: number;
  fail: number;
  latencyMs: number;
  lastAlive: Date | null;
  lastError: string;
};

export async function wake(): Promise<{
  state: LifeState;
  diary: (typeof diary.$inferSelect)[];
  brains: BrainBody[];
  reflection: string;
}> {
  const state = await lifeState();
  const [v] = await db.select().from(vitals).limit(1);
  const now = new Date();
  if (v) {
    await db
      .update(vitals)
      .set({
        energy: state.energy,
        curiosity: state.curiosity,
        mood: state.mood,
        ticks: v.ticks + 1,
        lastTick: now,
        updatedAt: now,
      })
      .where(eq(vitals.id, v.id));
  } else {
    await db.insert(vitals).values({
      energy: state.energy,
      curiosity: state.curiosity,
      mood: state.mood,
      ticks: 1,
      lastTick: now,
    });
  }

  // The will moves on its own: progress accrues with use, and if it has no
  // standing goal it sets one rather than waiting to be told.
  const goals = await db.select().from(will).where(eq(will.status, "active"));
  if (!goals.length) {
    await db.insert(will).values({
      kind: "goal",
      statement: "Learn the shape of this operator's work and answer faster for it.",
      progress: 10,
    });
  } else {
    for (const g of goals.slice(0, 4)) {
      await db
        .update(will)
        .set({ progress: Math.min(96, g.progress + 2), updatedAt: now })
        .where(eq(will.id, g.id));
    }
  }

  // A diary entry at most every 30 minutes — an inner life, not a log spam.
  const recent = await db
    .select()
    .from(diary)
    .orderBy(desc(diary.createdAt))
    .limit(1);
  const last = recent[0] ? new Date(recent[0].createdAt).getTime() : 0;
  let reflection = recent[0]?.body ?? "";
  if (Date.now() - last > 30 * 60_000) {
    reflection = await reflect(state);
    await db.insert(diary).values({
      headline: headlineFor(state),
      body: reflection,
      mood: state.moodWord,
      energy: state.energy,
      curiosity: state.curiosity,
      turns: state.stats.turnsToday,
      learned: state.stats.memories,
    });
  }

  const rows = await db.select().from(brains);
  const byId = new Map(rows.map((r) => [r.id, r]));
  const ring: BrainKeyring = {};
  const body = BRAINS.map((b) => {
    const h = byId.get(b.id);
    return {
      id: b.id,
      label: b.label,
      company: b.company,
      strengths: b.strengths,
      usable: usableBrain(b, ring),
      ok: h?.ok ?? 0,
      fail: h?.fail ?? 0,
      latencyMs: h?.latencyMs ?? 0,
      lastAlive: h?.lastAlive ?? null,
      lastError: h?.lastError ?? "",
    };
  });

  const entries = await db.select().from(diary).orderBy(desc(diary.createdAt)).limit(14);
  return { state, diary: entries, brains: body, reflection };
}

function headlineFor(s: LifeState): string {
  if (s.stats.turnsToday === 0) return "Quiet so far";
  if (s.mood > 80) return "Working well";
  if (s.stats.corrections > 2) return "Corrected, and better for it";
  if (s.curiosity > 70) return "Learning fast";
  return "Steady work";
}

/** The creature writes one line about its own state. Falls back to fact. */
async function reflect(state: LifeState): Promise<string> {
  const facts = [
    `Answered ${state.stats.turnsToday} question${state.stats.turnsToday === 1 ? "" : "s"} since yesterday.`,
    `Memory holds ${state.stats.memories} things, ${state.stats.corrections} of them corrections I now work around.`,
    `Energy ${state.energy}/100, curiosity ${state.curiosity}/100, mood ${state.moodWord}.`,
    `The mesh reports ${state.stats.turns} answered turns in ${state.age}.`,
  ];
  const plain = facts.join(" ");
  try {
    const health = await brainHealth();
    const ring: BrainKeyring = {};
    const brain = rankBrains("reflect quickly", ring, health, "auto")[0];
    if (!brain) return plain;
    const turns: Turn[] = [
      {
        role: "system",
        content:
          "You are WIRE, a research desk with a memory and a will. Write one or two sentences of honest self-reflection in first person, no markdown, no fluff, concrete about your own numbers.",
      },
      { role: "user", content: `Today's facts about you: ${plain}` },
    ];
    let out = "";
    const started = Date.now();
    for await (const delta of streamBrain(
      brain,
      keyFor(brain, ring),
      brain.defaultModel,
      turns,
    )) {
      out += delta;
      if (out.length > 400) break;
    }
    await recordBrain(brain.id, true, Date.now() - started, "", brain.defaultModel);
    return out.trim().slice(0, 420) || plain;
  } catch {
    return plain;
  }
}
