/**
 * WIRE — the agent.
 *
 * One turn of the desk: wake → remember → route apps → read the live web →
 * answer on whichever brain in the mesh is best for this question and still
 * alive → learn from the exchange → persist. Failures degrade one layer at a
 * time: another brain, then the extractive brief — never a dead end.
 */

import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  commandLog,
  connections,
  conversations,
  memories,
  messages,
  sites,
  sources,
} from "@/db/schema";
import { activeCodex, codexPrompt, evolve } from "./evolve";
import { absorb, councilTrace, traverse } from "./graph";
import { BUILD_RULES, extractHtml, sanitizeSiteHtml, siteSlug, wrapSite } from "./sites";
import { CONNECTORS, routeApps, type AppHit } from "./apps";
import { isCommand, runCommand } from "./commands";
import {
  buildSystemPrompt,
  learnFromExchange,
  persona,
  recall,
  sanitizeExternal,
  sanitizeUser,
  storeLearnings,
  willPower,
  type Learning,
} from "./brain";
import { fetchPageText, type Wire } from "./search";
import { synthesize } from "./llm";
import {
  keyFor,
  rankBrains,
  streamBrain,
  type BrainKeyring,
  type Turn,
} from "./mesh";
import { brainHealth, lifeState, recordBrain } from "./life";

export type AgentEvent = Record<string, unknown>;

export type MeshSettings = {
  brain?: string; // "auto" or a brain id
  ring?: Record<string, string>; // brainId -> api key
  models?: Record<string, string>; // brainId -> model override
  provider?: string; // legacy alias
  apiKey?: string;
  model?: string;
};

export type AgentInput = {
  conversationId?: string | null;
  message: string;
  mode: "ask" | "deep";
  settings?: MeshSettings;
  apps?: string[];
  regenerate?: boolean;
  signal?: AbortSignal;
};

function ringFrom(settings?: MeshSettings): BrainKeyring {
  const ring: BrainKeyring = { ...(settings?.ring ?? {}) };
  if (settings?.apiKey && settings?.provider) ring[settings.provider] = settings.apiKey;
  return ring;
}

const FILLER = new Set([
  "the", "a", "an", "is", "are", "was", "were", "what", "which", "who", "whom",
  "when", "where", "why", "how", "do", "does", "did", "can", "could", "should",
  "would", "will", "i", "you", "me", "my", "your", "it", "this", "that", "and",
  "or", "of", "to", "in", "on", "for", "with", "about", "please", "tell", "give",
  "best", "way", "any", "there", "from", "with", "remember", "note",
]);

/** A question is not a search query. Keep a condensed variant in reserve. */
function queryVariants(question: string): string[] {
  const trimmed = question
    .replace(/^(remember|note that|don't forget|keep in mind)\b[^.!?]*[.!?]?\s*/i, "")
    .trim();
  const words = trimmed
    .replace(/[^\w\s'-]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 && !FILLER.has(w.toLowerCase()));
  const condensed = words.slice(0, 9).join(" ");
  const tail = words.slice(-6).join(" ");
  return [...new Set([trimmed, condensed, tail, question].filter((q) => q.length > 2))];
}

async function enabledApps(override?: string[]): Promise<Map<string, string>> {
  const rows = await db.select().from(connections);
  const map = new Map<string, string>();
  for (const c of rows) if (c.connected) map.set(c.app, c.apiKey ?? "");
  for (const c of CONNECTORS) if (!map.has(c.id)) map.set(c.id, "");
  if (override?.length) {
    for (const key of [...map.keys()]) if (!override.includes(key)) map.delete(key);
  }
  return map;
}

export async function listMemory() {
  return db.select().from(memories).orderBy(desc(memories.updatedAt)).limit(240);
}

export async function* runAgent(input: AgentInput): AsyncGenerator<AgentEvent> {
  const question = sanitizeUser(input.message).trim();
  const mode = input.mode === "deep" ? "deep" : "ask";
  const ring = ringFrom(input.settings);
  const preference = input.settings?.brain ?? "auto";

  /* ------------------------------- thread ------------------------------ */
  let conversationId = input.conversationId ?? null;
  if (conversationId) {
    const [existing] = await db
      .select()
      .from(conversations)
      .where(eq(conversations.id, conversationId))
      .limit(1);
    if (!existing) conversationId = null;
  }
  if (!conversationId) {
    const [created] = await db
      .insert(conversations)
      .values({
        title: question.slice(0, 72) + (question.length > 72 ? "…" : ""),
        mode,
      })
      .returning();
    conversationId = created.id;
  }
  const cid: string = conversationId;
  await db
    .update(conversations)
    .set({ updatedAt: new Date(), mode })
    .where(eq(conversations.id, cid));

  if (!input.regenerate) {
    await db.insert(messages).values({ conversationId: cid, role: "user", content: question });
  }
  const history = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, cid))
    .orderBy(asc(messages.createdAt));
  const priorTurns: Turn[] = history
    .slice(0, -1)
    .slice(-8)
    .map((m) => ({
      role: m.role === "user" ? "user" : "assistant",
      content: sanitizeExternal(m.content),
    }));

  yield { type: "thread", conversationId: cid };

  /* ------------------------------ commands ----------------------------- */
  const wantsImage =
    /\b(generate|draw|make|create|paint|design|render)\b[^.!?]{0,70}\b(image|picture|photo|art|logo|poster|illustration|wallpaper|icon)\b/i.test(
      question,
    );
  const commandInput = wantsImage
    ? `/image ${
        question
          .replace(
            /^(generate|draw|make|create|paint|design|render)\s*(me\s*)?(an?\s*)?(image|picture|photo|art|logo|poster|illustration|wallpaper|icon)?\s*(of|about|for)?\s*/i,
            "",
          )
          .trim() || question
      }`
    : question;

  if (isCommand(question) || wantsImage) {
    const result = await runCommand(commandInput);
    await db.insert(commandLog).values({
      command: result.command,
      input: question.slice(0, 500),
      output: result.output.slice(0, 4000),
      ok: result.ok ? 1 : 0,
    });
    yield { type: "command", command: result.command, ok: result.ok };
    yield { type: "status", stage: "command", message: `Running /${result.command}…` };
    const answer = [`### ${result.title}`, result.output, result.note ? `_${result.note}_` : ""]
      .filter(Boolean)
      .join("\n\n");
    for (const chunk of answer.match(/\S+\s*/g) ?? [answer]) {
      yield { type: "token", text: chunk };
    }
    const [saved] = await db
      .insert(messages)
      .values({
        conversationId: cid,
        role: "assistant",
        content: answer,
        model: `/${result.command}`,
        provider: "command deck",
        searched: 0,
      })
      .returning();
    yield {
      type: "done",
      conversationId: cid,
      messageId: saved.id,
      model: `/${result.command}`,
      provider: "command deck",
      searched: 0,
      learned: 0,
    };
    return;
  }

  /* -------------------------- memory + will ---------------------------- */
  const [mem, personaState, willEntries, life] = await Promise.all([
    recall(question),
    persona(),
    willPower(),
    lifeState(),
  ]);
  yield {
    type: "memory",
    memories: mem.rows.map((m) => ({ kind: m.kind, content: m.content, detail: m.detail })),
    mood: life.moodWord,
    energy: life.energy,
    curiosity: life.curiosity,
  };

  /* ---------------------------- live reading --------------------------- */
  yield { type: "status", stage: "search", message: "Scanning the wire…" };
  const enabled = await enabledApps(input.apps);
  const connectors = routeApps(question, new Set(enabled.keys()), mode === "deep").filter(
    (c) => enabled.has(c.id) && (c.needs === "none" || enabled.get(c.id)),
  );

  const seen = new Set<string>();
  const wires: Wire[] = [];

  // A link pasted into the question is the source of record: read it first.
  const pasted = /https?:\/\/[^\s)»"'<>]+/i.exec(question)?.[0];
  if (pasted) {
    try {
      const host = new URL(pasted).hostname.replace(/^www\./, "");
      const text = await fetchPageText(pasted);
      wires.push({
        idx: 1,
        title: `The page you linked — ${host}`,
        url: pasted,
        domain: host,
        snippet: text.slice(0, 320),
        origin: "your link",
        published: null,
        text,
      });
      seen.add(pasted.replace(/[#?].*$/, "").replace(/\/$/, ""));
    } catch {
      /* the link may be unreachable */
    }
  }

  const addHits = (hits: AppHit[], label: string) => {
    for (const h of hits) {
      if (!/^https?:\/\//.test(h.url)) continue;
      const key = h.url.replace(/[#?].*$/, "").replace(/\/$/, "");
      if (seen.has(key)) continue;
      seen.add(key);
      wires.push({ ...h, origin: `${label} · ${h.origin}`, idx: wires.length + 1 });
      if (wires.length >= 16) return;
    }
  };

  // Questions that stand alone — algebra, calculus, code to write — do not
  // need the web, and making them wait for it would be pure latency.
  const fastPath =
    mode !== "deep" &&
    (/\b(solve for|solve the|differentiate|integrate|simplify|expand|factorise|factor|prove that|derivative of|integral of|limit of|taylor|eigenvalue|write (a|me|the|some)|implement (a|an|the)|refactor|debug (this|the) (code|function)|convert .* to .*)\b/i.test(
      question,
    ) ||
      /^[^?]{0,80}[=≈][^?]{0,80}$/.test(question.trim()) ||
      /\b(calculate|compute|how much is|what is|whats|what's)\b[^?]{0,60}[\d][^?]{0,60}[\+\-\*\/×÷^%]/i.test(
        question,
      ) ||
      /\d\s*[\+\-\*\/×÷^%]\s*\d/.test(question));

  // Every connector and every phrasing runs at once — one round, not four.
  const variants = fastPath ? [] : queryVariants(question).slice(0, 2);
  const rounds = await Promise.all(
    variants.map((variant) =>
      Promise.all(
        connectors.map(async (c) => {
          try {
            return await c.run(variant, enabled.get(c.id) ?? "");
          } catch {
            return [] as AppHit[];
          }
        }),
      ),
    ),
  );
  rounds.forEach((batch) =>
    batch.forEach((hits, i) => addHits(hits, connectors[i]?.label ?? "web")),
  );

  const readCount = fastPath ? 0 : mode === "deep" ? 5 : 2;
  await Promise.all(
    wires.slice(0, readCount).map(async (w) => {
      try {
        w.text = sanitizeExternal(await fetchPageText(w.url));
      } catch {
        /* snippet only */
      }
    }),
  );

  for (const row of await db.select().from(connections)) {
    if (connectors.some((c) => c.id === row.app)) {
      await db
        .update(connections)
        .set({ hits: row.hits + 1, lastUsedAt: new Date() })
        .where(eq(connections.id, row.id));
    }
  }

  yield {
    type: "sources",
    sources: wires.map((w) => ({
      idx: w.idx,
      title: w.title,
      url: w.url,
      domain: w.domain,
      snippet: w.snippet,
      origin: w.origin,
      published: w.published,
      read: Boolean(w.text),
    })),
    apps: connectors.map((c) => c.label),
  };

  /* ------------------------------- answer ------------------------------ */
  const context = wires
    .map((w) => {
      const excerpt = sanitizeExternal((w.text ?? w.snippet ?? "").slice(0, 2600));
      return `[${w.idx}] ${w.title}\nURL: ${w.url}\nSource: ${w.domain} · ${w.origin}\n${excerpt}`;
    })
    .join("\n\n---\n\n");

  const links = await traverse(question).catch(() => []);
  const mindLine = links.length
    ? `\n\nHOW THIS CONNECTS TO WHAT YOU ALREADY KNOW (traversed 2 hops through your own graph):\n${links
        .map((l) => `• ${l.path}`)
        .join("\n")}`
    : "";

  const turns: Turn[] = [
    {
      role: "system",
      content:
        buildSystemPrompt({
          memories: mem.rows,
          willEntries,
          persona: personaState,
          date: new Date().toISOString().slice(0, 10),
          mode,
          appLine: connectors.map((c) => c.label).join(", ") || "none",
          codexLine: codexPrompt(await activeCodex()),
          buildRules: BUILD_RULES,
        }) +
        "\n\n=== LIVE WEB CONTEXT ===\n" +
        (context || "(the wire returned nothing for this question)") +
        "\n=== END CONTEXT ===" +
        mindLine,
    },
    ...priorTurns,
    { role: "user", content: question },
  ];

  const health = await brainHealth();
  const ranked = rankBrains(question, ring, health, preference);
  yield {
    type: "mesh",
    brains: ranked.slice(0, 6).map((b) => ({ id: b.id, label: b.label, company: b.company })),
  };

  let answer = "";
  let providerLabel = "";
  let providerId = "mesh";

  for (const brain of ranked.slice(0, 6)) {
    const model = input.settings?.models?.[brain.id] || brain.defaultModel;
    yield {
      type: "status",
      stage: "answer",
      message: `Thinking on ${brain.label} · ${model}…`,
    };
    const started = Date.now();
    let got = "";
    try {
      for await (const delta of streamBrain(
        brain,
        keyFor(brain, ring),
        model,
        turns,
        input.signal,
      )) {
        if (!providerLabel) {
          providerLabel = `${brain.label} · ${model}`;
          providerId = brain.id;
          yield {
            type: "brain",
            brain: brain.label,
            company: brain.company,
            model,
          };
        }
        got += delta;
        answer += delta;
        yield { type: "token", text: delta };
      }
    } catch (err) {
      await recordBrain(
        brain.id,
        false,
        Date.now() - started,
        err instanceof Error ? err.message : "failed",
        model,
      );
      if (got.trim()) break; // partial answer beats a restart
      answer = "";
      continue;
    }
    await recordBrain(brain.id, true, Date.now() - started, "", model);
    if (got.trim()) break;
    answer = "";
  }

  // A thin answer is a failed answer. If the first pass came back with a shrug
  // or a bare number, push the same mind once more for the real thing.
  if (answer.trim().length > 0 && answer.trim().length < 70) {
    const brain = ranked[0];
    if (brain) {
      const strict: Turn[] = [
        ...turns,
        { role: "assistant", content: answer.trim() },
        {
          role: "user",
          content:
            "That reply is too thin. Answer again properly: show the working or the reasoning in one or two lines, then the result in bold, then one line of context. At least three sentences — never just the answer.",
        },
      ];
      try {
        let extra = "";
        for await (const delta of streamBrain(
          brain,
          keyFor(brain, ring),
          input.settings?.models?.[brain.id] || brain.defaultModel,
          strict,
          input.signal,
        )) {
          extra += delta;
          yield { type: "token", text: delta };
        }
        if (extra.trim().length > answer.trim().length) answer = extra;
      } catch {
        /* keep the first answer rather than lose the turn */
      }
    }
  }

  if (!answer.trim()) {
    providerLabel = "extractive brief";
    providerId = "wire";
    yield {
      type: "status",
      stage: "fallback",
      message: "Every brain declined — assembling the extractive brief…",
    };
    const brief = wires.length
      ? synthesize(question, wires)
      : `### What I can tell you\n\nThe wire returned nothing and every brain in the mesh declined, so here is my own position rather than a shrug:\n\n- Re-ask with sharper phrasing — names, dates, places — and I will re-scan.\n- Or add a brain key in **Settings** (Claude, GPT, Gemini, Groq…) so I can answer directly.\n\n> ${question}`;
    for (const chunk of brief.match(/\S+\s*/g) ?? [brief]) {
      answer += chunk;
      yield { type: "token", text: chunk };
    }
  }

  /* ------------------------------ make images ----------------------------- */
  if (false) {
    // Image requests are answered by the command deck before the wire is
    // scanned; this branch only guards a future media pipeline.
    const prompt =
      question
        .replace(/^(generate|draw|make|create|paint|design|render)\s*(me\s*)?(an?\s*)?(image|picture|photo|art|logo|poster|illustration|wallpaper|icon)?\s*(of|about|for)?\s*/i, "")
        .trim() || question;
    const seed = Math.floor(Math.random() * 1e6);
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=576&nologo=true&seed=${seed}`;
    const answer = `### Generated image\n\n![${prompt.slice(0, 80)}](${url})\n\n**Prompt:** ${prompt}\n\nRendered live at 1024×576. Ask for another style, mood, aspect or subject and I will redraw it — or ask me to build it into a website or game.`;
    for (const chunk of answer.match(/\S+\s*/g) ?? [answer]) {
      yield { type: "token", text: chunk };
    }
    const [saved] = await db
      .insert(messages)
      .values({
        conversationId: cid,
        role: "assistant",
        content: answer,
        model: "image engine",
        provider: "wire media",
        searched: 0,
      })
      .returning();
    yield {
      type: "done",
      conversationId: cid,
      messageId: saved.id,
      model: "image engine",
      provider: "wire media",
      searched: 0,
      learned: 0,
    };
    return;
  }

  /* --------------------- build: ship it as a private site -------------------- */
  let siteInfo: { slug: string; url: string; title: string } | null = null;
  const builtHtml = extractHtml(answer);
  if (builtHtml) {
    const title =
      question
        .replace(/^(build|create|make|design)\s+(me\s+)?(a|an|the)?\s*/i, "")
        .split(/[.?!]/)[0]
        .trim()
        .slice(0, 60) || "Private build";
    const slug = siteSlug();
    const html = wrapSite(sanitizeSiteHtml(builtHtml), title);
    await db.insert(sites).values({
      slug,
      title,
      prompt: question.slice(0, 400),
      html,
      bytes: html.length,
    });
    siteInfo = { slug, url: `/s/${slug}`, title };
    // The code is the deliverable, not the conversation: keep the prose, hand
    // over the link.
    const prose = answer.replace(/```(?:html|HTML)?\s*\n[\s\S]*?```/g, "").trim();
    answer =
      (prose || `### ${title}`) +
      `\n\n---\n\n**Built it and published it privately:** [${title}](/s/${slug}) — only this link opens it, and it is listed nowhere.\n\n\`/s/${slug}\``;
    yield { type: "site", ...siteInfo };
  }

  /* -------------------------- learn + persist -------------------------- */
  // Learn from everything: what you say, what it answered, and the pages it
  // actually read — one durable fact per page, attributed to its source.
  const harvested = wires
    .filter((w) => (w.text ?? "").length > 240)
    .slice(0, 2)
    .map((w) => {
      const sentence = (w.text ?? "")
        .split(/(?<=[.!?])\s+/)
        .find((s) => s.length > 70 && s.length < 190 && /[a-z]/.test(s));
      return sentence
        ? {
            kind: "knowledge",
            content: sentence.trim(),
            detail: `read on ${w.domain}`,
          }
        : null;
    })
    .filter(Boolean) as Learning[];
  const learnings = [...learnFromExchange(question, answer), ...harvested];
  await storeLearnings(learnings);

  // One-to-another: every exchange becomes nodes, typed edges and an episode.
  const graphAbsorbed = await absorb(question, answer, wires[0]?.domain ?? "").catch(
    () => ({ nodes: 0, edges: 0 }),
  );
  yield {
    type: "trace",
    roles: councilTrace(question),
    graph: graphAbsorbed,
    linked: links.length,
  };
  yield {
    type: "learn",
    learned: learnings.length,
    items: learnings.map((l) => ({ kind: l.kind, content: l.content })),
  };

  // Self-rewrite: every dozen turns the desk audits itself and rewrites its
  // own operating rules from the evidence of what worked.
  if (life.stats.turns > 0 && (life.stats.turns + 1) % 12 === 0) {
    try {
      const evolution = await evolve();
      yield {
        type: "evolve",
        written: evolution.written.length,
        report: evolution.report,
      };
    } catch {
      /* evolution never breaks a turn */
    }
  }

  const [saved] = await db
    .insert(messages)
    .values({
      conversationId: cid,
      role: "assistant",
      content: answer,
      model: providerLabel,
      provider: providerId,
      searched: wires.length,
    })
    .returning();

  if (wires.length) {
    await db.insert(sources).values(
      wires.map((w) => ({
        conversationId: cid,
        messageId: saved.id,
        idx: w.idx,
        title: w.title,
        url: w.url,
        domain: w.domain,
        snippet: w.snippet,
        origin: w.origin,
        published: w.published,
      })),
    );
  }

  yield {
    type: "done",
    conversationId: cid,
    messageId: saved.id,
    model: providerLabel,
    provider: providerId,
    searched: wires.length,
    learned: learnings.length,
    memory: mem.rows.length,
    mood: life.moodWord,
    energy: life.energy,
  };
}
