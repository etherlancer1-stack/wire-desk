/**
 * WIRE — agent studio.
 *
 * Build other AI agents. Each one is a real, persistent spec: its own role,
 * instructions, model and tool set, stored in the database, runnable from the
 * interface and from chat. The desk is the factory floor — this is where the
 * agents it builds live.
 */

import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { agents } from "@/db/schema";
import { runSearch } from "./search";
import { keyFor, rankBrains, streamBrain, type Turn } from "./mesh";
import { sanitizeExternal, sanitizeUser } from "./brain";

export type AgentSpec = typeof agents.$inferSelect;

export async function listAgents(): Promise<AgentSpec[]> {
  return db.select().from(agents).orderBy(desc(agents.updatedAt)).limit(50);
}

export async function saveAgent(input: {
  id?: string;
  name: string;
  role: string;
  instructions: string;
  model: string;
  tools: string;
}) {
  const values = {
    name: input.name.trim().slice(0, 80) || "Untitled agent",
    role: input.role.trim().slice(0, 60) || "assistant",
    instructions: input.instructions.trim().slice(0, 2000),
    model: input.model.trim().slice(0, 60) || "auto",
    tools: input.tools.trim().slice(0, 120) || "web,memory",
    updatedAt: new Date(),
  };
  if (input.id) {
    await db.update(agents).set(values).where(eq(agents.id, input.id));
    const [row] = await db.select().from(agents).where(eq(agents.id, input.id)).limit(1);
    return row;
  }
  const [row] = await db.insert(agents).values(values).returning();
  return row;
}

export async function removeAgent(id: string) {
  await db.delete(agents).where(eq(agents.id, id));
}

/** Run one of your own agents on a message. */
export async function runOwnAgent(
  id: string,
  message: string,
  onToken?: (t: string) => void,
): Promise<{ answer: string; model: string }> {
  const [spec] = await db.select().from(agents).where(eq(agents.id, id)).limit(1);
  if (!spec) throw new Error("No such agent.");

  const question = sanitizeUser(message).trim();
  const usesWeb = /web|search|research/i.test(spec.tools);

  let context = "";
  if (usesWeb) {
    try {
      const wires = await runSearch(question, { deep: false, keys: {} });
      context = wires
        .slice(0, 6)
        .map((w) => `[${w.idx}] ${w.title} — ${w.url}\n${w.snippet}`)
        .join("\n\n");
    } catch {
      context = "";
    }
  }

  const turns: Turn[] = [
    {
      role: "system",
      content: [
        `You are ${spec.name}, a specialist agent created inside the WIRE desk.`,
        `Your role: ${spec.role}.`,
        spec.instructions ? `Your standing instructions:\n${spec.instructions}` : "",
        "Answer with the depth your role implies, in clean markdown. When you use sources, cite them with [n]. Never invent sources. Be direct and concrete.",
        context ? `\n=== LIVE WEB CONTEXT ===\n${sanitizeExternal(context)}\n=== END ===` : "",
      ]
        .filter(Boolean)
        .join("\n\n"),
    },
    { role: "user", content: question },
  ];

  const ring: Record<string, string> = {};
  const ranked = rankBrains(question, ring, {}, spec.model === "auto" ? "auto" : spec.model);
  if (!ranked.length) throw new Error("No model available for this agent.");

  // Try the best minds in order — one dead provider never kills the agent.
  let answer = "";
  let label = "";
  for (const brain of ranked.slice(0, 5)) {
    const model = spec.model !== "auto" ? spec.model : brain.defaultModel;
    let produced = "";
    try {
      for await (const delta of streamBrain(brain, keyFor(brain, ring), model, turns)) {
        produced += delta;
        onToken?.(delta);
      }
    } catch {
      if (produced.trim()) break;
      continue;
    }
    if (produced.trim()) {
      answer = produced;
      label = `${brain.label} · ${model}`;
      break;
    }
    answer = produced;
    label = `${brain.label} · ${model}`;
  }

  if (!answer.trim()) throw new Error("Every model declined this turn.");

  await db
    .update(agents)
    .set({ runs: spec.runs + 1, updatedAt: new Date() })
    .where(eq(agents.id, id));

  return { answer, model: label };
}

/** A starting kit of agents the desk can build for you. */
export const TEMPLATES: { name: string; role: string; instructions: string; tools: string }[] = [
  {
    name: "Research Analyst",
    role: "deep research and synthesis",
    instructions:
      "Investigate questions across primary sources. Compare conflicting claims explicitly, give confidence levels, and end with the three open questions that remain.",
    tools: "web,memory",
  },
  {
    name: "Code Architect",
    role: "software design and review",
    instructions:
      "Design modules before writing them. Show the interface first, then implementation, then tests. Flag breaking changes and missing error handling every time.",
    tools: "web,memory",
  },
  {
    name: "Market Scout",
    role: "commercial opportunities",
    instructions:
      "Find real problems people pay to solve. Estimate effort versus return honestly, name the competitors, and propose one thing worth building this week.",
    tools: "web,memory",
  },
  {
    name: "Tutor",
    role: "teaching and explanation",
    instructions:
      "Explain from first principles with a worked example, then a harder one the learner solves. Check understanding with one question at the end.",
    tools: "memory",
  },
];
