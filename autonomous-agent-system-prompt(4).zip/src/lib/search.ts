/**
 * WIRE — live web search layer.
 *
 * Order of battle:
 *   1. Real search APIs when a key is configured (Tavily / Serper / Brave).
 *   2. Keyless public indexes always run in parallel so the desk is never blind:
 *      DuckDuckGo Instant Answer, Wikipedia, Hacker News (Algolia), Semantic Scholar.
 *   3. Top result pages are fetched and their text extracted so the model reads
 *      the actual pages rather than trusting snippets.
 *
 * Every provider is wrapped so one failure never kills the answer.
 */

export type Wire = {
  idx: number;
  title: string;
  url: string;
  domain: string;
  snippet: string;
  origin: string;
  published: string | null;
  text?: string;
};

export type SearchKeys = {
  tavily?: string;
  serper?: string;
  brave?: string;
};

const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

function host(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "web";
  }
}

function clean(s: string): string {
  return s
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/\s+/g, " ")
    .trim();
}

async function json(url: string, init?: RequestInit): Promise<any> {
  const res = await fetch(url, {
    ...init,
    signal: AbortSignal.timeout(5000),
    headers: {
      "User-Agent": UA,
      Accept: "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!res.ok) throw new Error(`${url.slice(0, 40)} → ${res.status}`);
  return res.json();
}

function raw(
  title: string,
  url: string,
  snippet: string,
  origin: string,
  published: string | null = null,
): Omit<Wire, "idx"> {
  return {
    title: clean(title) || host(url),
    url,
    domain: host(url),
    snippet: clean(snippet).slice(0, 320),
    origin,
    published,
  };
}

/* ----------------------------- providers ----------------------------- */

async function searchTavily(q: string, key: string): Promise<Omit<Wire, "idx">[]> {
  const data = await json("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query: q, max_results: 8, include_raw_content: false }),
  });
  return (data.results ?? []).map((r: any) =>
    raw(r.title, r.url, r.content ?? "", "web", r.published_date ?? null),
  );
}

async function searchSerper(q: string, key: string): Promise<Omit<Wire, "idx">[]> {
  const data = await json("https://google.serper.dev/search", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-API-KEY": key },
    body: JSON.stringify({ q, num: 10 }),
  });
  const organic = (data.organic ?? []).map((r: any) =>
    raw(r.title, r.link, r.snippet ?? "", "web", r.date ?? null),
  );
  const news = (data.news ?? []).map((r: any) =>
    raw(r.title, r.link, r.snippet ?? "", "news", r.date ?? null),
  );
  return [...organic, ...news];
}

async function searchBrave(q: string, key: string): Promise<Omit<Wire, "idx">[]> {
  const data = await json(
    `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(q)}&count=10`,
    { headers: { "X-Subscription-Token": key, Accept: "application/json" } },
  );
  return (data.web?.results ?? []).map((r: any) =>
    raw(r.title, r.url, r.description ?? "", "web", r.age ?? null),
  );
}

/** Independent general-web index (keyless, generous). */
async function searchMarginalia(q: string): Promise<Omit<Wire, "idx">[]> {
  const data = await json(
    `https://api.marginalia.nu/public/search/${encodeURIComponent(q)}`,
  );
  return (data.results ?? []).slice(0, 8).map((r: any) =>
    raw(r.title, r.url, r.description ?? "", "web"),
  );
}

async function searchDuckDuckGo(q: string): Promise<Omit<Wire, "idx">[]> {
  const data = await json(
    `https://api.duckduckgo.com/?q=${encodeURIComponent(q)}&format=json&no_html=1&skip_disambig=1`,
  );
  const out: Omit<Wire, "idx">[] = [];
  if (data.AbstractText && data.AbstractURL) {
    out.push(raw(data.Heading ?? data.AbstractURL, data.AbstractURL, data.AbstractText, "reference"));
  }
  const walk = (items: any[]) => {
    for (const it of items ?? []) {
      if (it.Topics) walk(it.Topics);
      else if (it.FirstURL && it.Text && !/duckduckgo\.com/i.test(it.FirstURL)) {
        const [title, ...rest] = it.Text.split(" - ");
        out.push(raw(title, it.FirstURL, rest.join(" - ") || it.Text, "reference"));
      }
    }
  };
  walk(data.RelatedTopics ?? []);
  return out.slice(0, 8);
}

async function searchWikipedia(q: string): Promise<Omit<Wire, "idx">[]> {
  const data = await json(
    `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
      q,
    )}&srlimit=5&format=json`,
  );
  const hits: any[] = data.query?.search ?? [];
  const out: Omit<Wire, "idx">[] = [];
  await Promise.all(
    hits.slice(0, 3).map(async (h) => {
      try {
        const s = await json(
          `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(h.title)}`,
        );
        out.push(
          raw(
            s.title ?? h.title,
            s.content_urls?.desktop?.page ??
              `https://en.wikipedia.org/wiki/${encodeURIComponent(h.title)}`,
            s.extract ?? clean(h.snippet),
            "reference",
          ),
        );
      } catch {
        out.push(
          raw(
            h.title,
            `https://en.wikipedia.org/wiki/${encodeURIComponent(h.title)}`,
            clean(h.snippet),
            "reference",
          ),
        );
      }
    }),
  );
  return out;
}

async function searchHackerNews(q: string): Promise<Omit<Wire, "idx">[]> {
  const data = await json(
    `https://hn.algolia.com/api/v1/search?query=${encodeURIComponent(q)}&tags=story&hitsPerPage=5`,
  );
  return (data.hits ?? [])
    .filter((h: any) => h.url || h.objectID)
    .map((h: any) =>
      raw(
        h.title ?? "Hacker News thread",
        h.url ?? `https://news.ycombinator.com/item?id=${h.objectID}`,
        `${h.points ?? 0} points · ${h.num_comments ?? 0} comments on Hacker News`,
        "forum",
        h.created_at ?? null,
      ),
    );
}

async function searchScholar(q: string): Promise<Omit<Wire, "idx">[]> {
  const data = await json(
    `https://api.semanticscholar.org/graph/v1/paper/search?query=${encodeURIComponent(
      q,
    )}&limit=4&fields=title,abstract,url,year,authors,externalIds`,
  );
  return (data.data ?? []).map((p: any) =>
    raw(
      p.title,
      p.url ??
        (p.externalIds?.DOI
          ? `https://doi.org/${p.externalIds.DOI}`
          : "https://www.semanticscholar.org"),
      `${p.abstract ?? "Peer-reviewed paper."}`.slice(0, 320),
      "paper",
      p.year ? String(p.year) : null,
    ),
  );
}

async function searchNews(q: string): Promise<Omit<Wire, "idx">[]> {
  const data = await json(
    `https://api.gdeltproject.org/api/v2/doc/doc?query=${encodeURIComponent(
      q,
    )}&mode=ArtList&maxrecords=6&format=json&timespan=1week`,
  );
  return (data.articles ?? []).map((a: any) =>
    raw(a.title, a.url, `${a.domain ?? ""} — coverage from the last 7 days`, "news", a.seendate),
  );
}

/* ------------------------------ pipeline ----------------------------- */

export async function runSearch(
  query: string,
  opts: { deep?: boolean; keys?: SearchKeys } = {},
): Promise<Wire[]> {
  const keys = opts.keys ?? {};
  const tasks: Promise<Omit<Wire, "idx">[]>[] = [];

  if (keys.tavily) tasks.push(searchTavily(query, keys.tavily).catch(() => []));
  if (keys.serper) tasks.push(searchSerper(query, keys.serper).catch(() => []));
  if (keys.brave) tasks.push(searchBrave(query, keys.brave).catch(() => []));

  tasks.push(searchMarginalia(query).catch(() => []));
  tasks.push(searchWikipedia(query).catch(() => []));
  tasks.push(searchDuckDuckGo(query).catch(() => []));
  tasks.push(searchHackerNews(query).catch(() => []));
  if (opts.deep) {
    tasks.push(searchScholar(query).catch(() => []));
    tasks.push(searchNews(query).catch(() => []));
  }

  const batches = await Promise.all(tasks);
  const generalFirst = batches.flat();

  const seen = new Set<string>();
  const out: Wire[] = [];
  for (const item of generalFirst) {
    let key: string;
    try {
      const u = new URL(item.url);
      key = u.hostname.replace(/^www\./, "") + u.pathname.replace(/\/$/, "");
    } catch {
      continue;
    }
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ ...item, idx: out.length + 1 });
    if (out.length >= 14) break;
  }
  return out;
}

/** Pull readable text out of a page so the model reads the source, not a snippet. */
export async function fetchPageText(url: string): Promise<string> {
  const res = await fetch(url, {
    signal: AbortSignal.timeout(3500),
    redirect: "follow",
    headers: {
      "User-Agent": UA,
      Accept: "text/html,application/xhtml+xml,application/json",
    },
  });
  if (!res.ok) throw new Error(`fetch ${res.status}`);
  const type = res.headers.get("content-type") ?? "";
  const body = (await res.text()).slice(0, 220_000);
  if (type.includes("json")) return clean(body).slice(0, 6000);
  const stripped = body
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<nav[\s\S]*?<\/nav>/gi, " ")
    .replace(/<footer[\s\S]*?<\/footer>/gi, " ")
    .replace(/<svg[\s\S]*?<\/svg>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
    .replace(/<\/(p|div|li|h1|h2|h3|h4|tr|br)>/gi, "\n")
    .replace(/<[^>]+>/g, " ");
  return clean(stripped).slice(0, 7000);
}

export async function enrich(wires: Wire[], count: number): Promise<Wire[]> {
  const targets = wires.slice(0, count);
  await Promise.all(
    targets.map(async (w) => {
      try {
        w.text = await fetchPageText(w.url);
      } catch {
        /* keep snippet only */
      }
    }),
  );
  return wires;
}
