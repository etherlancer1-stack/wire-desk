/**
 * WIRE × OpenJarvis.
 *
 * OpenJarvis (github.com/open-jarvis/OpenJarvis, Apache-2.0, Stanford Hazy
 * Research / SAIL) is a local-first personal AI stack. This module adopts its
 * core architecture inside WIRE:
 *
 *   1. SKILLS — tool capabilities discovered from a catalog and invoked on
 *      demand (agentskills.io open standard), the way `jarvis skill install`
 *      works. Every WIRE command and connector is exposed as a skill.
 *   2. AGENT PRESETS — its five starter presets (morning digest, deep
 *      research, code assistant, scheduled monitor, chat simple) become
 *      one-click agents in the studio, with its execution modes.
 *   3. INTELLIGENCE PER WATT — evaluation that treats energy, latency and
 *      dollar cost as first-class constraints alongside quality.
 *   4. LOCAL-FIRST — prefer an on-device brain (Ollama) when one is present;
 *      call the cloud only when the local model cannot answer.
 *
 * Their Python runtime is not vendored here; WIRE speaks the same architecture
 * and can drive a `jarvis` installation through the connector registry.
 */

export type Skill = {
  id: string;
  name: string;
  category: string;
  source: string;
  about: string;
  invoke: string;
};

/** Skills follow the agentskills.io shape: named, discoverable, invokable. */
export const SKILLS: Skill[] = [
  { id: "wire:web-research", name: "web-research", category: "research", source: "wire", about: "Multi-hop research across the live web with numbered citations.", invoke: "ask any research question" },
  { id: "wire:arxiv", name: "arxiv", category: "research", source: "hermes:arxiv", about: "Search and summarise preprints from arXiv.", invoke: "/gateway arxiv · or ask" },
  { id: "wire:deep-research", name: "deep-research", category: "research", source: "openjarvis", about: "Long-horizon investigation with sources read in full.", invoke: "switch to Deep search" },
  { id: "wire:code-explainer", name: "code-explainer", category: "code", source: "hermes", about: "Explain code line by line, then review it for defects.", invoke: "paste code and ask" },
  { id: "wire:code-architect", name: "code-architect", category: "code", source: "openjarvis", about: "Design modules, interfaces and tests before implementation.", invoke: "Agent studio → Code Architect" },
  { id: "wire:project-reader", name: "project-reader", category: "code", source: "wire", about: "Index and search a project workspace without loading it all.", invoke: "Projects panel / search" },
  { id: "wire:builder", name: "builder", category: "code", source: "wire", about: "Generate complete applications and host them privately.", invoke: "ask for a website or game" },
  { id: "wire:image-gen", name: "image-gen", category: "media", source: "wire", about: "Render images from a description.", invoke: "/image <prompt>" },
  { id: "wire:digest", name: "morning-digest", category: "automation", source: "openjarvis", about: "Daily briefing from the world scan, memory and treasury.", invoke: "/brief · /cycle" },
  { id: "wire:scheduled-monitor", name: "scheduled-monitor", category: "automation", source: "openjarvis", about: "Continuous watching with memory and consolidation.", invoke: "/cycle · /cycle night" },
  { id: "wire:memory", name: "memory", category: "personal", source: "wire", about: "Long-term memory of preferences, corrections and knowledge.", invoke: "automatic every turn" },
  { id: "wire:graph", name: "knowledge-graph", category: "personal", source: "wire", about: "Linked concepts with typed relations and 2-hop traversal.", invoke: "/mind <topic>" },
  { id: "wire:gmail", name: "gmail", category: "connectors", source: "openjarvis:gdrive", about: "Read your own mailbox on request (OAuth token required).", invoke: "connect in the Gateway" },
  { id: "wire:security-scan", name: "security-scan", category: "security", source: "wire", about: "Non-destructive assessment of authorized targets.", invoke: "Security lab" },
  { id: "wire:command-deck", name: "command-deck", category: "tools", source: "wire", about: "Hashing, ciphers, JWT, regex, math, extraction — deterministic.", invoke: "/help" },
];

export type Preset = {
  id: string;
  name: string;
  mode: "on-demand" | "scheduled" | "continuous";
  role: string;
  instructions: string;
  tools: string;
  about: string;
};

/** OpenJarvis starter presets, expressed as WIRE agents. */
export const PRESETS: Preset[] = [
  {
    id: "morning-digest",
    name: "Morning Digest",
    mode: "scheduled",
    role: "daily briefing",
    instructions:
      "Produce a spoken-style daily brief: what changed overnight in the world, what is on the calendar, and what to act on. Lead with the three things that matter. Cite sources.",
    tools: "web,memory",
    about: "OpenJarvis's morning digest: a daily briefing drawn from live sources.",
  },
  {
    id: "deep-research",
    name: "Deep Research",
    mode: "on-demand",
    role: "multi-hop research with citations",
    instructions:
      "Investigate across primary sources in multiple hops. Compare conflicting claims explicitly, give confidence levels, cite every claim to a numbered source, and end with the open questions.",
    tools: "web,memory",
    about: "Multi-hop research over the web and local documents, fully cited.",
  },
  {
    id: "code-assistant",
    name: "Code Assistant",
    mode: "on-demand",
    role: "code execution, files and shell",
    instructions:
      "Work like a senior engineer: inspect before changing, design interfaces first, implement, then test. Report exactly what was changed and what remains broken.",
    tools: "web,memory",
    about: "An agent with file I/O and code execution habits from the OpenJarvis code preset.",
  },
  {
    id: "scheduled-monitor",
    name: "Scheduled Monitor",
    mode: "continuous",
    role: "stateful monitoring with memory",
    instructions:
      "Watch a topic over time. Each run: what changed since last time, what it means, and what to watch next. Keep state between runs; compress old detail, keep decisions.",
    tools: "web,memory",
    about: "Long-horizon monitoring with memory compression and retrieval.",
  },
  {
    id: "chat-simple",
    name: "Chat Simple",
    mode: "on-demand",
    role: "single-turn conversation",
    instructions: "Answer directly and briefly. No tools, no research, no preamble.",
    tools: "memory",
    about: "Lightweight single-turn conversation without tool calls.",
  },
];

/**
 * Intelligence Per Watt: evaluate turns as efficiency, not just accuracy —
 * latency, model cost and network work weighed against usefulness.
 */
export type Efficiency = {
  avgLatencyMs: number;
  fastestBrain: string;
  localShare: number;
  estimatedCostPerTurn: number;
  intelligencePerWatt: number;
  note: string;
};

const COST_PER_1K: Record<string, number> = {
  openai: 0.0015,
  anthropic: 0.003,
  google: 0.0005,
  groq: 0.0002,
  deepseek: 0.0002,
  mistral: 0.002,
  openrouter: 0.0015,
  openwire: 0,
  ollama: 0,
};

export function efficiency(input: {
  brainStats: { id: string; label: string; ok: number; fail: number; latencyMs: number; keyless?: boolean }[];
  turns: number;
}): Efficiency {
  const live = input.brainStats.filter((b) => b.ok > 0);
  const avgLatencyMs = live.length
    ? Math.round(live.reduce((a, b) => a + b.latencyMs, 0) / live.length)
    : 0;
  const fastest = [...live].sort((a, b) => a.latencyMs - b.latencyMs)[0];
  const localShare = live.length
    ? Math.round((live.filter((b) => b.id === "ollama" || b.keyless).length / live.length) * 100)
    : 0;
  const cost = live.length
    ? live.reduce((a, b) => a + (COST_PER_1K[b.id] ?? 0.0015), 0) / live.length
    : 0;
  // Efficiency is usefulness per unit of time and money: higher is better.
  const ipw = avgLatencyMs > 0 ? Number(((1000 / avgLatencyMs) * (1 - Math.min(cost * 40, 0.8))).toFixed(2)) : 0;
  return {
    avgLatencyMs,
    fastestBrain: fastest ? `${fastest.label} (${fastest.latencyMs}ms)` : "—",
    localShare,
    estimatedCostPerTurn: Number(cost.toFixed(5)),
    intelligencePerWatt: ipw,
    note:
      localShare > 40
        ? "Local-first: much of the thinking happens on hardware you control."
        : "Cloud-weighted: add a local model (Ollama) to raise efficiency and privacy.",
  };
}
