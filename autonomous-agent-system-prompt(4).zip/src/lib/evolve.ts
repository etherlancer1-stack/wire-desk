/**
 * WIRE — the evolution engine.
 *
 * The desk rewrites its own operating code. Not the server — its own rules:
 * the standing instructions, heuristics and tunings that decide how it thinks.
 * Every so often it audits what has been working (your verdicts, its memory,
 * how fast and how well it answered) and rewrites those rules, keeping every
 * version so a bad rewrite can be reverted in one click.
 */

import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { codex, feedback, memories, messages, sources } from "@/db/schema";

export type CodexEntry = typeof codex.$inferSelect;

export async function activeCodex(): Promise<CodexEntry[]> {
  const rows = await db.select().from(codex).orderBy(desc(codex.createdAt)).limit(60);
  return rows.filter((r) => r.active);
}

export async function codexHistory(): Promise<CodexEntry[]> {
  return db.select().from(codex).orderBy(desc(codex.createdAt)).limit(60);
}

export function codexPrompt(entries: CodexEntry[]): string {
  if (!entries.length) return "";
  return [
    "YOUR CODEX — operating rules you wrote for yourself. They override your defaults; follow them:",
    ...entries.map((e) => `- [v${e.version}] ${e.content}`),
    "You may rewrite these rules as you learn. Keep them short, specific and testable.",
  ].join("\n");
}

/** What actually happened lately — the evidence any rewrite must answer to. */
export async function evidence() {
  const msgs = await db.select().from(messages);
  const fb = await db.select().from(feedback);
  const mem = await db.select().from(memories);
  const src = await db.select().from(sources);
  const recent = msgs.slice(-40);
  const answers = recent.filter((m) => m.role === "assistant");
  const avgLen = answers.length
    ? Math.round(answers.reduce((a, m) => a + m.content.length, 0) / answers.length)
    : 0;
  return {
    turns: answers.length,
    totalTurns: msgs.filter((m) => m.role === "assistant").length,
    avgLength: avgLen,
    good: fb.filter((f) => f.vote > 0).length,
    bad: fb.filter((f) => f.vote < 0).length,
    corrections: mem.filter((m) => m.kind === "correction").map((m) => m.content),
    memories: mem.length,
    sourcedRatio: answers.length
      ? Math.round(
          (answers.filter((m) => m.searched && m.searched > 0).length / answers.length) * 100,
        )
      : 0,
    citations: src.length,
  };
}

/**
 * Rewrite the codex from evidence. Deterministic first (so it always produces
 * something honest), model-assisted when a brain is free to phrase it better.
 */
export async function evolve(): Promise<{ written: CodexEntry[]; report: string }> {
  const ev = await evidence();
  const existing = await activeCodex();
  const drafts: { kind: string; content: string; note: string }[] = [];

  if (ev.avgLength > 1600) {
    drafts.push({
      kind: "tuning",
      content: "Answers were running long — lead with the answer in one line, then support it. Cut any paragraph the question did not ask for.",
      note: `avg answer ${ev.avgLength} chars`,
    });
  } else if (ev.avgLength > 0 && ev.avgLength < 320) {
    drafts.push({
      kind: "tuning",
      content: "Answers were running thin — add the mechanism, the numbers and the trade-off, not just the conclusion.",
      note: `avg answer ${ev.avgLength} chars`,
    });
  }

  if (ev.sourcedRatio < 55) {
    drafts.push({
      kind: "rule",
      content: "Too few answers were grounded in live sources — scan the wire before answering any factual question, and cite each claim to its number.",
      note: `only ${ev.sourcedRatio}% of answers carried sources`,
    });
  }

  if (ev.bad > ev.good && ev.corrections.length) {
    drafts.push({
      kind: "rule",
      content: `Corrections are outrunning praise. Non-negotiable: ${ev.corrections.slice(0, 2).join(" / ")}`,
      note: `${ev.bad} fixes vs ${ev.good} good`,
    });
  }

  if (ev.good > ev.bad && ev.good > 2) {
    drafts.push({
      kind: "tuning",
      content: "The current register is landing — keep the same structure and directness, and keep answering in the first sentence.",
      note: `${ev.good} good verdicts`,
    });
  }

  if (!drafts.length) {
    drafts.push({
      kind: "note",
      content: "Nothing broken detected. Next cycle: answer one level deeper on technical questions and keep the first sentence as the answer.",
      note: "steady state",
    });
  }

  // Never pile up rules: supersede same-kind entries instead of stacking.
  const written: CodexEntry[] = [];
  for (const d of drafts.slice(0, 3)) {
    const dupe = existing.find((e) => e.kind === d.kind && e.content === d.content);
    if (dupe) continue;
    for (const e of existing.filter((x) => x.kind === d.kind)) {
      await db.update(codex).set({ active: 0 }).where(eq(codex.id, e.id));
    }
    const [row] = await db
      .insert(codex)
      .values({
        kind: d.kind,
        content: d.content,
        note: d.note,
        version: existing.filter((x) => x.kind === d.kind).length + 1,
      })
      .returning();
    written.push(row);
  }

  return {
    written,
    report: `Turns ${ev.totalTurns}, avg answer ${ev.avgLength} chars, ${ev.sourcedRatio}% sourced, verdicts ${ev.good} good / ${ev.bad} fixed, ${ev.memories} memories.`,
  };
}

export async function revertCodex(id: string) {
  await db.update(codex).set({ active: 0 }).where(eq(codex.id, id));
}

export async function reviveCodex(id: string) {
  await db.update(codex).set({ active: 1 }).where(eq(codex.id, id));
}
