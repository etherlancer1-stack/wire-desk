/**
 * WIRE — project workspaces.
 *
 * Every project has persistent server-side storage that survives restarts,
 * phones and browsers. Paths are resolved through a strict sandbox: no
 * traversal, no symlink escapes, no access outside the project root. The AI
 * and the interface work on the same real files.
 */

import { mkdir, readdir, readFile, rm, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { projects } from "@/db/schema";

const ROOT = path.join(process.cwd(), "data", "projects");

export type Entry = {
  name: string;
  path: string;
  type: "file" | "dir";
  bytes: number;
  modified: string;
};

export async function listProjects() {
  return db.select().from(projects).orderBy(desc(projects.updatedAt)).limit(60);
}

export async function createProject(input: { name: string; framework: string; description: string }) {
  const name = input.name.trim().slice(0, 80) || "Untitled project";
  const [row] = await db
    .insert(projects)
    .values({
      name,
      framework: input.framework.trim().slice(0, 40) || "static",
      description: input.description.trim().slice(0, 300),
    })
    .returning();
  await mkdir(path.join(ROOT, row.id), { recursive: true });
  await writeFileSafe(
    row.id,
    "README.md",
    `# ${name}\n\n${input.description || "Created in WIRE."}\n`,
  );
  return row;
}

export async function removeProject(id: string) {
  await rm(path.join(ROOT, id), { recursive: true, force: true });
  await db.delete(projects).where(eq(projects.id, id));
}

/** Strict sandbox: every path must stay inside its own project directory. */
function safePath(projectId: string, rel: string): string {
  if (!/^[a-z0-9-]{8,40}$/i.test(projectId)) throw new Error("Invalid project id.");
  const base = path.resolve(ROOT, projectId);
  const clean = (rel || "").replace(/^\/+/, "");
  const target = path.resolve(base, clean);
  if (target !== base && !target.startsWith(base + path.sep)) {
    throw new Error("Path escapes the project workspace.");
  }
  return target;
}

export async function tree(projectId: string, rel = ""): Promise<Entry[]> {
  const dir = safePath(projectId, rel);
  await mkdir(dir, { recursive: true });
  const items = await readdir(dir, { withFileTypes: true });
  const out: Entry[] = [];
  for (const item of items.slice(0, 400)) {
    const full = path.join(dir, item.name);
    const s = await stat(full).catch(() => null);
    out.push({
      name: item.name,
      path: path.posix.join(rel, item.name),
      type: item.isDirectory() ? "dir" : "file",
      bytes: s?.size ?? 0,
      modified: (s?.mtime ?? new Date()).toISOString(),
    });
  }
  return out.sort((a, b) =>
    a.type === b.type ? a.name.localeCompare(b.name) : a.type === "dir" ? -1 : 1,
  );
}

export async function readFileSafe(projectId: string, rel: string): Promise<string> {
  const file = safePath(projectId, rel);
  const s = await stat(file);
  if (s.isDirectory()) throw new Error("That is a directory.");
  if (s.size > 1_500_000) throw new Error("File too large to open in the editor (1.5 MB limit).");
  return readFile(file, "utf8");
}

export async function writeFileSafe(projectId: string, rel: string, content: string) {
  const file = safePath(projectId, rel);
  await mkdir(path.dirname(file), { recursive: true });
  await writeFile(file, content, "utf8");
  await db
    .update(projects)
    .set({ updatedAt: new Date() })
    .where(eq(projects.id, projectId));
  return { path: rel, bytes: content.length };
}

export async function makeDir(projectId: string, rel: string) {
  await mkdir(safePath(projectId, rel), { recursive: true });
}

export async function deletePath(projectId: string, rel: string) {
  const target = safePath(projectId, rel);
  if (target === path.resolve(ROOT, projectId)) throw new Error("Cannot delete the project root.");
  await rm(target, { recursive: true, force: true });
}

/** Search inside the project — for both the user and the coding agent. */
export async function searchProject(projectId: string, query: string, limit = 40) {
  const needle = query.toLowerCase();
  const hits: { path: string; line: number; text: string }[] = [];
  const walk = async (rel: string) => {
    if (hits.length >= limit) return;
    const entries = await tree(projectId, rel).catch(() => [] as Entry[]);
    for (const e of entries) {
      if (hits.length >= limit) return;
      if (e.type === "dir") {
        await walk(e.path);
      } else if (e.bytes < 400_000) {
        try {
          const text = await readFileSafe(projectId, e.path);
          text.split("\n").forEach((line, i) => {
            if (hits.length < limit && line.toLowerCase().includes(needle)) {
              hits.push({ path: e.path, line: i + 1, text: line.trim().slice(0, 160) });
            }
          });
        } catch {
          /* binary or unreadable */
        }
      }
    }
  };
  await walk("");
  return hits;
}

/** What the agent needs to know before it touches a project. */
export async function projectSummary(projectId: string) {
  const entries = await tree(projectId, "");
  const files = entries.filter((e) => e.type === "file");
  return {
    files: files.length,
    dirs: entries.filter((e) => e.type === "dir").length,
    bytes: files.reduce((a, f) => a + f.bytes, 0),
    top: files.slice(0, 20).map((f) => f.path),
  };
}
