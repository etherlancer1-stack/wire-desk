/**
 * WIRE — source export.
 *
 * The desk can hand over its own complete source: every module, config and
 * asset, zipped in-process with no dependencies, or as one raw text listing.
 * This is how you take the whole thing with you — to a server, to a fork, or
 * to read at the kitchen table.
 */

import { readdir, readFile, stat } from "node:fs/promises";
import path from "node:path";

const ROOT = process.cwd();

const INCLUDE = [
  "src",
  "public",
  "package.json",
  "tsconfig.json",
  "next.config.ts",
  "postcss.config.mjs",
  "drizzle.config.json",
  "eslint.config.mjs",
  "Dockerfile",
  "render.yaml",
  "PUBLISH.md",
];

const SKIP = new Set(["node_modules", ".next", ".git", ".env", "dist", ".turbo"]);

export type FileEntry = { path: string; bytes: number; lines: number };

async function walk(dir: string, acc: string[]): Promise<string[]> {
  const entries = await readdir(dir, { withFileTypes: true });
  for (const e of entries) {
    if (SKIP.has(e.name)) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) await walk(full, acc);
    else acc.push(full);
  }
  return acc;
}

export async function listSource(): Promise<FileEntry[]> {
  const files: string[] = [];
  for (const item of INCLUDE) {
    const full = path.join(ROOT, item);
    try {
      const s = await stat(full);
      if (s.isDirectory()) await walk(full, files);
      else files.push(full);
    } catch {
      /* optional file */
    }
  }
  const out: FileEntry[] = [];
  for (const f of files.sort()) {
    const s = await stat(f);
    const rel = path.relative(ROOT, f);
    let lines = 0;
    if (/\.(ts|tsx|js|jsx|css|json|md|mjs|yml|yaml|html)$/.test(rel)) {
      const text = await readFile(f, "utf8");
      lines = text.split("\n").length;
    }
    out.push({ path: rel, bytes: s.size, lines });
  }
  return out;
}

export async function sourceLines(): Promise<number> {
  return (await listSource()).reduce((a, f) => a + f.lines, 0);
}

/** One readable file: every text source file, separated by banners. */
export async function textListing(): Promise<string> {
  const entries = await listSource();
  const parts: string[] = [
    `WIRE — complete source export · ${new Date().toISOString()}`,
    `${entries.length} files`,
    "",
  ];
  for (const e of entries) {
    if (!/\.(ts|tsx|css|json|mjs|yml|yaml|md|html)$/.test(e.path)) continue;
    const text = await readFile(path.join(ROOT, e.path), "utf8");
    parts.push("=".repeat(78));
    parts.push(`FILE: ${e.path}  (${e.lines} lines)`);
    parts.push("=".repeat(78));
    parts.push(text);
    parts.push("");
  }
  return parts.join("\n");
}

/* --------------------------- dependency-free zip -------------------------- */

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function dosTime(d: Date) {
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
  const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time, date };
}

/** Store-only ZIP: no dependencies, no compression, opens everywhere. */
export async function zipSource(): Promise<Buffer> {
  const entries = await listSource();
  const now = dosTime(new Date());
  const locals: Buffer[] = [];
  const centrals: Buffer[] = [];
  let offset = 0;

  for (const e of entries) {
    const name = Buffer.from(`wire/${e.path}`, "utf8");
    const data = await readFile(path.join(ROOT, e.path));
    const crc = crc32(data);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt16LE(now.time, 10);
    local.writeUInt16LE(now.date, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    locals.push(local, name, data);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt16LE(now.time, 12);
    central.writeUInt16LE(now.date, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(data.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt16LE(0, 30);
    central.writeUInt16LE(0, 32);
    central.writeUInt16LE(0, 34);
    central.writeUInt16LE(0, 36);
    central.writeUInt32LE(0, 38);
    central.writeUInt32LE(offset, 42);
    centrals.push(central, name);

    offset += local.length + name.length + data.length;
  }

  const centralBuf = Buffer.concat(centrals);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(centralBuf.length, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([...locals, centralBuf, eocd]);
}
