/**
 * WIRE — the security lab.
 *
 * Ethical testing only. Every check runs against a target the owner has
 * explicitly declared and authorized, is non-destructive by default, and is
 * recorded. The tool catalog below mirrors the official Kali Linux toolset
 * (kali.org/tools/all-tools) with honest installation status: a tool is only
 * ever reported as installed when it is actually present and verified on the
 * host running it — never otherwise.
 */

import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { targets } from "@/db/schema";

export type Tool = {
  name: string;
  category: string;
  about: string;
  docs: string;
};

/**
 * Scope hardening. Assessments must never reach internal infrastructure —
 * not through a typed hostname, not through a redirect, not through DNS.
 */
export function blockedHost(host: string): string | null {
  const h = host.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
  if (!h) return "empty host";
  if (/^(localhost|127\.|0\.0\.0\.0|\[?::1\]?|ip6-localhost)/.test(h)) return "localhost";
  if (/^10\./.test(h) || /^192\.168\./.test(h) || /^172\.(1[6-9]|2\d|3[01])\./.test(h))
    return "private network range";
  if (/^169\.254\./.test(h) || /metadata\.google\.internal/.test(h))
    return "link-local / cloud metadata service";
  if (/^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(h)) return "CGNAT range";
  if (/\.(internal|local|localdomain|home|lan)$/.test(h)) return "internal name";
  if (/^\[?::ffff:/i.test(h)) return "mapped loopback";
  return null;
}

/** Ownership proof: a DNS TXT record only the domain controller can set. */
export async function verifyOwnership(host: string): Promise<{ verified: boolean; detail: string }> {
  try {
    const { resolveTxt } = await import("node:dns/promises");
    const records = await resolveTxt(host);
    const flat = records.flat();
    const found = flat.find((r) => r.startsWith("wire-verify="));
    return found
      ? { verified: true, detail: `DNS proof found: ${found}` }
      : {
          verified: false,
          detail: `No proof yet. Create a DNS TXT record: wire-verify=${host} and re-check.`,
        };
  } catch (err) {
    return {
      verified: false,
      detail: `DNS lookup failed: ${err instanceof Error ? err.message : "unknown"}`,
    };
  }
}

/** Curated from the official Kali tool index — the tools that matter first. */
export const KALI_TOOLS: Tool[] = [
  { name: "nmap", category: "Network discovery", about: "Host discovery, port and service enumeration, NSE scripting.", docs: "https://www.kali.org/tools/nmap/" },
  { name: "masscan", category: "Network discovery", about: "Internet-scale TCP port scanner.", docs: "https://www.kali.org/tools/masscan/" },
  { name: "rustscan", category: "Network discovery", about: "Fast port scanner that hands off to nmap.", docs: "https://www.kali.org/tools/rustscan/" },
  { name: "arp-scan", category: "Network discovery", about: "Layer-2 host discovery via ARP.", docs: "https://www.kali.org/tools/arp-scan/" },
  { name: "dnsrecon", category: "DNS security", about: "DNS enumeration, zone transfer and record analysis.", docs: "https://www.kali.org/tools/dnsrecon/" },
  { name: "dnsenum", category: "DNS security", about: "Domain enumeration and subdomain discovery.", docs: "https://www.kali.org/tools/dnsenum/" },
  { name: "fierce", category: "DNS security", about: "Non-contiguous IP space and DNS recon.", docs: "https://www.kali.org/tools/fierce/" },
  { name: "theHarvester", category: "OSINT", about: "Emails, subdomains and names from public sources.", docs: "https://www.kali.org/tools/theharvester/" },
  { name: "recon-ng", category: "OSINT", about: "Modular reconnaissance framework.", docs: "https://www.kali.org/tools/recon-ng/" },
  { name: "maltego", category: "OSINT", about: "Link analysis and relationship mapping.", docs: "https://www.kali.org/tools/maltego/" },
  { name: "shodan", category: "OSINT", about: "Internet-connected device search.", docs: "https://www.kali.org/tools/shodan/" },
  { name: "spiderfoot", category: "OSINT", about: "Automated OSINT collection and correlation.", docs: "https://www.kali.org/tools/spiderfoot/" },
  { name: "nikto", category: "Web application testing", about: "Web server misconfiguration and vulnerability scanner.", docs: "https://www.kali.org/tools/nikto/" },
  { name: "sqlmap", category: "Web application testing", about: "Automated SQL injection detection and exploitation (authorized targets only).", docs: "https://www.kali.org/tools/sqlmap/" },
  { name: "wpscan", category: "Web application testing", about: "WordPress vulnerability scanner.", docs: "https://www.kali.org/tools/wpscan/" },
  { name: "gobuster", category: "Web application testing", about: "Directory, DNS and vhost brute-forcing.", docs: "https://www.kali.org/tools/gobuster/" },
  { name: "ffuf", category: "Web application testing", about: "Fast web fuzzer for content discovery.", docs: "https://www.kali.org/tools/ffuf/" },
  { name: "dirb", category: "Web application testing", about: "URL brute-force scanner.", docs: "https://www.kali.org/tools/dirb/" },
  { name: "wfuzz", category: "Web application testing", about: "Web application fuzzer.", docs: "https://www.kali.org/tools/wfuzz/" },
  { name: "burpsuite", category: "Web application testing", about: "Intercepting proxy and web security workbench.", docs: "https://www.kali.org/tools/burpsuite/" },
  { name: "zaproxy", category: "Web application testing", about: "OWASP ZAP — automated web app scanner.", docs: "https://www.kali.org/tools/zaproxy/" },
  { name: "commix", category: "Web application testing", about: "Command injection discovery and exploitation.", docs: "https://www.kali.org/tools/commix/" },
  { name: "nuclei", category: "Vulnerability assessment", about: "Template-based vulnerability scanner.", docs: "https://www.kali.org/tools/nuclei/" },
  { name: "openvas", category: "Vulnerability assessment", about: "Full-featured vulnerability management scanner.", docs: "https://www.kali.org/tools/openvas/" },
  { name: "lynis", category: "Vulnerability assessment", about: "System hardening and auditing.", docs: "https://www.kali.org/tools/lynis/" },
  { name: "legion", category: "Vulnerability assessment", about: "Semi-automated network penetration testing.", docs: "https://www.kali.org/tools/legion/" },
  { name: "metasploit-framework", category: "Exploitation", about: "Exploit development and delivery framework — authorized engagements only.", docs: "https://www.kali.org/tools/metasploit-framework/" },
  { name: "searchsploit", category: "Exploitation", about: "Offline search of the Exploit-DB archive.", docs: "https://www.kali.org/tools/searchsploit/" },
  { name: "set", category: "Exploitation", about: "Social engineering toolkit — with explicit written authorization only.", docs: "https://www.kali.org/tools/set/" },
  { name: "responder", category: "Network traffic", about: "LLMNR/NBT-NS/MDNS poisoning for internal assessments.", docs: "https://www.kali.org/tools/responder/" },
  { name: "wireshark", category: "Network traffic", about: "Deep packet capture and protocol analysis.", docs: "https://www.kali.org/tools/wireshark/" },
  { name: "tcpdump", category: "Network traffic", about: "Command-line packet capture.", docs: "https://www.kali.org/tools/tcpdump/" },
  { name: "tshark", category: "Network traffic", about: "Terminal packet analysis.", docs: "https://www.kali.org/tools/tshark/" },
  { name: "ettercap", category: "Network traffic", about: "MITM detection and analysis on owned networks.", docs: "https://www.kali.org/tools/ettercap/" },
  { name: "hcxtools", category: "Wireless security", about: "WiFi handshake capture and analysis.", docs: "https://www.kali.org/tools/hcxtools/" },
  { name: "aircrack-ng", category: "Wireless security", about: "WiFi security assessment suite.", docs: "https://www.kali.org/tools/aircrack-ng/" },
  { name: "wifite2", category: "Wireless security", about: "Automated wireless auditing.", docs: "https://www.kali.org/tools/wifite2/" },
  { name: "hcxdumptool", category: "Wireless security", about: "WiFi packet capture for auditing own hardware.", docs: "https://www.kali.org/tools/hcxdumptool/" },
  { name: "hydra", category: "Password security", about: "Online password auditing against owned services.", docs: "https://www.kali.org/tools/hydra/" },
  { name: "john", category: "Password security", about: "John the Ripper — offline hash auditing.", docs: "https://www.kali.org/tools/john/" },
  { name: "hashcat", category: "Password security", about: "GPU password recovery and strength studies.", docs: "https://www.kali.org/tools/hashcat/" },
  { name: "cewl", category: "Password security", about: "Wordlist generation from target content.", docs: "https://www.kali.org/tools/cewl/" },
  { name: "crunch", category: "Password security", about: "Custom wordlist generation.", docs: "https://www.kali.org/tools/crunch/" },
  { name: "openssl", category: "Cryptography", about: "Certificates, TLS configuration and key tooling.", docs: "https://www.kali.org/tools/openssl/" },
  { name: "sslscan", category: "Cryptography", about: "TLS/SSL configuration assessment.", docs: "https://www.kali.org/tools/sslscan/" },
  { name: "testssl.sh", category: "Cryptography", about: "Exhaustive TLS configuration testing.", docs: "https://www.kali.org/tools/testssl.sh/" },
  { name: "steghide", category: "Cryptography", about: "Steganography analysis.", docs: "https://www.kali.org/tools/steghide/" },
  { name: "binwalk", category: "Reverse engineering", about: "Firmware and binary analysis.", docs: "https://www.kali.org/tools/binwalk/" },
  { name: "ghidra", category: "Reverse engineering", about: "Full reverse engineering suite.", docs: "https://www.kali.org/tools/ghidra/" },
  { name: "radare2", category: "Reverse engineering", about: "Binary analysis framework.", docs: "https://www.kali.org/tools/radare2/" },
  { name: "gdb", category: "Reverse engineering", about: "Debugger with exploit development plugins.", docs: "https://www.kali.org/tools/gdb/" },
  { name: "apktool", category: "Reverse engineering", about: "Android application analysis.", docs: "https://www.kali.org/tools/apktool/" },
  { name: "yara", category: "Malware analysis", about: "Pattern matching for malware classification.", docs: "https://www.kali.org/tools/yara/" },
  { name: "clamav", category: "Malware analysis", about: "Antivirus engine and signature scanning.", docs: "https://www.kali.org/tools/clamav/" },
  { name: "foremost", category: "Digital forensics", about: "File carving and recovery.", docs: "https://www.kali.org/tools/foremost/" },
  { name: "autopsy", category: "Digital forensics", about: "Disk forensic analysis workbench.", docs: "https://www.kali.org/tools/autopsy/" },
  { name: "volatility3", category: "Digital forensics", about: "Memory forensics framework.", docs: "https://www.kali.org/tools/volatility3/" },
  { name: "sleuthkit", category: "Digital forensics", about: "File system forensic tooling.", docs: "https://www.kali.org/tools/sleuthkit/" },
  { name: "afl++", category: "Fuzz testing", about: "Coverage-guided fuzzing.", docs: "https://www.kali.org/tools/afl/" },
  { name: "boofuzz", category: "Fuzz testing", about: "Network protocol fuzzing.", docs: "https://www.kali.org/tools/boofuzz/" },
  { name: "trivy", category: "Container security", about: "Container and dependency vulnerability scanning.", docs: "https://www.kali.org/tools/trivy/" },
  { name: "docker-bench", category: "Container security", about: "Docker host hardening checks.", docs: "https://www.kali.org/tools/docker-bench-security/" },
  { name: "snyk", category: "Cloud security", about: "Dependency and code scanning.", docs: "https://snyk.io" },
  { name: "semgrep", category: "Cloud security", about: "Static analysis with custom rules.", docs: "https://semgrep.dev" },
  { name: "pacu", category: "Cloud security", about: "AWS exploitation framework for owned accounts.", docs: "https://www.kali.org/tools/pacu/" },
  { name: "bloodhound", category: "Active Directory", about: "AD relationship analysis.", docs: "https://www.kali.org/tools/bloodhound/" },
  { name: "impacket", category: "Active Directory", about: "Network protocol tooling for internal assessments.", docs: "https://www.kali.org/tools/impacket/" },
  { name: "responder-ad", category: "Active Directory", about: "Internal name-resolution analysis.", docs: "https://www.kali.org/tools/responder/" },
  { name: "crackmapexec", category: "Active Directory", about: "Swiss-army knife for AD security assessment.", docs: "https://www.kali.org/tools/crackmapexec/" },

  /* ------------------------------ OSINT ------------------------------ */
  { name: "osrframework", category: "OSINT", about: "Username and identity enumeration across platforms.", docs: "https://www.kali.org/tools/osrframework/" },
  { name: "sherlock", category: "OSINT", about: "Hunt usernames across social networks.", docs: "https://github.com/sherlock-project/sherlock" },
  { name: "holehe", category: "OSINT", about: "Check which sites an email address is registered on.", docs: "https://github.com/megadose/holehe" },
  { name: "infoga", category: "OSINT", about: "Email intelligence and breach exposure gathering.", docs: "https://github.com/m4ll0k/Infoga" },
  { name: "metagoofil", category: "OSINT", about: "Metadata extraction from public documents.", docs: "https://www.kali.org/tools/metagoofil/" },
  { name: "exiftool", category: "OSINT", about: "Deep metadata reading and writing for media and documents.", docs: "https://www.kali.org/tools/exiftool/" },
  { name: "creepy", category: "OSINT", about: "Geolocation intelligence gathering.", docs: "https://www.kali.org/tools/creepy/" },
  { name: "twint", category: "OSINT", about: "Twitter intelligence without API keys.", docs: "https://github.com/twintproject/twint" },
  { name: "social-analyzer", category: "OSINT", about: "Profile analysis across 1000+ sites.", docs: "https://github.com/qeeqbox/social-analyzer" },
  { name: "whois", category: "OSINT", about: "Domain registration records.", docs: "https://www.kali.org/tools/whois/" },
  { name: "dnslytics", category: "OSINT", about: "Domain, IP and ASN relationship research.", docs: "https://dnslytics.com" },
  { name: "censys", category: "OSINT", about: "Internet-wide scan data and certificate search.", docs: "https://censys.io" },
  { name: "zoomeye", category: "OSINT", about: "Cyberspace search engine for exposed services.", docs: "https://www.zoomeye.org" },
  { name: "fofa", category: "OSINT", about: "Asset discovery and exposure mapping.", docs: "https://fofa.info" },
  { name: "greynoise", category: "OSINT", about: "Internet background noise and scanner intelligence.", docs: "https://www.greynoise.io" },
  { name: "h8mail", category: "OSINT", about: "Breach and credential exposure checks (defensive).", docs: "https://github.com/khast3x/h8mail" },

  /* --------------------------- Network ----------------------------- */
  { name: "zmap", category: "Network discovery", about: "Internet-wide single-packet scanning.", docs: "https://www.kali.org/tools/zmap/" },
  { name: "netdiscover", category: "Network discovery", about: "ARP-based LAN host discovery.", docs: "https://www.kali.org/tools/netdiscover/" },
  { name: "nbtscan", category: "Network discovery", about: "NetBIOS name scanning.", docs: "https://www.kali.org/tools/nbtscan/" },
  { name: "onesixtyone", category: "Network discovery", about: "SNMP community string scanner.", docs: "https://www.kali.org/tools/onesixtyone/" },
  { name: "ike-scan", category: "Network discovery", about: "IPsec VPN discovery and fingerprinting.", docs: "https://www.kali.org/tools/ike-scan/" },
  { name: "nmap-nse-vulners", category: "Network discovery", about: "Version-to-CVE matching through NSE.", docs: "https://nmap.org/nsedoc/scripts/vulners.html" },
  { name: "enum4linux-ng", category: "Network discovery", about: "SMB/Windows enumeration.", docs: "https://www.kali.org/tools/enum4linux/" },
  { name: "smbclient", category: "Network discovery", about: "SMB share inspection on owned networks.", docs: "https://www.kali.org/tools/smbclient/" },

  /* ------------------------ DNS & infrastructure ------------------- */
  { name: "amass", category: "DNS security", about: "In-depth attack surface mapping and subdomain discovery.", docs: "https://www.kali.org/tools/amass/" },
  { name: "subfinder", category: "DNS security", about: "Passive subdomain enumeration.", docs: "https://www.kali.org/tools/subfinder/" },
  { name: "sublist3r", category: "DNS security", about: "Subdomain enumeration via public sources.", docs: "https://www.kali.org/tools/sublist3r/" },
  { name: "aquatone", category: "DNS security", about: "Domain flyovers with screenshot grouping.", docs: "https://github.com/michenriksen/aquatone" },
  { name: "dnsdumpster", category: "DNS security", about: "DNS research and mapping.", docs: "https://dnsdumpster.com" },
  { name: "dnswalk", category: "DNS security", about: "DNS zone sanity checking.", docs: "https://www.kali.org/tools/dnswalk/" },
  { name: "lbd", category: "DNS security", about: "Load balancer detection.", docs: "https://www.kali.org/tools/lbd/" },

  /* ------------------------ Web application ------------------------ */
  { name: "arachni", category: "Web application testing", about: "Full-featured web application security scanner.", docs: "https://www.kali.org/tools/arachni/" },
  { name: "skipfish", category: "Web application testing", about: "Web application reconnaissance crawler.", docs: "https://www.kali.org/tools/skipfish/" },
  { name: "whatweb", category: "Web application testing", about: "Web technology fingerprinting.", docs: "https://www.kali.org/tools/whatweb/" },
  { name: "wafw00f", category: "Web application testing", about: "Web application firewall detection.", docs: "https://www.kali.org/tools/wafw00f/" },
  { name: "feroxbuster", category: "Web application testing", about: "Recursive content discovery.", docs: "https://www.kali.org/tools/feroxbuster/" },
  { name: "dirsearch", category: "Web application testing", about: "Web path scanner.", docs: "https://www.kali.org/tools/dirsearch/" },
  { name: "vhostscan", category: "Web application testing", about: "Virtual host discovery.", docs: "https://www.kali.org/tools/vhostscan/" },
  { name: "s3scanner", category: "Web application testing", about: "Open cloud storage bucket discovery (defensive).", docs: "https://github.com/sa7mon/S3Scanner" },
  { name: "jwt_tool", category: "Web application testing", about: "JSON Web Token testing and hardening review.", docs: "https://github.com/ticarpi/jwt_tool" },
  { name: "corsy", category: "Web application testing", about: "CORS misconfiguration detection.", docs: "https://github.com/s0md3v/Corsy" },
  { name: "testcookie", category: "Web application testing", about: "Session cookie and consent review.", docs: "https://owasp.org/www-project-web-security-testing-guide/" },
  { name: "xsstrike", category: "Web application testing", about: "XSS detection engine.", docs: "https://github.com/s0md3v/XSStrike" },
  { name: "dalfox", category: "Web application testing", about: "Parameter analysis and XSS scanning.", docs: "https://github.com/hahwul/dalfox" },
  { name: "crlfuzz", category: "Web application testing", about: "CRLF injection detection.", docs: "https://github.com/dwisiswant0/crlfuzz" },
  { name: "httpx", category: "Web application testing", about: "Fast HTTP probing and metadata collection.", docs: "https://www.kali.org/tools/httpx/" },
  { name: "katana", category: "Web application testing", about: "Next-generation crawling and endpoint discovery.", docs: "https://www.kali.org/tools/katana/" },
  { name: "gau", category: "Web application testing", about: "Known-URL retrieval from public archives.", docs: "https://github.com/lc/gau" },
  { name: "waybackurls", category: "Web application testing", about: "Historical URL discovery.", docs: "https://github.com/tomnomnom/waybackurls" },

  /* ---------------------- Vulnerability assessment ------------------ */
  { name: "nessus", category: "Vulnerability assessment", about: "Commercial vulnerability scanner (own infrastructure only).", docs: "https://www.tenable.com/products/nessus" },
  { name: "qualys", category: "Vulnerability assessment", about: "Cloud vulnerability management.", docs: "https://www.qualys.com" },
  { name: "vuls", category: "Vulnerability assessment", about: "Agentless vulnerability scanner for servers.", docs: "https://vuls.io" },
  { name: "grype", category: "Vulnerability assessment", about: "Container and filesystem vulnerability scanner.", docs: "https://github.com/anchore/grype" },
  { name: "osv-scanner", category: "Vulnerability assessment", about: "Dependency vulnerability lookup against OSV.", docs: "https://github.com/google/osv-scanner" },
  { name: "retire.js", category: "Vulnerability assessment", about: "Detects outdated JavaScript libraries.", docs: "https://retirejs.github.io/retire.js/" },
  { name: "npm-audit", category: "Vulnerability assessment", about: "Dependency audit for Node projects.", docs: "https://docs.npmjs.com/cli/v10/commands/npm-audit" },
  { name: "pip-audit", category: "Vulnerability assessment", about: "Python dependency auditing.", docs: "https://github.com/pypa/pip-audit" },

  /* ------------------------- Secrets & code ------------------------- */
  { name: "gitleaks", category: "Cloud security", about: "Secret detection in repositories and history.", docs: "https://github.com/gitleaks/gitleaks" },
  { name: "trufflehog", category: "Cloud security", about: "Credential discovery across git and storage.", docs: "https://github.com/trufflesecurity/trufflehog" },
  { name: "detect-secrets", category: "Cloud security", about: "Auditable secret detection baseline.", docs: "https://github.com/Yelp/detect-secrets" },
  { name: "bandit", category: "Cloud security", about: "Python static security analysis.", docs: "https://github.com/PyCQA/bandit" },
  { name: "eslint-security", category: "Cloud security", about: "Security-focused linting for JavaScript.", docs: "https://github.com/nodesecurity/eslint-plugin-security" },
  { name: "brakeman", category: "Cloud security", about: "Ruby on Rails static analysis.", docs: "https://brakemanscanner.org" },
  { name: "gosec", category: "Cloud security", about: "Go security static analysis.", docs: "https://github.com/securego/gosec" },
  { name: "sonarqube", category: "Cloud security", about: "Continuous code quality and security.", docs: "https://www.sonarsource.com/products/sonarqube/" },
  { name: "codeql", category: "Cloud security", about: "Semantic code analysis and query engine.", docs: "https://codeql.github.com" },
  { name: "bearer", category: "Cloud security", about: "Data-flow security scanning.", docs: "https://github.com/Bearer/bearer" },

  /* -------------------------- Passwords ---------------------------- */
  { name: "ophcrack", category: "Password security", about: "Rainbow-table password auditing (own hashes).", docs: "https://www.kali.org/tools/ophcrack/" },
  { name: "fcrackzip", category: "Password security", about: "ZIP password auditing for owned archives.", docs: "https://www.kali.org/tools/fcrackzip/" },
  { name: "rarcrack", category: "Password security", about: "RAR/7z archive password auditing.", docs: "https://www.kali.org/tools/rarcrack/" },
  { name: "patator", category: "Password security", about: "Multi-protocol brute-force auditing.", docs: "https://www.kali.org/tools/patator/" },
  { name: "medusa", category: "Password security", about: "Parallel login auditing.", docs: "https://www.kali.org/tools/medusa/" },
  { name: "ncrack", category: "Password security", about: "Network authentication auditing.", docs: "https://www.kali.org/tools/ncrack/" },
  { name: "hash-identifier", category: "Password security", about: "Identify hash formats before auditing.", docs: "https://www.kali.org/tools/hash-identifier/" },
  { name: "cupp", category: "Password security", about: "Custom wordlist generation from profiles.", docs: "https://www.kali.org/tools/cupp/" },

  /* --------------------------- Wireless ---------------------------- */
  { name: "kismet", category: "Wireless security", about: "Wireless detector and sniffer.", docs: "https://www.kali.org/tools/kismet/" },
  { name: "reaver", category: "Wireless security", about: "WPS assessment on owned hardware.", docs: "https://www.kali.org/tools/reaver/" },
  { name: "bully", category: "Wireless security", about: "WPS brute-force auditing.", docs: "https://www.kali.org/tools/bully/" },
  { name: "fern-wifi-cracker", category: "Wireless security", about: "Wireless security auditing suite.", docs: "https://www.kali.org/tools/fern-wifi-cracker/" },
  { name: "pixiewps", category: "Wireless security", about: "Offline WPS attack analysis.", docs: "https://www.kali.org/tools/pixiewps/" },
  { name: "btscanner", category: "Wireless security", about: "Bluetooth device discovery.", docs: "https://www.kali.org/tools/btscanner/" },
  { name: "spooftooph", category: "Wireless security", about: "Bluetooth auditing for owned devices.", docs: "https://www.kali.org/tools/spooftooph/" },

  /* ------------------------ Traffic & radio ------------------------ */
  { name: "ngrep", category: "Network traffic", about: "Network grep for live traffic.", docs: "https://www.kali.org/tools/ngrep/" },
  { name: "dsniff", category: "Network traffic", about: "Network auditing and analysis suite.", docs: "https://www.kali.org/tools/dsniff/" },
  { name: "scapy", category: "Network traffic", about: "Packet crafting and analysis library.", docs: "https://www.kali.org/tools/scapy/" },
  { name: "netsniff-ng", category: "Network traffic", about: "High-performance traffic analyzer.", docs: "https://www.kali.org/tools/netsniff-ng/" },
  { name: "tcpreplay", category: "Network traffic", about: "Traffic replay for lab analysis.", docs: "https://www.kali.org/tools/tcpreplay/" },
  { name: "mitmproxy", category: "Network traffic", about: "Interactive TLS-intercepting proxy.", docs: "https://mitmproxy.org" },

  /* ----------------------- Crypto & certificates ------------------- */
  { name: "certbot", category: "Cryptography", about: "TLS certificate automation and review.", docs: "https://certbot.eff.org" },
  { name: "crt.sh", category: "Cryptography", about: "Certificate transparency log search.", docs: "https://crt.sh" },
  { name: "sslyze", category: "Cryptography", about: "TLS configuration analyzer.", docs: "https://github.com/nabla-c0d3/sslyze" },
  { name: "aeskeyfind", category: "Cryptography", about: "Locate AES keys in memory images.", docs: "https://www.kali.org/tools/aeskeyfind/" },
  { name: "rsakeyfind", category: "Cryptography", about: "Locate RSA keys in memory images.", docs: "https://www.kali.org/tools/rsakeyfind/" },
  { name: "pgpdump", category: "Cryptography", about: "PGP packet structure analysis.", docs: "https://www.kali.org/tools/pgpdump/" },

  /* ------------------------ Forensics & IR ------------------------ */
  { name: "rekall", category: "Digital forensics", about: "Memory forensics framework.", docs: "https://www.kali.org/tools/rekall/" },
  { name: "bulk_extractor", category: "Digital forensics", about: "Feature extraction from disk images.", docs: "https://www.kali.org/tools/bulk-extractor/" },
  { name: "dc3dd", category: "Digital forensics", about: "Forensic imaging.", docs: "https://www.kali.org/tools/dc3dd/" },
  { name: "guymager", category: "Digital forensics", about: "Forensic imager GUI.", docs: "https://www.kali.org/tools/guymager/" },
  { name: "scalpel", category: "Digital forensics", about: "File carving.", docs: "https://www.kali.org/tools/scalpel/" },
  { name: "chkrootkit", category: "Digital forensics", about: "Rootkit detection on owned hosts.", docs: "https://www.kali.org/tools/chkrootkit/" },
  { name: "rkhunter", category: "Digital forensics", about: "Rootkit and backdoor detection.", docs: "https://www.kali.org/tools/rkhunter/" },
  { name: "aide", category: "Digital forensics", about: "File integrity monitoring.", docs: "https://www.kali.org/tools/aide/" },
  { name: "ossec", category: "Digital forensics", about: "Host intrusion detection.", docs: "https://www.ossec.net" },
  { name: "velociraptor", category: "Digital forensics", about: "Endpoint visibility and response.", docs: "https://docs.velociraptor.app" },

  /* --------------------- Malware & reverse ------------------------ */
  { name: "cuckoo", category: "Malware analysis", about: "Automated malware sandbox (isolated lab).", docs: "https://cuckoosandbox.org" },
  { name: "remnux", category: "Malware analysis", about: "Malware analysis distribution toolkit.", docs: "https://remnux.org" },
  { name: "floss", category: "Malware analysis", about: "Obfuscated string recovery.", docs: "https://github.com/mandiant/flare-floss" },
  { name: "upx", category: "Malware analysis", about: "Packer analysis and unpacking.", docs: "https://upx.github.io" },
  { name: "pedump", category: "Reverse engineering", about: "PE header analysis.", docs: "https://www.kali.org/tools/pedump/" },
  { name: "rizin", category: "Reverse engineering", about: "Reverse engineering framework.", docs: "https://rizin.re" },
  { name: "gdb-peda", category: "Reverse engineering", about: "Exploit development assistant for GDB.", docs: "https://github.com/longld/peda" },
  { name: "one_gadget", category: "Reverse engineering", about: "RCE gadget discovery in libc.", docs: "https://github.com/david942j/one_gadget" },
  { name: "ropper", category: "Reverse engineering", about: "ROP chain research.", docs: "https://github.com/sashs/Ropper" },
  { name: "checksec", category: "Reverse engineering", about: "Binary hardening property checks.", docs: "https://www.kali.org/tools/checksec/" },

  /* ------------------------ Fuzzing & QA -------------------------- */
  { name: "honggfuzz", category: "Fuzz testing", about: "Coverage-guided fuzzing engine.", docs: "https://github.com/google/honggfuzz" },
  { name: "libfuzzer", category: "Fuzz testing", about: "In-process fuzzing for C/C++.", docs: "https://llvm.org/docs/LibFuzzer.html" },
  { name: "jazzer", category: "Fuzz testing", about: "Coverage-guided fuzzing for JVM.", docs: "https://github.com/CodeIntelligenceTesting/jazzer" },
  { name: "wfuzz-suite", category: "Fuzz testing", about: "Web parameter fuzzing.", docs: "https://www.kali.org/tools/wfuzz/" },

  /* --------------------- Containers & cloud ----------------------- */
  { name: "kube-bench", category: "Container security", about: "Kubernetes CIS benchmark checks.", docs: "https://github.com/aquasecurity/kube-bench" },
  { name: "kube-hunter", category: "Container security", about: "Kubernetes penetration testing (owned clusters).", docs: "https://github.com/aquasecurity/kube-hunter" },
  { name: "checkov", category: "Container security", about: "Infrastructure-as-code scanning.", docs: "https://www.checkov.io" },
  { name: "tfsec", category: "Container security", about: "Terraform security scanning.", docs: "https://aquasecurity.github.io/tfsec/" },
  { name: "dockle", category: "Container security", about: "Container image linter.", docs: "https://github.com/goodwithtech/dockle" },
  { name: "syft", category: "Container security", about: "Software bill of materials generation.", docs: "https://github.com/anchore/syft" },
  { name: "prowler", category: "Cloud security", about: "AWS/Azure/GCP security assessment.", docs: "https://github.com/prowler-cloud/prowler" },
  { name: "scoutsuite", category: "Cloud security", about: "Multi-cloud security auditing.", docs: "https://github.com/nccgroup/ScoutSuite" },
  { name: "cloudsploit", category: "Cloud security", about: "Cloud configuration scanning.", docs: "https://github.com/aquasecurity/cloudsploit" },
  { name: "cartography", category: "Cloud security", about: "Infrastructure relationship mapping.", docs: "https://github.com/lyft/cartography" },

  /* --------------------- Active Directory ------------------------- */
  { name: "rubeus", category: "Active Directory", about: "Kerberos interaction analysis (own domain).", docs: "https://github.com/GhostPack/Rubeus" },
  { name: "mimikatz", category: "Active Directory", about: "Credential structure research — isolated labs only.", docs: "https://github.com/gentilkiwi/mimikatz" },
  { name: "certipy", category: "Active Directory", about: "AD certificate services assessment.", docs: "https://github.com/ly4k/Certipy" },
  { name: "ldapdomaindump", category: "Active Directory", about: "LDAP enumeration and reporting.", docs: "https://github.com/dirkjanm/ldapdomaindump" },
  { name: "windapsearch", category: "Active Directory", about: "Active Directory LDAP querying.", docs: "https://github.com/dirkjanm/windapsearch" },
  { name: "powerview", category: "Active Directory", about: "Domain situational awareness.", docs: "https://github.com/PowerShellMafia/PowerSploit" },

  /* ------------------------ Reporting & QA ------------------------ */
  { name: "faraday", category: "Security reporting", about: "Collaborative penetration test management.", docs: "https://www.faradaysec.com" },
  { name: "dradis", category: "Security reporting", about: "Security reporting and collaboration.", docs: "https://dradis.com" },
  { name: "pwndoc", category: "Security reporting", about: "Pentest report generation.", docs: "https://github.com/pwndoc/pwndoc" },
  { name: "serpico", category: "Security reporting", about: "Report generation for assessments.", docs: "https://github.com/SerpicoProject/Serpico" },
  { name: "defectdojo", category: "Security reporting", about: "Vulnerability management and tracking.", docs: "https://www.defectdojo.org" },

  /* ------------------- Mobile, hardware & radio ------------------- */
  { name: "apktool", category: "Mobile security", about: "Android package reverse engineering.", docs: "https://www.kali.org/tools/apktool/" },
  { name: "jadx", category: "Mobile security", about: "Android DEX to Java decompiler.", docs: "https://github.com/skylot/jadx" },
  { name: "dex2jar", category: "Mobile security", about: "Convert Android DEX to JAR for analysis.", docs: "https://github.com/pxb1988/dex2jar" },
  { name: "apk-mitm", category: "Mobile security", about: "Certificate pinning review for owned builds.", docs: "https://github.com/shroudedcode/apk-mitm" },
  { name: "objection", category: "Mobile security", about: "Runtime mobile exploration toolkit.", docs: "https://github.com/sensepost/objection" },
  { name: "frida", category: "Mobile security", about: "Dynamic instrumentation for owned applications.", docs: "https://frida.re" },
  { name: "drozer", category: "Mobile security", about: "Android application security assessment.", docs: "https://www.kali.org/tools/drozer/" },
  { name: "mobsf", category: "Mobile security", about: "Mobile security testing framework.", docs: "https://github.com/MobSF/Mobile-Security-Framework-MobSF" },
  { name: "ghidra-mobile", category: "Mobile security", about: "Native library reversing on Android builds.", docs: "https://ghidra-sre.org" },
  { name: "sdrsharp", category: "Hardware & radio", about: "Software-defined radio reception analysis.", docs: "https://airspy.com/download/" },
  { name: "gqrx", category: "Hardware & radio", about: "SDR receiver for radio spectrum study.", docs: "https://gqrx.dk" },
  { name: "hackrf", category: "Hardware & radio", about: "Radio test equipment tooling (owned spectrum).", docs: "https://greatscottgadgets.com/hackrf/" },
  { name: "rtl-sdr", category: "Hardware & radio", about: "DVB-T dongle radio analysis tools.", docs: "https://osmocom.org/projects/rtl-sdr/wiki" },
  { name: "urh", category: "Hardware & radio", about: "Universal radio hacker for own devices.", docs: "https://github.com/jopohl/urh" },
  { name: "proxmark3", category: "Hardware & radio", about: "RFID/NFC research on owned credentials.", docs: "https://github.com/RfidResearchGroup/proxmark3" },
  { name: "chipwhisperer", category: "Hardware & radio", about: "Side-channel analysis laboratory.", docs: "https://chipwhisperer.com" },
  { name: "openocd", category: "Hardware & radio", about: "On-chip debugging for own hardware.", docs: "https://openocd.org" },
  { name: "minicom", category: "Hardware & radio", about: "Serial console analysis.", docs: "https://www.kali.org/tools/minicom/" },
  { name: "buspirate", category: "Hardware & radio", about: "Hardware protocol debugging.", docs: "https://buspirate.com" },

  /* ---------------------- Web3 & identity ------------------------- */
  { name: "slither", category: "Web3 security", about: "Static analysis for smart contracts you own.", docs: "https://github.com/crytic/slither" },
  { name: "mythril", category: "Web3 security", about: "Symbolic analysis of EVM bytecode.", docs: "https://github.com/ConsenSys/mythril" },
  { name: "foundry", category: "Web3 security", about: "Smart contract testing toolkit.", docs: "https://getfoundry.sh" },
  { name: "hardhat", category: "Web3 security", about: "Ethereum development and testing.", docs: "https://hardhat.org" },
  { name: "ethpwn", category: "Web3 security", about: "EVM analysis library for lab exercises.", docs: "https://github.com/es3n1n/ethpwn" },
  { name: "semgrep-smart", category: "Web3 security", about: "Custom rules for contract patterns.", docs: "https://semgrep.dev" },
  { name: "truffle", category: "Web3 security", about: "Contract compilation and test harness.", docs: "https://trufflesuite.com" },
  { name: "echidna", category: "Web3 security", about: "Fuzzing for smart contracts.", docs: "https://github.com/crytic/echidna" },

  /* ------------------- Infrastructure & IAM ----------------------- */
  { name: "pacu-iam", category: "Cloud security", about: "IAM misconfiguration review in owned accounts.", docs: "https://github.com/RhinoSecurityLabs/pacu" },
  { name: "iamlive", category: "Cloud security", about: "Capture IAM policy needs from real usage.", docs: "https://github.com/iann0036/iamlive" },
  { name: "cartography-iam", category: "Cloud security", about: "IAM relationship mapping.", docs: "https://github.com/lyft/cartography" },
  { name: "cloudsplaining", category: "Cloud security", about: "IAM policy risk analysis.", docs: "https://github.com/salesforce/cloudsplaining" },
  { name: "parliament", category: "Cloud security", about: "IAM linting.", docs: "https://github.com/duo-labs/parliament" },
  { name: "terraform-scan", category: "Cloud security", about: "IaC misconfiguration scanning.", docs: "https://github.com/aquasecurity/tfsec" },
  { name: "kics", category: "Cloud security", about: "Keeping infrastructure as code secure.", docs: "https://github.com/Checkmarx/kics" },
  { name: "cdk-nag", category: "Cloud security", about: "CDK rule checks for AWS stacks.", docs: "https://github.com/cdklabs/cdk-nag" },

  /* --------------------- Detection & response --------------------- */
  { name: "sigma", category: "Detection & response", about: "Generic signature format for log events.", docs: "https://github.com/SigmaHQ/sigma" },
  { name: "suricata", category: "Detection & response", about: "Network intrusion detection.", docs: "https://suricata.io" },
  { name: "snort", category: "Detection & response", about: "Network intrusion prevention analysis.", docs: "https://www.snort.org" },
  { name: "zeek", category: "Detection & response", about: "Network security monitoring.", docs: "https://zeek.org" },
  { name: "wazuh", category: "Detection & response", about: "Host-based detection and response.", docs: "https://wazuh.com" },
  { name: "falco", category: "Detection & response", about: "Runtime container threat detection.", docs: "https://falco.org" },
  { name: "yara-rules", category: "Detection & response", about: "Community detection ruleset.", docs: "https://github.com/Yara-Rules/rules" },
  { name: "osquery", category: "Detection & response", about: "Endpoint visibility through SQL.", docs: "https://osquery.io" },
  { name: "auditd", category: "Detection & response", about: "Linux audit framework.", docs: "https://linux.die.net/man/8/auditd" },
  { name: "plaso", category: "Detection & response", about: "Timeline creation from forensic artifacts.", docs: "https://github.com/log2timeline/plaso" },

  /* --------------------- Reporting & standards -------------------- */
  { name: "mitre-attack", category: "Security reporting", about: "Adversary technique mapping for reports.", docs: "https://attack.mitre.org" },
  { name: "owasp-asvs", category: "Security reporting", about: "Application security verification standard.", docs: "https://owasp.org/www-project-application-security-verification-standard/" },
  { name: "cvss-calculator", category: "Security reporting", about: "Severity scoring that does not exaggerate.", docs: "https://www.first.org/cvss/calculator/" },
  { name: "nist-nvd", category: "Security reporting", about: "Vulnerability database and references.", docs: "https://nvd.nist.gov" },
  { name: "attack-navigator", category: "Security reporting", about: "Visual technique coverage mapping.", docs: "https://mitre-attack.github.io/attack-navigator/" },
  { name: "cve-cwe-map", category: "Security reporting", about: "Weakness classification for findings.", docs: "https://cwe.mitre.org" },
  { name: "pentext", category: "Security reporting", about: "Report templating for engagements.", docs: "https://github.com/SecAF/pentext" },
  { name: "vulnreport", category: "Security reporting", about: "Finding lifecycle tracking.", docs: "https://github.com/Netflix-Skunkworks/vulnreport" },
];

export const CATEGORIES = [...new Set(KALI_TOOLS.map((t) => t.category))];

/* --------------------------- honest tool status -------------------------- */

const CHECKS = ["nmap", "curl", "openssl", "dig", "node", "psql"];

/** Only ever reports a tool as installed when it is really on this host. */
export async function toolStatus(): Promise<Record<string, boolean>> {
  const { execFile } = await import("node:child_process");
  const out: Record<string, boolean> = {};
  for (const bin of CHECKS) {
    out[bin] = await new Promise<boolean>((resolve) => {
      try {
        execFile("which", [bin], { timeout: 2500 }, (err) => resolve(!err));
      } catch {
        resolve(false);
      }
    });
  }
  return out;
}

/* ----------------------------- target scope ----------------------------- */

export async function listTargets() {
  return db.select().from(targets).orderBy(desc(targets.createdAt)).limit(100);
}

export async function addTarget(input: {
  name: string;
  host: string;
  scope: string;
  notes: string;
}) {
  const host = input.host.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
  if (!/^[a-z0-9.-]{3,80}$/.test(host)) {
    throw new Error("That is not a valid hostname.");
  }
  const blocked = blockedHost(host);
  if (blocked) {
    throw new Error(`Refused: ${blocked} cannot be an assessment target.`);
  }
  // "lab" targets are explicitly registered local environments. Anything else
  // must prove control of the domain before it can be tested.
  if (input.scope !== "lab") {
    const proof = await verifyOwnership(host);
    if (!proof.verified) {
      throw new Error(
        `Ownership not proven. ${proof.detail} (Or register it as an isolated lab target you control.)`,
      );
    }
  }
  const existing = await db.select().from(targets).where(eq(targets.host, host));
  if (existing.length) return existing[0];
  const [row] = await db
    .insert(targets)
    .values({
      name: input.name.trim().slice(0, 80) || host,
      host,
      scope: ["owned", "staging", "lab"].includes(input.scope) ? input.scope : "lab",
      authorized: 1,
      notes: input.notes.slice(0, 300),
    })
    .returning();
  return row;
}

/* ------------------------- non-destructive checks ------------------------ */

export type Finding = {
  severity: "high" | "medium" | "low" | "pass";
  check: string;
  detail: string;
  fix: string;
};

export async function assess(host: string): Promise<{ host: string; findings: Finding[] }> {
  const findings: Finding[] = [];
  const url = `https://${host}`;

  const blocked = blockedHost(host);
  if (blocked) {
    return {
      host,
      findings: [
        {
          severity: "high",
          check: "scope enforcement",
          detail: `Refused to scan: ${blocked}.`,
          fix: "Only externally-owned, authorized hosts may be assessed.",
        },
      ],
    };
  }

  // 1. transport security
  try {
    const res = await fetch(url, {
      signal: AbortSignal.timeout(9000),
      // No automatic redirects: a redirect must never become a scope bypass.
      redirect: "manual",
      headers: { "User-Agent": "WIRE-Security-Lab/1.0 (authorized assessment)" },
    });
    const h = res.headers;
    const expect: [string, string, string][] = [
      ["strict-transport-security", "high", "HSTS missing — browsers can be downgraded to plain HTTP."],
      ["content-security-policy", "high", "No CSP — injection flaws are far easier to exploit."],
      ["x-content-type-options", "medium", "Missing nosniff — responses can be misinterpreted as active content."],
      ["x-frame-options", "medium", "Missing frame protection — clickjacking is possible."],
      ["referrer-policy", "low", "No referrer policy — URLs leak to third parties."],
      ["permissions-policy", "low", "No permissions policy — browser features are unrestricted."],
    ];
    for (const [header, severity, detail] of expect) {
      if (h.get(header)) {
        findings.push({ severity: "pass", check: header, detail: `Present: ${h.get(header)!.slice(0, 70)}`, fix: "" });
      } else {
        findings.push({
          severity: severity as Finding["severity"],
          check: header,
          detail,
          fix: `Add the ${header} header at the edge or in the application.`,
        });
      }
    }
    if (h.get("server")) {
      findings.push({
        severity: "low",
        check: "server banner",
        detail: `Server discloses: ${h.get("server")}`,
        fix: "Suppress version banners at the proxy.",
      });
    }
    if (h.get("set-cookie") && !/secure/i.test(h.get("set-cookie")!)) {
      findings.push({
        severity: "high",
        check: "cookie flags",
        detail: "A cookie is set without the Secure flag.",
        fix: "Set Secure, HttpOnly and SameSite on all cookies.",
      });
    }
    if (!res.url.startsWith("https")) {
      findings.push({
        severity: "high",
        check: "redirect chain",
        detail: `The site ends up on a plain-HTTP URL (${res.url}).`,
        fix: "Redirect all HTTP traffic to HTTPS at the edge.",
      });
    }
    findings.push({
      severity: "pass",
      check: "availability",
      detail: `Responded ${res.status} in ${res.url.startsWith("https") ? "HTTPS" : "HTTP"}.`,
      fix: "",
    });
  } catch (err) {
    findings.push({
      severity: "high",
      check: "reachability",
      detail: `Could not reach the target: ${err instanceof Error ? err.message : "unknown"}`,
      fix: "Confirm the host is up and reachable from the internet.",
    });
  }

  // 2. exposure checks (passive, harmless)
  for (const path of ["/.env", "/.git/config", "/backup.zip"]) {
    try {
      const res = await fetch(`https://${host}${path}`, {
        signal: AbortSignal.timeout(6000),
        method: "GET",
        redirect: "manual",
        headers: { "User-Agent": "WIRE-Security-Lab/1.0 (authorized assessment)" },
      });
      const text = await res.text();
      const leaked =
        res.ok &&
        text.length > 0 &&
        !/not found|404|cannot GET|does not exist/i.test(text.slice(0, 400));
      findings.push({
        severity: leaked ? "high" : "pass",
        check: `exposure ${path}`,
        detail: leaked
          ? `${path} is publicly readable — secrets or history may be leaking.`
          : `${path} is not exposed.`,
        fix: leaked ? "Block dotfiles and backups at the web server immediately." : "",
      });
    } catch {
      findings.push({ severity: "pass", check: `exposure ${path}`, detail: "Not reachable.", fix: "" });
    }
  }

  return { host, findings };
}

export function reportSummary(findings: Finding[]) {
  const high = findings.filter((f) => f.severity === "high").length;
  const medium = findings.filter((f) => f.severity === "medium").length;
  const low = findings.filter((f) => f.severity === "low").length;
  const pass = findings.filter((f) => f.severity === "pass").length;
  const score = Math.max(5, 100 - high * 18 - medium * 8 - low * 3);
  return { high, medium, low, pass, score };
}
