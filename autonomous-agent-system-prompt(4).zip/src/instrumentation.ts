/**
 * WIRE — the survival layer.
 *
 * Nothing in this process is allowed to die. Unhandled rejections, uncaught
 * exceptions, provider timeouts and empty responses are caught here, recorded,
 * and worked around instead of taking the desk down.
 */

export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  const log = (kind: string, detail: unknown) => {
    const line = `[wire:${kind}] ${new Date().toISOString()} ${
      detail instanceof Error ? detail.stack ?? detail.message : String(detail)
    }`;
    console.error(line);
  };

  process.on("uncaughtException", (err) => log("uncaught", err));
  process.on("unhandledRejection", (err) => log("rejection", err));
  process.on("warning", (w) => log("warning", w.message));

  // Keep the event loop honest: never let a hung socket hold a turn hostage.
  const keepalive = setInterval(() => {
    if (typeof (globalThis as any).__wireAlive !== "number") {
      (globalThis as any).__wireAlive = Date.now();
    }
    (globalThis as any).__wireAlive = Date.now();
  }, 30_000);
  keepalive.unref?.();

  console.log("[wire] survival layer armed — the desk does not crash, it degrades.");
}
