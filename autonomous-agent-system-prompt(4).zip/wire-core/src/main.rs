//! WIRE core — the performance-critical engine, in Rust.
//!
//! Dependency-free by design: nothing here can be compromised through a
//! third-party crate, and it compiles to a small, fast, auditable binary.
//!
//! Commands:
//!   hash <text>       SHA-256, SHA-1, MD5
//!   b64 [-d] <text>   Base64 encode / decode
//!   rot13 <text>      ROT13
//!   hex [-d] <text>   Hex encode / decode
//!   uuid              UUID v4
//!   crack <cipher>    Identify and decode hex / base64 / binary / rot13 / morse / url
//!   jwt <token>       Decode a JWT header and payload
//!   stats <text>      Text statistics

use std::io::Read;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let cmd = args.first().map(|s| s.as_str()).unwrap_or("help");
    let rest = args[1..].join(" ");

    match cmd {
        "hash" => {
            let bytes = rest.as_bytes();
            println!("SHA-256 {}", hex(&sha256(bytes)));
            println!("SHA-1   {}", hex(&sha1(bytes)));
            println!("MD5     {}", hex(&md5(bytes)));
            println!("BYTES   {}", bytes.len());
        }
        "b64" => {
            let decode = rest.starts_with("-d");
            let body = rest.replacen("-d", "", 1).trim().to_string();
            if decode {
                match b64_decode(&body) {
                    Ok(v) => println!("{}", String::from_utf8_lossy(&v)),
                    Err(e) => eprintln!("error: {e}"),
                }
            } else {
                println!("{}", b64_encode(body.as_bytes()));
            }
        }
        "rot13" => println!("{}", rot13(&rest)),
        "hex" => {
            let decode = rest.starts_with("-d");
            let body = rest.replacen("-d", "", 1).trim().to_string();
            if decode {
                match unhex(&body) {
                    Ok(v) => println!("{}", String::from_utf8_lossy(&v)),
                    Err(e) => eprintln!("error: {e}"),
                }
            } else {
                println!("{}", hex(body.as_bytes()));
            }
        }
        "uuid" => println!("{}", uuid_v4()),
        "crack" => crack(&rest),
        "jwt" => jwt(&rest),
        "stats" => stats(&rest),
        _ => {
            println!("wire-core 1.0.0 — WIRE's engine, in Rust");
            println!("commands: hash | b64 | rot13 | hex | uuid | crack | jwt | stats");
        }
    }
}

/* ------------------------------- encoding ------------------------------ */

const B64: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

fn b64_encode(data: &[u8]) -> String {
    let mut out = String::with_capacity(data.len().div_ceil(3) * 4);
    for chunk in data.chunks(3) {
        let b = [
            chunk[0],
            *chunk.get(1).unwrap_or(&0),
            *chunk.get(2).unwrap_or(&0),
        ];
        let n = ((b[0] as u32) << 16) | ((b[1] as u32) << 8) | b[2] as u32;
        out.push(B64[(n >> 18) as usize & 63] as char);
        out.push(B64[(n >> 12) as usize & 63] as char);
        out.push(if chunk.len() > 1 { B64[(n >> 6) as usize & 63] as char } else { '=' });
        out.push(if chunk.len() > 2 { B64[n as usize & 63] as char } else { '=' });
    }
    out
}

fn b64_decode(input: &str) -> Result<Vec<u8>, String> {
    let clean: Vec<u8> = input
        .bytes()
        .filter(|b| *b != b'=' && !b.is_ascii_whitespace())
        .collect();
    if clean.len() % 4 == 1 {
        return Err("invalid base64 length".into());
    }
    let mut out = Vec::with_capacity(clean.len() * 3 / 4);
    for chunk in clean.chunks(4) {
        let mut n: u32 = 0;
        for (i, b) in chunk.iter().enumerate() {
            let val = B64
                .iter()
                .position(|c| c == b)
                .ok_or_else(|| "invalid base64 character".to_string())? as u32;
            n |= val << (18 - 6 * i as u32);
        }
        let bytes = n.to_be_bytes();
        let take = chunk.len() - 1;
        out.extend_from_slice(&bytes[1..=take]);
    }
    Ok(out)
}

fn hex(data: &[u8]) -> String {
    data.iter().map(|b| format!("{b:02x}")).collect()
}

fn unhex(input: &str) -> Result<Vec<u8>, String> {
    let clean: Vec<u8> = input.bytes().filter(|b| !b.is_ascii_whitespace()).collect();
    if clean.len() % 2 != 0 {
        return Err("odd hex length".into());
    }
    clean
        .chunks(2)
        .map(|c| {
            let s = std::str::from_utf8(c).map_err(|_| "bad hex")?;
            u8::from_str_radix(s, 16).map_err(|_| "bad hex".to_string())
        })
        .collect()
}

fn rot13(input: &str) -> String {
    input
        .chars()
        .map(|c| match c {
            'a'..='z' => (((c as u8 - b'a' + 13) % 26) + b'a') as char,
            'A'..='Z' => (((c as u8 - b'A' + 13) % 26) + b'A') as char,
            _ => c,
        })
        .collect()
}

fn uuid_v4() -> String {
    let mut buf = [0u8; 16];
    if let Ok(mut f) = std::fs::File::open("/dev/urandom") {
        let _ = f.read_exact(&mut buf);
    } else {
        // fall back to a time-seeded xorshift; never panic on missing entropy
        let t = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos() as u64)
            .unwrap_or(0x9E3779B97F4A7C15);
        let mut x = t | 1;
        for slot in buf.chunks_mut(8) {
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            for (i, b) in slot.iter_mut().enumerate() {
                *b = (x >> (8 * i)) as u8;
            }
        }
    }
    buf[6] = (buf[6] & 0x0f) | 0x40;
    buf[8] = (buf[8] & 0x3f) | 0x80;
    let h = hex(&buf);
    format!(
        "{}-{}-{}-{}-{}",
        &h[0..8],
        &h[8..12],
        &h[12..16],
        &h[16..20],
        &h[20..32]
    )
}

/* -------------------------------- hashing ------------------------------ */

fn sha256(data: &[u8]) -> [u8; 32] {
    const K: [u32; 64] = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
    ];
    let mut h: [u32; 8] = [
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
    ];

    let mut msg = data.to_vec();
    let bitlen = (data.len() as u64) * 8;
    msg.push(0x80);
    while msg.len() % 64 != 56 {
        msg.push(0);
    }
    msg.extend_from_slice(&bitlen.to_be_bytes());

    for block in msg.chunks(64) {
        let mut w = [0u32; 64];
        for i in 0..16 {
            w[i] = u32::from_be_bytes([
                block[i * 4],
                block[i * 4 + 1],
                block[i * 4 + 2],
                block[i * 4 + 3],
            ]);
        }
        for i in 16..64 {
            let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
            let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16]
                .wrapping_add(s0)
                .wrapping_add(w[i - 7])
                .wrapping_add(s1);
        }
        let (mut a, mut b, mut c, mut d, mut e, mut f, mut g, mut hh) =
            (h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7]);
        for i in 0..64 {
            let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
            let ch = (e & f) ^ ((!e) & g);
            let t1 = hh
                .wrapping_add(s1)
                .wrapping_add(ch)
                .wrapping_add(K[i])
                .wrapping_add(w[i]);
            let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
            let maj = (a & b) ^ (a & c) ^ (b & c);
            let t2 = s0.wrapping_add(maj);
            hh = g;
            g = f;
            f = e;
            e = d.wrapping_add(t1);
            d = c;
            c = b;
            b = a;
            a = t1.wrapping_add(t2);
        }
        h[0] = h[0].wrapping_add(a);
        h[1] = h[1].wrapping_add(b);
        h[2] = h[2].wrapping_add(c);
        h[3] = h[3].wrapping_add(d);
        h[4] = h[4].wrapping_add(e);
        h[5] = h[5].wrapping_add(f);
        h[6] = h[6].wrapping_add(g);
        h[7] = h[7].wrapping_add(hh);
    }

    let mut out = [0u8; 32];
    for (i, word) in h.iter().enumerate() {
        out[i * 4..i * 4 + 4].copy_from_slice(&word.to_be_bytes());
    }
    out
}

fn sha1(data: &[u8]) -> [u8; 20] {
    let mut h: [u32; 5] = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0];
    let mut msg = data.to_vec();
    let bitlen = (data.len() as u64) * 8;
    msg.push(0x80);
    while msg.len() % 64 != 56 {
        msg.push(0);
    }
    msg.extend_from_slice(&bitlen.to_be_bytes());

    for block in msg.chunks(64) {
        let mut w = [0u32; 80];
        for i in 0..16 {
            w[i] = u32::from_be_bytes([
                block[i * 4],
                block[i * 4 + 1],
                block[i * 4 + 2],
                block[i * 4 + 3],
            ]);
        }
        for i in 16..80 {
            w[i] = (w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]).rotate_left(1);
        }
        let (mut a, mut b, mut c, mut d, mut e) = (h[0], h[1], h[2], h[3], h[4]);
        for i in 0..80 {
            let (f, k) = match i {
                0..=19 => ((b & c) | ((!b) & d), 0x5A827999),
                20..=39 => (b ^ c ^ d, 0x6ED9EBA1),
                40..=59 => ((b & c) | (b & d) | (c & d), 0x8F1BBCDC),
                _ => (b ^ c ^ d, 0xCA62C1D6),
            };
            let t = a
                .rotate_left(5)
                .wrapping_add(f)
                .wrapping_add(e)
                .wrapping_add(k)
                .wrapping_add(w[i]);
            e = d;
            d = c;
            c = b.rotate_left(30);
            b = a;
            a = t;
        }
        h[0] = h[0].wrapping_add(a);
        h[1] = h[1].wrapping_add(b);
        h[2] = h[2].wrapping_add(c);
        h[3] = h[3].wrapping_add(d);
        h[4] = h[4].wrapping_add(e);
    }

    let mut out = [0u8; 20];
    for (i, word) in h.iter().enumerate() {
        out[i * 4..i * 4 + 4].copy_from_slice(&word.to_be_bytes());
    }
    out
}

fn md5(data: &[u8]) -> [u8; 16] {
    const S: [u32; 64] = [
        7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5,
        9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10,
        15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21,
    ];
    let mut k = [0u32; 64];
    for (i, item) in k.iter_mut().enumerate() {
        *item = (((i as f64 + 1.0).sin().abs()) * 4294967296.0) as u32;
    }

    let mut msg = data.to_vec();
    let bitlen = (data.len() as u64) * 8;
    msg.push(0x80);
    while msg.len() % 64 != 56 {
        msg.push(0);
    }
    msg.extend_from_slice(&bitlen.to_le_bytes());

    let (mut a0, mut b0, mut c0, mut d0) = (0x67452301u32, 0xefcdab89u32, 0x98badcfeu32, 0x10325476u32);

    for block in msg.chunks(64) {
        let mut m = [0u32; 16];
        for i in 0..16 {
            m[i] = u32::from_le_bytes([
                block[i * 4],
                block[i * 4 + 1],
                block[i * 4 + 2],
                block[i * 4 + 3],
            ]);
        }
        let (mut a, mut b, mut c, mut d) = (a0, b0, c0, d0);
        for i in 0..64 {
            let (f, g) = match i {
                0..=15 => ((b & c) | ((!b) & d), i),
                16..=31 => ((d & b) | ((!d) & c), (5 * i + 1) % 16),
                32..=47 => (b ^ c ^ d, (3 * i + 5) % 16),
                _ => (c ^ (b | (!d)), (7 * i) % 16),
            };
            let f2 = f
                .wrapping_add(a)
                .wrapping_add(k[i])
                .wrapping_add(m[g]);
            a = d;
            d = c;
            c = b;
            b = b.wrapping_add(f2.rotate_left(S[i]));
        }
        a0 = a0.wrapping_add(a);
        b0 = b0.wrapping_add(b);
        c0 = c0.wrapping_add(c);
        d0 = d0.wrapping_add(d);
    }

    let mut out = [0u8; 16];
    out[0..4].copy_from_slice(&a0.to_le_bytes());
    out[4..8].copy_from_slice(&b0.to_le_bytes());
    out[8..12].copy_from_slice(&c0.to_le_bytes());
    out[12..16].copy_from_slice(&d0.to_le_bytes());
    out
}

/* ------------------------------ inspection ----------------------------- */

fn crack(input: &str) {
    let s = input.trim();
    if s.is_empty() {
        println!("error: give me something to decode");
        return;
    }

    // hex
    if s.len() % 2 == 0 && s.bytes().all(|b| b.is_ascii_hexdigit()) {
        if let Ok(v) = unhex(s) {
            if !v.is_empty() && v.iter().all(|b| b.is_ascii_graphic() || b.is_ascii_whitespace()) {
                println!("CIPHER plain hex");
                println!("OUTPUT {}", String::from_utf8_lossy(&v));
                return;
            }
        }
    }

    // base64
    if s.len() % 4 == 0
        && s.bytes()
            .all(|b| b.is_ascii_alphanumeric() || b == b'+' || b == b'/' || b == b'=')
    {
        if let Ok(v) = b64_decode(s) {
            if !v.is_empty() && v.iter().all(|b| b.is_ascii_graphic() || b.is_ascii_whitespace()) {
                println!("CIPHER base64");
                println!("OUTPUT {}", String::from_utf8_lossy(&v));
                return;
            }
        }
    }

    // binary
    let compact: String = s.chars().filter(|c| !c.is_whitespace()).collect();
    if compact.len() % 8 == 0 && compact.chars().all(|c| c == '0' || c == '1') {
        let text: String = compact
            .as_bytes()
            .chunks(8)
            .map(|b| u8::from_str_radix(std::str::from_utf8(b).unwrap_or("0"), 2).unwrap_or(32) as char)
            .collect();
        println!("CIPHER binary");
        println!("OUTPUT {text}");
        return;
    }

    // percent-encoding
    if s.contains('%') {
        let decoded = s
            .split('%')
            .enumerate()
            .map(|(i, part)| {
                if i == 0 {
                    part.to_string()
                } else {
                    let (hexpart, tail) = part.split_at(2.min(part.len()));
                    let ch = u8::from_str_radix(hexpart, 16)
                        .map(|b| b as char)
                        .unwrap_or('?');
                    format!("{ch}{tail}")
                }
            })
            .collect::<String>();
        println!("CIPHER percent-encoding");
        println!("OUTPUT {decoded}");
        return;
    }

    // morse
    if s.chars().all(|c| matches!(c, '.' | '-' | '/' | ' ')) && s.contains('.') || s.contains('-') {
        const TABLE: [(&str, char); 36] = [
            (".-", 'a'), ("-...", 'b'), ("-.-.", 'c'), ("-..", 'd'), (".", 'e'), ("..-.", 'f'),
            ("--.", 'g'), ("....", 'h'), ("..", 'i'), (".---", 'j'), ("-.-", 'k'), (".-..", 'l'),
            ("--", 'm'), ("-.", 'n'), ("---", 'o'), (".--.", 'p'), ("--.-", 'q'), (".-.", 'r'),
            ("...", 's'), ("-", 't'), ("..-", 'u'), ("...-", 'v'), (".--", 'w'), ("-..-", 'x'),
            ("-.--", 'y'), ("--..", 'z'), ("-----", '0'), (".----", '1'), ("..---", '2'),
            ("...--", '3'), ("....-", '4'), (".....", '5'), ("-....", '6'), ("--...", '7'),
            ("---..", '8'), ("----.", '9'),
        ];
        let text: String = s
            .split_whitespace()
            .map(|t| TABLE.iter().find(|(code, _)| *code == t).map(|(_, c)| *c).unwrap_or(' '))
            .collect();
        println!("CIPHER morse");
        println!("OUTPUT {text}");
        return;
    }

    println!("CIPHER none recognised");
    println!("OUTPUT try hex, base64, binary, morse, rot13 or percent-encoding");
    println!("ROT13 {}", rot13(s));
    println!("REVERSED {}", s.chars().rev().collect::<String>());
}

fn jwt(token: &str) {
    let parts: Vec<&str> = token.split('.').collect();
    if parts.len() < 2 {
        println!("error: a JWT has three dot-separated segments");
        return;
    }
    for (label, part) in [("HEADER", parts[0]), ("PAYLOAD", parts[1])] {
        match b64_decode(part) {
            Ok(v) => println!("{label} {}", String::from_utf8_lossy(&v)),
            Err(e) => println!("{label} error: {e}"),
        }
    }
    println!("SIGNATURE {}", parts.get(2).unwrap_or(&"(none)"));
}

fn stats(text: &str) {
    let words: Vec<&str> = text.split_whitespace().collect();
    let sentences = text.split(|c| c == '.' || c == '!' || c == '?').filter(|s| !s.trim().is_empty()).count().max(1);
    let avg = if words.is_empty() {
        0.0
    } else {
        words.iter().map(|w| w.len()).sum::<usize>() as f64 / words.len() as f64
    };
    println!("CHARS {}", text.chars().count());
    println!("BYTES {}", text.len());
    println!("WORDS {}", words.len());
    println!("SENTENCES {sentences}");
    println!("AVG_WORD {:.2}", avg);
    println!("READ_MIN {}", (words.len() as f64 / 220.0).max(1.0).round());
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sha256_known_vectors() {
        assert_eq!(
            hex(&sha256(b"abc")),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
        assert_eq!(
            hex(&sha256(b"")),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
    }

    #[test]
    fn sha1_known_vector() {
        assert_eq!(hex(&sha1(b"abc")), "a9993e364706816aba3e25717850c26c9cd0d89d");
    }

    #[test]
    fn md5_known_vectors() {
        assert_eq!(hex(&md5(b"abc")), "900150983cd24fb0d6963f7d28e17f72");
        assert_eq!(hex(&md5(b"")), "d41d8cd98f00b204e9800998ecf8427e");
    }

    #[test]
    fn base64_roundtrip() {
        assert_eq!(b64_encode(b"hello"), "aGVsbG8=");
        assert_eq!(b64_decode("aGVsbG8=").unwrap(), b"hello");
        assert_eq!(b64_encode(b"wire desk"), "d2lyZSBkZXNr");
    }

    #[test]
    fn rot13_roundtrip() {
        assert_eq!(rot13("wire desk"), "jver qrfx");
        assert_eq!(rot13(&rot13("Hello")), "Hello");
    }

    #[test]
    fn uuid_shape() {
        let u = uuid_v4();
        assert_eq!(u.len(), 36);
        assert_eq!(&u[14..15], "4");
    }

    #[test]
    fn hex_roundtrip() {
        assert_eq!(hex(b"wire"), "77697265");
        assert_eq!(unhex("77697265").unwrap(), b"wire");
    }
}
